from confiacim.cli.base import base_app as app
from confiacim.cli.deterministic import determ_app
from confiacim.cli.dist import dist_app
from confiacim.cli.form import form_app
from confiacim.cli.monte_carlo import mc_app
from confiacim.cli.plot import plot_app, plotly_app
from confiacim.cli.tencim import tencim_app

app.add_typer(determ_app, name="deterministic", help="Análise deterministica.")
app.add_typer(tencim_app, name="tencim", help="Análise simples com o tencim.")

form_app.add_typer(plot_app, name="plot", help="Plotando resultados do FORM com o matplotlib.")
form_app.add_typer(plotly_app, name="plotly", help="Plotando resultados do FORM com plotly.")

app.add_typer(dist_app, name="dist", help="Informações das distruibuições.")

app.add_typer(form_app, name="form", help="Análise probabilistica usando o FORM.")

app.add_typer(mc_app, name="mc", help="Análise probabilistica usando o Monte Carlo.")


__all__ = ("app",)
