"""
O módulo contem controladores para serem usando na `CLI` e na `API`.

Classes e funções deste módulo:

- run

---

"""

from pathlib import Path

from rich.align import Align
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from confiacim import tables
from confiacim.constants import COLORS
from confiacim.erros import CaseFileNotFound, InputDirNotExists
from confiacim.file_folder_handlers import default_output_dir
from confiacim.form.mainloop import loop
from confiacim.logger import get_logger, set_logger
from confiacim.run_statistics import confiacim_statistics
from confiacim.simulation_config import load_config
from confiacim.tencim.input_file import check_for_nocliprc_macro
from confiacim.timer import Timer
from confiacim.write_results import write_confiacim_statistics, write_final_results

logger = get_logger()
console = Console()


def run(
    *,
    input_dir: Path,
    output_dir: Path | None,
    verbose_level: int,
    save_intermediate_files: bool = False,
) -> None:
    """
    Rodando a simulação FORM.

    Parameters:
        input_dir: Diterório do arquivo de entrada.
        output_dir: Diterório do arquivo de saida.
        verbose_level: Nivel de verbosidade.
        save_intermediate_files: Salva os arquivos intermediarios da simulação.

    Info:
        A verbosidade pode ser:

        - 0 - Nenhuma
        - 1 - Moderada
        - 2 - Alta
    """
    if not Path(input_dir).exists():
        raise InputDirNotExists(input_dir)

    if not output_dir:
        output_dir = default_output_dir(input_dir)

    set_logger(logfile=input_dir / "simulation.log", name="simulation")

    try:
        check_for_nocliprc_macro(case_file=input_dir / "case.dat")
    except FileNotFoundError as e:
        raise CaseFileNotFound(e.filename) from FileNotFoundError

    simulation_conf = load_config(file_path=input_dir / "case.yml")
    variable_names = simulation_conf.variable_names

    logger.info(f"Analise form: {input_dir=} {output_dir=} {verbose_level=}")

    output_dir_form = output_dir / "form"

    with Timer("Complete Analysis", print_time=verbose_level) as t:
        results = loop(
            **simulation_conf.form_configs,
            **simulation_conf.base_configs,
            **simulation_conf.variables_infos,
            input_dir=input_dir,
            output_dir=output_dir_form,
            console=console,
            verbose_level=verbose_level,
            save_intermediate_files=save_intermediate_files,
        )
    confiacim_statistics.total_time = t.get_wall_time()

    if verbose_level:
        text = Text("Final results", justify="center", style=COLORS[3])
        panel = Panel(Align(text, vertical="middle", align="center"))
        console.print(panel)

        console.print(tables.form_final_stats(results))
        console.print(tables.form_sensitity(variable_names, results))

    write_json = simulation_conf.result_files == "json"
    json_indent = simulation_conf.json_indent

    write_final_results(results, output_dir_form, write_json=write_json, indent=json_indent)
    write_confiacim_statistics(confiacim_statistics, output_dir_form, write_json=write_json, indent=json_indent)
