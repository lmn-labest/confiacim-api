from pathlib import Path

from confiacim.variables import DistributionNames


class ConfiacimError(Exception): ...


class TencimExecNotFound(FileExistsError): ...


class TencimRunError(Exception): ...


# TODO: parece redundante com VariableTemplateError
class PropValueMissingError(ConfiacimError):
    def __init__(self, template_name: str, variable: str):
        self.message = (
            f"Template `{template_name}` foi encontrado, mas a variável '{str(variable)}' não foi achada. "
            "Por favor verificar os template e o 'case.yml'"
        )
        super().__init__(self.message)


class VariableTemplateError(ConfiacimError):
    def __init__(self, variable: str):
        self.message = (
            f"A variável '{variable}' foi achada no template mas não é uma variavel da simulação. "
            "Por favor verificar os templates e o arquivo case.yml."
        )
        super().__init__(self.message)


class FormStepUaInfError(ConfiacimError):
    def __init__(self):
        self.message = "O vetor Ua_new tem valores infinitos."
        super().__init__(self.message)


class FormStepModZeroError(ConfiacimError):
    def __init__(self):
        self.message = "Modg com valor zero."
        super().__init__(self.message)


class EmptyRCFile(ConfiacimError): ...


class InputDirNotExists(ConfiacimError):
    def __init__(self, input_dir: Path):
        message = f"Diretório {input_dir} não existe."
        super().__init__(message)


class InvalidStochasticVar(ConfiacimError): ...


class MustBeOrderedDict(ConfiacimError): ...


class SimulationConfigFileError(ConfiacimError): ...


class InvalidDistributionError(ConfiacimError):
    def __init__(self, dist: str):
        options = ", ".join(DistributionNames.options())

        self.message = f"Distribuição {dist} é invalida. As opções são: {options}."
        super().__init__(self.message)


class MatplotlibModuleError(ConfiacimError): ...


class PlotlyModuleError(ConfiacimError): ...


class RCFileNotFound(ConfiacimError): ...


class DirsResultsNotFound(ConfiacimError):
    def __init__(self, output_dir: Path | str):
        super().__init__(f"Nenhuma pasta de resultados foi achada no caminho '{output_dir}'.")


class SimulationFolderNotFound(ConfiacimError):
    def __init__(self, output_dir: Path | str):
        self.message = f"Nenhuma pasta de simulação foi achada no caminho '{output_dir}'."
        super().__init__(self.message)


class CaseFileNotFound(ConfiacimError):
    def __init__(self, filename: Path | str):
        self.message = f"Arquivo '{filename}' não foi achado."
        super().__init__(self.message)


class MissingNoRcNoClip(ConfiacimError): ...


class ItFolderNotFound(ConfiacimError):
    def __init__(self, it_folder: Path | str):
        self.message = f"A pasta da iteração não foi encontrada no caminho '{it_folder}'."
        super().__init__(self.message)


class NeedBeAFileNotDir(ConfiacimError):
    def __init__(self, path: Path | str):
        self.message = f"Precisa ser o caminho de um arquivo, foi passado o diretório '{path}'."
        super().__init__(self.message)


class VarNameNotFoundAtCaseFileError(ConfiacimError):
    def __init__(self, var_name: str):
        self.message = f"A variável '{var_name}' não foi encontrada no arquivo case.yml."
        super().__init__(self.message)
