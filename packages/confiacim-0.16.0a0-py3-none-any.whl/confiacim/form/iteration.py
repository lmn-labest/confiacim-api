"""
Cálculos matemáticos de uma iteração do **FORM**

---
"""

import logging

import numpy as np

from .math_utils import (
    array_U,
    array_V,
    i_matrix_A,
    matrix_A,
    mk_G,
    mk_grad_g,
    mk_gradU,
)
from confiacim.constants import NR
from confiacim.erros import FormStepModZeroError, FormStepUaInfError
from confiacim.logger import get_logger

VAR_NAMES = "Gi,Gaux,GradU,A,iA,Modg,Modg_square,betai,Vn,Ua".split(",")

logger_simulation = get_logger(name="simulation")


def form_step(
    Ua: np.ndarray,
    L: np.ndarray,
    rcs: dict,
    gamma: float,
    delta: float,
    beta: float,
    distributions: dict,
    iteration: int,
    Nr: int = NR,
) -> tuple:
    """
    Cálculos de uma iteração do **FORM**.

    Parameters:
        Ua: Valor das variaveis aleatórias normalizadas.
        L: Parte inferior da fatoração **Cholesky** da matriz de correlação.
        rcs: `RCs` das simulações.
        gamma: Parametro do **FORM**.
        delta: delta das derivadas.
        beta: Parametro do **FORM**.
        distributions: Distribuições `pdf`, `cpf`e `ppf`.
        iteration: Numero do iteração do **FORM**.
        Nr: Parâmetro de relaxação do metodo **FORM**

    Returns:
        Retorna as variáveis do `Ua`, `betai`, `res` e `Grad_gi / Modg` da iteração.

    Raises:
        FormStepModZeroError: Levanta um erro caso Modg seja nulo.
        FormStepUaInfError: Levanta um erro caso tenha um valor inifinito do array `Ua`.
    """

    fs = distributions["fs"]
    Fs = distributions["Fs"]
    IFs = distributions["IFs"]

    log_level = logging.DEBUG
    try:
        Gi, Gaux = mk_G(rcs, gamma)

        GradU = mk_gradU(Gaux, Gi, Ua, delta)

        Vi = array_V(Ua, L, Fs)

        A = matrix_A(Ua, fs, Fs)
        iA = i_matrix_A(A)

        Grad_gi = mk_grad_g(np.transpose(L), iA, GradU)

        Modg = np.linalg.norm(Grad_gi, ord=2)

        if Modg == 0.0e0:
            raise FormStepModZeroError()

        Modg_square = Modg**2
        Vn = ((np.dot(Grad_gi, Vi) - Gi) * Grad_gi) / Modg_square

        alpha = relaxation(iteration, Nr)

        Vstart = alpha * Vn + (1.0e0 - alpha) * Vi

        betai = np.linalg.norm(Vstart, ord=2)

        res = abs(betai - beta) / betai

        Ua = array_U(Vstart, L, IFs)

        if any(np.isinf(Ua)):
            raise FormStepUaInfError()

    except (FormStepModZeroError, FormStepUaInfError) as e:
        log_level = logging.ERROR
        raise e

    finally:
        _form_variable_state(**locals())

    return Ua, betai, res, Grad_gi / Modg


WRITE_LOGS = {
    logging.DEBUG: logger_simulation.debug,
    logging.ERROR: logger_simulation.error,
}


def _form_variable_state(**context):
    """
    Escreve o log cálculos de uma iteração do **FORM**

    Parameters:
        context: variáveis do contexto da função form_step
    """

    log_level = context["log_level"]

    write_log = WRITE_LOGS[log_level]

    dict_ = {"detail": "Form step"}

    for var_name in VAR_NAMES:
        try:
            var = context[var_name]
        except KeyError:
            continue

        if isinstance(var, np.ndarray):
            var_python = var.tolist()
        else:
            var_python = var

        dict_[var_name] = var_python

    write_log(dict_)


def relaxation(it: int, Nr: int = NR) -> float:
    """Fator de relaxação entre ]0.0, 1.0]

    Parameters:
        it: Numero da iteração
        Nr: Paramentro da relaxação

    Returns:
        float: Retorno o valor de relaxação
    """
    return it / Nr if it < Nr else 1.0
