import platform

match platform.system():
    case "Linux":
        COLORS = ("magenta", "green", "blue", "read")
    case "Windows":
        COLORS = ("magenta", "green", "bright_black", "red")
    case _:
        COLORS = ("magenta", "green", "blue", "red")

NR = 1
