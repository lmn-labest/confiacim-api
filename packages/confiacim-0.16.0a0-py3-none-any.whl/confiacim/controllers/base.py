"""
O módulo contem controladores para serem usando na `CLI` e na `API`.

Classes e funções deste módulo:

- search_var_by_name
- summary
- init
- get_os
- version
---

"""

import subprocess
from importlib.resources import files
from pathlib import Path

from rich.align import Align
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from confiacim import __version__, tables
from confiacim.conf import settings
from confiacim.erros import InputDirNotExists
from confiacim.file_folder_handlers import copy_list_files, list_files
from confiacim.form.correlations import generate_correlation_matrix
from confiacim.simulation_config import load_config

console = Console()


def summary(*, input_dir: Path) -> None:
    """
    Mostra o resumo da análise.

    Parameters:
        input_dir: Diretório da simulação.
    """
    if not Path(input_dir).exists():
        raise InputDirNotExists(input_dir)

    simulation_conf = load_config(file_path=input_dir / "case.yml")

    variable_names = simulation_conf.variable_names
    variables = simulation_conf.variables
    correlations = simulation_conf.correlations

    text = Text("Summary", justify="center", style="red")
    panel = Panel(Align(text, vertical="middle", align="center"))
    console.print(panel)

    table = tables.variables(variables)

    console.print(table)

    ro = generate_correlation_matrix(correlations, variables)

    table = tables.correlation(variable_names, ro)

    console.print(table)

    table = tables.form_simulation_configs(simulation_conf.configs)

    console.print(table)


def init():
    """
    Gera a estrutura básica para as simulações

    Infos:
        Cria um paasta `bin` com o `tencim` e uma pasta simulation para salvar as simulações.
    """
    base_dir = Path.cwd()

    module_root_dir = files("confiacim.data")

    for case_name in ["case1a", "case1b", "case8"]:
        case_dir = module_root_dir / f"input/{case_name}"
        input = base_dir / f"simulation/{case_name}"
        input.mkdir(exist_ok=True, parents=True)

        input_files = list_files(case_dir, ["*.dat", "*.yml"])

        copy_list_files(input_files, input)

        input_files = list_files(case_dir / "templates", "*.jinja")

        copy_list_files(input_files, input / "templates")


def version() -> str:
    """
    Pega a versão do confiacim e do tencim usado.

    Returns:
        Retorna uma string com as versões.
    """
    str_ = f"Confiacim {__version__}"
    try:
        tencim = subprocess.run([f"{settings.EXEC_TENCIM_DIR}/{settings.EXEC_TENCIM_BIN}", "-v"], capture_output=True)
        tencim_version = tencim.stdout.decode("utf-8").strip()
        str_ = f"{str_} ({tencim_version})"
    except FileNotFoundError:
        pass

    return str_
