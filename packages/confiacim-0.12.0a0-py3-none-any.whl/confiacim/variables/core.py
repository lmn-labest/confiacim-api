"""Modulo da variáveis aleatórias.

---
"""

from dataclasses import dataclass

from confiacim.variables.distribution import (
    DistGumbelR,
    DistLogNormal,
    DistLogNormalTrunked,
    DistNormal,
    DistSGLD,
    DistTriang,
    DistWeibullMin,
)

# TODO: Tipar isso depois
# DistType = DistLogNormal | DistNormal | DistGumbelR | DistWeibullMin | DistTriang

DIST_OPTIONS = {
    "lognormal": DistLogNormal.infos(),
    "lognormal_t": DistLogNormalTrunked.infos(),
    "normal": DistNormal.infos(),
    "gumbel_r": DistGumbelR.infos(),
    "weibull_min": DistWeibullMin.infos(),
    "triang": DistTriang.infos(),
    "sgld": DistSGLD.infos(),
}


@dataclass(frozen=True)
class DistInfos:
    """
    Classe que que guarda as infos da distruição lidas.

    Attributes:
        name (str): Nome da distribuição.
        params ( dict[str, int | float]): Parâmentros da distruibuição.
    """

    name: str
    params: dict[str, int | float]


class StochasticVariable:
    """
    Classe que define as variável aleatória.

    Attributes:
        name (str): Nome da variável.
        dist_infos (DistInfos): Informação da distribuição.
        dist (object): Instância da distribuição desejada

    Info:
        o Coeficiente de variação é o desvio padrão divido pela média.
    """

    def __init__(self, name: str, dist_infos: DistInfos):
        """
        Parameters:
            name: Nome da variável_
            dist_infos: Informações das distribuição_
        """
        self.name = name
        self.dist_infos = dist_infos
        self.dist = self.set_distribution()

    @property
    def mean(self):
        """Retorna a média da variável."""
        return self.dist.mean

    @property
    def std(self):
        """Retorna o desvio padrão da variável."""
        return self.dist.std

    def set_distribution(self):  # TODO: Tipar -> DistType
        """

        Raises:
            ValueError: Levanta o erro caso a distruição não seja válida.

        Returns:
            Retorna a distruição definida em dist_name.
        """
        try:
            Dist = DIST_OPTIONS[self.dist_infos.name]["class_"]
        except KeyError:
            raise ValueError(
                f"Distribuição '{self.dist_infos.name}' da variável '{self.name}' é invalida."
            ) from KeyError

        return Dist(**self.dist_infos.params)

    def __eq__(self, obj):
        if isinstance(obj, StochasticVariable):
            return (
                self.name == obj.name
                and self.dist_infos.params == obj.dist_infos.params
                and self.dist_infos.name == obj.dist_infos.name
            )
        return False


def pdf_cdf_ppf_of_distributions(variables: tuple[StochasticVariable, ...]) -> dict[str, list]:
    """
    Cria uma dicionário com as respectivas `pdf`, `cdf` e `ppf` das distribuicões..

    Parameters:
        variables: Variáves aleatórias.

    Returns:
        Retorna um dicionário com as distruibuições com sua respectivamente `pdf`, `cdf` e `ppf`.
    """
    fs, Fs, IFs = [], [], []

    for v in variables:
        fs.append(v.dist.pdf)
        Fs.append(v.dist.cdf)
        IFs.append(v.dist.ppf)

    return dict(fs=fs, Fs=Fs, IFs=IFs)


def search_var_by_name(variables: tuple[StochasticVariable, ...], var_name: str) -> StochasticVariable | None:
    """Procura por uma variável especifica

    Args:
        variables: Variaveis aleatorias
        var_name: Nome da variável que desejada

    Returns:
        Retorna a variável caso seja encontrada.
    """

    found_var = None
    for v in variables:
        if v.name == var_name:
            found_var = v
            break

    return found_var
