"""
Modulo com as funcionalidades da analises determiniticas com o `tencim`.

- new_case_with_until_the_step
- run_tencim

---
"""

from pathlib import Path

from confiacim.plot.results import RCResults, read_results
from confiacim.samples import Sample, sample_averages
from confiacim.tencim.iteration import run_samples_iteration_i
from confiacim.tencim.runner import TencimRunnerDeterministic
from confiacim.variables.core import StochasticVariable


def new_case_with_until_the_step(*, case_data_str: str, new_last_step: int) -> str:
    """
    Gera case truncado no new_last_step

    Danger:
        Caso `new_last_step` seja maior que o número de passos do caso original
        será mantido o valor inicial. Não será criado mais blocos `loop-next` do `tencim`.

    Parameters:
        case_data_str: Conteudo do Arquivo de `case.dat` não forma de `str`.
        new_last_step: Novo ultimo passo de tempo.

    Returns:
        Retorna no novo conteudo do arquivo `case.dat`.
    """

    lines = case_data_str.split("\n")

    new_lines, istep, k = [], 0, 0

    continued_reading = True

    while continued_reading:
        try:
            line = lines[k]
        except IndexError:
            break

        if not line:
            break

        words = line.split()

        if "dt" == words[0]:
            dt = float(words[1])
            loop = int(lines[k + 1].split()[1])

            for i in range(loop):
                istep += 1
                if istep >= new_last_step:
                    new_lines.extend(f"dt {dt}\nloop {i+1}\nsolvt\nsolvm\nnext\nstop".split("\n"))
                    continued_reading = False
                    break

            if not continued_reading:
                continue

            k += 4
            new_lines.extend(f"dt {dt}\nloop {loop}\nsolvt\nsolvm\nnext".split("\n"))
        else:
            new_lines.append(line)

        k += 1

    return "\n".join(new_lines)


def run_tencim(
    *,
    input_dir: Path,
    output_dir: Path,
    variables: tuple[StochasticVariable, ...],
    verbose: bool,
) -> RCResults:
    """
    Roda a análise determinista do `tencim`.

    Parameters:
        input_dir: Diterório do arquivo de entrada.
        output_dir: Diterório do arquivo de saida.
        variables: Variaveis aleatorias.
        verbose: Nivel de verbosidade.

    Returns:
        Retorna os resultados.
    """
    avgs = sample_averages(variables)
    sample = [Sample(name="deterministic", averages=avgs)]

    run_samples_iteration_i(
        samples=sample,
        input_dir=input_dir,
        output_dir=output_dir,
        RunnerClass=TencimRunnerDeterministic,
        verbose=verbose,
        save_intermediate_files=True,
    )

    results = read_results(output_dir / "deterministic")

    return results
