"""Módulo do controlador do comando dist"""

from pathlib import Path
from typing import Callable

from confiacim.erros import InputDirNotExists, VarNameNotFoundAtCaseFileError
from confiacim.simulation_config import load_config
from confiacim.variables.core import search_var_by_name


def dist(*, input_dir: Path, var_name: str, function_plot: Callable) -> None:
    """
    Plota a `pdf`, `cdf` ou `ppf` da distribuição selecinada.

    Parameters:
        input_dir: Diretório da simulação
        var_name: Nome da variável.
        function_plot: Função que plota.

    Raises:
        InputDirNotExists: Diretŕio não encontrado.
        VarNameNotFoundAtCaseFileError: Não da variável no encontrado.
    """
    if not Path(input_dir).exists():
        raise InputDirNotExists(input_dir)

    simulation_conf = load_config(file_path=input_dir / "case.yml")

    found_var = search_var_by_name(simulation_conf.variables, var_name)

    if found_var is None:
        raise VarNameNotFoundAtCaseFileError(var_name)

    function_plot(variable=found_var)
