"""
Módulo de logging

---
"""

import json
import logging
from logging import Logger, handlers
from pathlib import Path

from confiacim.conf import settings


class JsonFormatter(logging.Formatter):
    """
    Formatter that outputs JSON strings after parsing the LogRecord.

    Parameters:
        fmt_dict dict : Key: logging format attribute pairs..
        time_format str: time.strftime() format string."
        msec_format str: Microsecond formatting. Appended at the end."
    """

    # def __init__(self, fmt_dict: dict = None, time_format: str = "%Y-%m-%dT%H:%M:%S", msec_format: str = "%s.%03dZ"):
    def __init__(self, fmt_dict: dict, time_format: str = "%Y-%m-%d %H:%M:%S", msec_format: str = "%s.%03d"):
        self.fmt_dict = fmt_dict
        self.default_time_format = time_format
        self.default_msec_format = msec_format
        self.datefmt = None

    def usesTime(self) -> bool:
        """
        Overwritten to look for the attribute in the format dict values instead of the fmt string.
        """
        return "asctime" in self.fmt_dict.values()

    def formatMessage(self, record):
        """
        Overwritten to return a dictionary of the relevant LogRecord attributes instead of a string.
        KeyError is raised if an unknown attribute is provided in the fmt_dict.
        """
        return {fmt_key: record.__dict__[fmt_val] for fmt_key, fmt_val in self.fmt_dict.items()}

    def format(self, record) -> str:
        """
        Mostly the same as the parent's class method, the difference being that a dict is manipulated and dumped as JSON
        instead of a string.
        """
        msg = record.msg

        if isinstance(msg, dict):
            record.message = msg
        else:
            record.message = record.getMessage()

        if self.usesTime():
            record.asctime = self.formatTime(record, self.datefmt)

        if record.exc_info:
            # Cache the traceback text to avoid converting it multiple times
            # (it's constant anyway)
            if not record.exc_text:
                record.exc_text = self.formatException(record.exc_info)

        message_dict = {}

        if record.exc_text:
            message_dict["exc_info"] = record.exc_text

        if record.stack_info:
            message_dict["stack_info"] = self.formatStack(record.stack_info)

        message_dict = self.formatMessage(record)
        return json.dumps(message_dict, ensure_ascii=False)


fmt = JsonFormatter(
    {
        "timestamp": "asctime",
        "loggerName": "name",
        "level": "levelname",
        "filename": "filename",
        "fileline": "lineno",
        "message": "message",
    }
)


def set_logger(logfile: Path, name: str = "confiacim") -> Logger:
    """
    Configura um log para ser usuado depois.

    Parameters:
        logfile: Nome do arquivo de log.
        name: nome do logger.

    Returns:
        Retorna a classe de logging.
    """

    logger = logging.getLogger(name)
    logger.setLevel(settings.LOG_LEVEL)

    fh = handlers.RotatingFileHandler(logfile, maxBytes=1024 * 1024, backupCount=10)
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    return logger


def get_logger(name: str = "confiacim") -> Logger:
    """
    Obtém um logger.

    Parameters:
        name: nome do logger.

    Returns:
        Retorna a classe de logging.
    """
    return logging.getLogger(name)


confiacim_logger = set_logger(logfile=settings.LOG_FILE_PATH)
