from enum import UNIQUE, IntEnum, auto, verify


@verify(UNIQUE)
class VerboseLevel(IntEnum):
    LEVEL_0 = 0
    LEVEL_1 = auto()
    LEVEL_2 = auto()
