"""

Modulo que lida com os resultados da análise.

Classes e funções deste módulo:

- RCResults
- result_folders
- read_results

---
"""

import csv
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from confiacim.erros import EmptyRCFile, RCFileNotFound
from confiacim.file_folder_handlers import list_only_dirs


@dataclass(frozen=True)
class RCResults:
    """
    Classe que define os resultados.

    Attributes:
        istep: passos de tempo.
        t: tempos.
        rc_mhor_coulomb: `RC` do critério de Mhor Coulomb.
        rc_rankine: `RC` do critério de Rankine.
    """

    istep: np.ndarray
    t: np.ndarray
    rc_mhor_coulomb: np.ndarray
    rc_rankine: np.ndarray


def result_folders(path: Path, reverse: bool = False) -> list[Path]:
    """
    Retorna somente diretorios que começamm com `it_` de forrmma ordenada.

    Attributes:
        path: caminho do diretório.
        reverse: ordem daa listagem.

    Returns:
        Lista com os diretórios.
    """

    dirs = [abs_path for abs_path in list_only_dirs(path) if abs_path.name.startswith("it_")]

    return sorted(dirs, key=lambda x: int(x.name.split("_")[1]), reverse=reverse)


def read_results(path: Path) -> RCResults:
    """
    Retorna somente diretorios que começamm com `it_` de forrmma ordenada.

    Attributes:
        path: caminho do diretório onde existe um arquivo`RC`.

    Returns:
        Retorna os resultados.

    Info:
        É esperado que o **prefixo** do arquivo de `RC` tem o **mesmo** nome da pasta.

    Raises:
        EmptyRCFile: O arquivo `RC` está vazio.
        RCFileNotFound: O arquivo `RC` não encontrado.
    """

    file_name = path.name.split(".")[0] + "_RC.txt"
    try:
        with open(path / file_name, encoding="utf-8") as fp:
            reader = csv.reader(fp)

            try:
                next(reader)
            except StopIteration:
                raise EmptyRCFile(f"Arquivo {path}_RC.txt RC está vazio.") from StopIteration

            i_s, t_s, rc_mc_s, rc_r_s = [], [], [], []
            for line in reader:
                words = line[0].split()
                istep = int(words[0])
                t, rc_mc, rc_r = map(float, (words[1], words[3], words[-1]))

                i_s.append(istep)
                t_s.append(t)
                rc_mc_s.append(rc_mc)
                rc_r_s.append(rc_r)

        return RCResults(
            istep=np.array(i_s),
            t=np.array(t_s),
            rc_mhor_coulomb=np.array(rc_mc_s),
            rc_rankine=np.array(rc_r_s),
        )
    except FileNotFoundError as e:
        raise RCFileNotFound(f"Arquivo '{e.filename}' não foi achado.") from FileNotFoundError
