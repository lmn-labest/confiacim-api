from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from confiacim.controllers.dist import dist as dist_controller
from confiacim.erros import (
    InputDirNotExists,
    MatplotlibModuleError,
    VarNameNotFoundAtCaseFileError,
)
from confiacim.logger import get_logger
from confiacim.plot.graphs import dist_cdf, dist_pdf, dist_ppf

dist_app = typer.Typer()

logger = get_logger()

console = Console()


@dist_app.command()
def pdf(
    var_name: Annotated[str, typer.Argument(..., help="Nome da váriavel desejada.")],
    input_dir: Annotated[Path, typer.Argument(..., help="Diretório dos arquivos de entra.")],
):
    """Plotando a pdf da variável desejada."""
    try:
        dist_controller(input_dir=input_dir, var_name=var_name, function_plot=dist_pdf)

    except (InputDirNotExists, VarNameNotFoundAtCaseFileError, MatplotlibModuleError) as e:
        console.print(f"[red]Error[/red]: {e}")
        logger.error(e)
        raise typer.Exit(1) from e


@dist_app.command()
def cdf(
    var_name: Annotated[str, typer.Argument(..., help="Nome da váriavel desejada.")],
    input_dir: Annotated[Path, typer.Argument(..., help="Diretório dos arquivos de entra.")],
):
    """Plotando a cdf da variável desejada."""

    try:
        dist_controller(input_dir=input_dir, var_name=var_name, function_plot=dist_cdf)

    except (InputDirNotExists, VarNameNotFoundAtCaseFileError, MatplotlibModuleError) as e:
        console.print(f"[red]Error[/red]: {e}")
        logger.error(e)
        raise typer.Exit(1) from e


@dist_app.command()
def ppf(
    var_name: Annotated[str, typer.Argument(..., help="Nome da váriavel desejada.")],
    input_dir: Annotated[Path, typer.Argument(..., help="Diretório dos arquivos de entra.")],
):
    """Plotando a ppf da variável desejada."""

    try:
        dist_controller(input_dir=input_dir, var_name=var_name, function_plot=dist_ppf)

    except (InputDirNotExists, VarNameNotFoundAtCaseFileError, MatplotlibModuleError) as e:
        console.print(f"[red]Error[/red]: {e}")
        logger.error(e)
        raise typer.Exit(1) from e
