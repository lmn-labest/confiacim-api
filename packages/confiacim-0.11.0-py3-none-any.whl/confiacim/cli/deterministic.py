from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console

from confiacim.controllers.deterministic import new_max_step as new_max_step_controller
from confiacim.controllers.deterministic import run as run_controller
from confiacim.erros import (
    CaseFileNotFound,
    EmptyRCFile,
    InputDirNotExists,
    InvalidDistributionError,
    MatplotlibModuleError,
    NeedBeAFileNotDir,
    PropValueMissingError,
    RCFileNotFound,
    TencimRunError,
    VariableTemplateError,
)
from confiacim.logger import get_logger
from confiacim.plot.graphs import deterministic_rcs
from confiacim.simulation_config import (
    JsonIndentValueError,
    ResultFilesInvalidOptionError,
)
from confiacim.timer import Timer
from confiacim.variables.weibull_params import NoConvergenceWeibullParams

determ_app = typer.Typer()
logger = get_logger()

console = Console()


@determ_app.command(name="run")
def cli_run(
    input_dir: Annotated[Path, typer.Argument(..., help="Diretório dos arquivos de entra.")],
    output_dir: Annotated[Optional[Path], typer.Argument(..., help="Diretório dos arquivos de saida.")] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Modo verboso.")] = False,
):
    """
    Comando que executa o Tencim para análise derministica. Os arquivo de entrada
    serão gerados utilizando os templates com as médias das variaveis que estão
    definidos no arquivo case.yaml.
    """

    try:
        with Timer("Determinist Analysis"):
            run_controller(input_dir=input_dir, output_dir=output_dir, verbose=verbose)
    except InputDirNotExists as e:
        console.print(f"[red]Error[/red]: {e}")
        logger.error(e)
        raise typer.Exit(1) from e

    except TencimRunError as e:
        console.print(f"[red]Error[/red]: Erro no tencim\n{e}")
        logger.error("Erro no tencim. Ver simulation.log para mais informações.")
        logger_simulation = get_logger("simulation")
        logger_simulation.error(e)
        raise typer.Exit(1) from e

    except (
        InvalidDistributionError,
        PropValueMissingError,
        VariableTemplateError,
        NoConvergenceWeibullParams,
        JsonIndentValueError,
        ResultFilesInvalidOptionError,
    ) as e:
        console.print(f"[red]Error[/red]: {e}")

        logger.error("Erro na simulação. Ver simulation.log para mais informações.")

        logger_simulation = get_logger(name="simulation")
        logger_simulation.error(e)
        raise typer.Exit(1) from e


@determ_app.command(name="plot")
def plot(
    output_dir: Annotated[Path, typer.Argument(..., help="Diretório dos arquivos de saida.")],
    save: Annotated[bool, typer.Option("--save", "-s", help="Salvar gráfico.")] = False,
):
    """Plota o RC da analise terministica"""
    try:
        deterministic_rcs(output_dir=output_dir, save=save)
    except (RCFileNotFound, EmptyRCFile, MatplotlibModuleError) as e:
        console.print(f"[red]Error[/red]: {e}")
        logger.error(e)
        raise typer.Exit(1) from e


@determ_app.command(name="new_last_step")
def cli_new_last_step(
    step: Annotated[int, typer.Argument(..., help="Passo de tempo que será truncada simulação.")],
    case_path: Annotated[
        Path, typer.Argument(..., help="Caminho para o arquivo principal da simulação (e.g. case.dat).")
    ],
):
    """Comando que gera um novo arquivo case.dat com a simulação truncada no passo de tempo informado."""
    try:
        new_max_step_controller(case_path=case_path, step=step)
    except (CaseFileNotFound, NeedBeAFileNotDir) as e:
        console.print(f"[red]Error[/red]: {e}")
        logger.error(e)
        raise typer.Exit(1) from e
