"""
Modulo que gera as tables para `CLI`.

Classes e funções deste módulo:

- confiam_configs
- convergence
- correlation
- form_final_stats
- form_sensitity
- form_simulation_configs
- minimal_rcs
- samples_it_rcs
- variables
- variables_vector

---
"""

import numpy as np
from rich.table import Table

from confiacim.conf import Settings, TencimExcMode
from confiacim.form.model import FormResult
from confiacim.monte_carlo.model import MonteCarloResult
from confiacim.tencim.rc import TimeMinimalRC
from confiacim.variables.core import StochasticVariable


def monte_carlo_final_results(results: MonteCarloResult) -> Table:
    """
    Imprime tabela com o resultado final no Monte Carlo.

    Parameters:
        results: probabilidade de falha do **MONTE Carlo**.

    Returns:
        A tabela pronta.
    """

    table = Table(title="Monte Carlo Results")

    table.add_column("Samples Number", justify="center", style="cyan")
    table.add_column("Fail", justify="center", style="magenta")
    table.add_column("P(%)", justify="center", style="magenta")
    table.add_column("Estimator", justify="center", style="magenta")

    table.add_row(
        f"{results.total}",
        f"{results.fail}",
        f"{results.P:.4%}",
        f"{results.estimator:.4e}" if results.estimator else "unavailable",
    )

    return table


def convergence(beta: float, res: float, title: str) -> Table:
    """
    Imprime tabela de convergencia.

    Parameters:
        beta: Paramentro do **FORM**.
        res: Residuo do **FORM**.
        title: titulo da tabela.

    Returns:
        A tabela pronta.
    """

    table = Table(title=title)

    table.add_column("beta", justify="center", style="cyan")
    table.add_column("res", justify="center", style="magenta")

    table.add_row(f"{beta:.3e}", f"{res:.3e}")

    return table


def correlation(variable_names: tuple[str, ...], ro: np.ndarray) -> Table:
    """
    Imprime tabela com as matrix de correlação.

    Parameters:
        variable_names: Tupla com os names variaveis aleatórias.
        ro: Matriz de correlação.

    Returns:
        A tabela pronta.
    """

    table = Table(title="Matrix Correlations")

    table.add_column(" ", justify="left", style="green")
    for name in variable_names:
        table.add_column(name, justify="center", style="cyan")

    for i, n in enumerate(variable_names):
        table.add_row(n, *list(map(lambda s: f"{s:6.3f}", ro[i, :])))

    return table


def samples_it_rcs(rcs: dict) -> Table:
    """
    Imprime tabela de RCs.

    Parameters:
        rcs: RCs da simulação.

    Returns:
        A tabela pronta.
    """

    table = Table(title="RCs")

    table.add_column("sample", justify="right", style="cyan", no_wrap=True)
    table.add_column("RC min", style="magenta")
    table.add_column("RC last", style="green")

    for k, v in rcs.items():
        table.add_row(k, str(v["min"]), str(v["last"]))

    return table


def form_final_stats(results: FormResult) -> Table:
    """
    Imprime tabela com a porcetangem final de falha.

    Parameters:
        results: Resultados da simulação.

    Returns:
        A tabela pronta.
    """

    table = Table(title="Final Result")

    beta, resid, Pf, it = (
        results.beta,
        results.resid,
        results.Pf,
        results.it,
    )

    table.add_column("it", justify="center", style="green")
    table.add_column("beta", justify="center", style="cyan")
    table.add_column("resid", justify="center", style="magenta")
    table.add_column("Pf", justify="center", style="cyan")
    table.add_column("Pf(%)", justify="center", style="magenta")

    table.add_row(f"{it}", f"{beta:.3e}", f"{resid:.3e}", f"{Pf:.3e}", f"{100*Pf:.2f}%")

    return table


def form_sensitity(variables: tuple[str, ...], results: FormResult) -> Table:
    """
    Imprime tabela com as importancia e fatores de omissão.

    Parameters:
        variables: Tupla com o nome das variaveis.
        results: Resultados da simulação.

    Returns:
        A tabela pronta.
    """

    table = Table(title="Final Sensitivity")

    importance = results.importance_factors
    omission = results.omission_factors

    table.add_column("Variables", justify="right", style="cyan", no_wrap=True)
    table.add_column("Importance(%)", style="magenta", justify="center")
    table.add_column("Omission", style="green", justify="center")

    for v, i, o in zip(variables, importance, omission):
        table.add_row(v, f"{i:.3f}", f"{o:.3f}")

    return table


def form_simulation_configs(configs: dict) -> Table:
    """
    Imprime tabela com as configurações do **FORM**.

    Parameters:
        configs: Configurações do lidas do arquivo `*.yaml`.

    Returns:
        A tabela pronta.
    """

    table = Table(title="Configs")

    table.add_column("Name", justify="left", style="green")
    table.add_column("Value", justify="left", style="green")

    if form := configs.get("form"):
        table.add_row("beta", str(form["beta"]))
        table.add_row("delta", str(form["delta"]))
        table.add_row("gamma", str(form["gamma"]))
        table.add_row("tol", str(form["tol"]))
        table.add_row("maxit", str(form["maxit"]))

    table.add_row("result_files", str(configs["result_files"]))
    table.add_row("json_indent", str(configs["json_indent"]))

    return table


def minimal_rcs(minamal_rcs: dict[str, TimeMinimalRC]) -> Table:
    """
    Imprime tabela RCs da simulçãao deterministica.

    Parameters:
        minamal_rcs: Informações do `RCs` minimos da sumulação deterministica.

    Returns:
        A tabela pronta.
    """

    table = Table(title="Minimal RCs")

    table.add_column("Name", justify="left", style="green")
    table.add_column("istep", justify="center", style="cyan")
    table.add_column("t(s)", justify="center", style="cyan")
    table.add_column("t(h)", justify="center", style="cyan")
    table.add_column("RC", justify="center", style="cyan")

    table.add_row(
        "Mhor Coulomb",
        str(minamal_rcs["rc_mohr_coulomb"].istep),
        str(minamal_rcs["rc_mohr_coulomb"].t),
        str(round(minamal_rcs["rc_mohr_coulomb"].t / 3600, 2)),
        str(minamal_rcs["rc_mohr_coulomb"].rc),
    )

    table.add_row(
        "Rankine",
        str(minamal_rcs["rc_rankine"].istep),
        str(minamal_rcs["rc_rankine"].t),
        str(round(minamal_rcs["rc_rankine"].t / 3600, 2)),
        str(minamal_rcs["rc_rankine"].rc),
    )

    return table


def confiam_configs(settings: Settings) -> Table:
    """
    Imprime tabela com as configurações do `confiacim`.

    Parameters:
        settings: Configurações do `confiacim`.

    Returns:
        A tabela pronta.
    """

    table = Table(title="Settings")

    table.add_column("Variabel Name", justify="left", style="green")
    table.add_column("Value", justify="left", style="cyan")
    for k, v in settings.model_dump().items():
        if k == "EXEC_TENCIM_MODE":
            table.add_row(k, TencimExcMode.name_by_value(int(v)))
            continue
        table.add_row(k, str(v))

    return table


def variables(variables: tuple[StochasticVariable, ...]) -> Table:
    """
    Imprime tabela com a variaveis aleatórias.

    Parameters:
        variables: Tupla com as variaveis aleatórias.

    Returns:
        A tabela pronta.
    """

    table = Table(title="Variables")

    table.add_column("Ord", justify="center", style="green")
    table.add_column("Name", justify="left", style="cyan")
    table.add_column("Dist", justify="center", style="cyan")
    table.add_column("Mean", justify="center", style="cyan")
    table.add_column("Std", justify="center", style="cyan")
    for i, v in enumerate(variables, start=1):
        table.add_row(str(i), v.name, str(v.dist), f"{v.mean:.4e}", f"{v.std:.4e}")

    return table


def variables_vector(Un: np.ndarray, variables: dict[str, float], title: str) -> Table:
    """
    Imprime as varaiveis aleatorias.

    Parameters:
        Un: Array com variaveis normalizadas.
        variables: Dicionário variaveis não-normalizadas.
        title: titulo da tabela.

    Returns:
        A tabela pronta.
    """
    table = Table(title=title)

    table.add_column("i", justify="center", style="cyan")
    table.add_column("names", justify="left", style="green")
    table.add_column("internal values", justify="center", style="magenta")
    table.add_column("values", justify="center", style="magenta")

    for i, (un, (n, u)) in enumerate(zip(Un, variables.items())):
        table.add_row(str(i + 1), n, f"{un:.3e}", f"{u:.3e}")

    return table
