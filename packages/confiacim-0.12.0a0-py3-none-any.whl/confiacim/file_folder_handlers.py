"""Modulo com funções de apoio de manipulação de arquivos e diretórios."""

import os
import shutil
import sys
from glob import glob
from pathlib import Path
from tempfile import TemporaryDirectory
from time import sleep

from .erros import TencimExecNotFound
from confiacim.conf import settings


def abs_original_dir() -> Path:
    """
    Retorna o caminho absoluto de diretório

    Returns:
        Caminho completo
    """
    return Path.cwd()


def base_work_tmpdir(origin_dir: Path) -> TemporaryDirectory:
    """
    Gera o diretório temporátio base.

    Parameters:
        origin_dir: Ditetorio base

    Returns:
        Caminho completo do diretório temporário.
    """

    return TemporaryDirectory(dir=origin_dir)


def check_tencim_exec(path: Path) -> None:
    """
    Verificar se exite um excutavel do tencim1D no diretorio.

    Parameters:
        path: Caminho do diretório.

    Raises:
        TencimExecNotFound: Tencim não foi achado no diretório informado
    """

    full_path = path / settings.EXEC_TENCIM_BIN
    if not full_path.exists():
        raise TencimExecNotFound(f"Executavel do tencim não foi encontarado: O local de busca foi: {full_path}.")


def clean_input_files_after_run(files: list[Path]) -> None:
    """
    Apaga uma lista de arquivos.

    Parameters:
        files: Lista de arquivos
    """
    for p in files:
        os.remove(p)


def copy_exec_tencim(src_exec: Path, dest_folder: Path) -> None:
    """
    Copia o `tencim` para uma pasta.

    Parameters:
        src_exec: Diretório onde estáa o `tencim`.
        dest_folder: Pasta de destino
    """
    src, dest = (
        src_exec / settings.EXEC_TENCIM_BIN,
        dest_folder / settings.EXEC_TENCIM_BIN,
    )

    copy_file(src, dest)


def copy_file(src: Path | str, dest: Path) -> None:
    """
    Copia um arquivo de um local para outro.

    Parameters:
        src: Caminho do arquivo
        dest: Destino para onde será copiado o arquivo
    """
    try:
        shutil.copy(src, dest)
    except FileNotFoundError:
        os.makedirs(os.path.dirname(dest))
        shutil.copy(src, dest)


def copy_list_files(files: list[Path], dest_folder: Path) -> None:
    """
    Copia uma lista de arquivos para um destinho.

    Parameters:
        files: Lista dos arquivos.
        dest_folder: Diretório de destino.
    """
    for f in files:
        copy_file(f, dest_folder / f.name)


def exec_dir(origin_dir: Path) -> Path:
    """
    Diretório onde o tencim está.

    Parameters:
        origin_dir: Caminho base

    Returns:
        Caminho absoluto do diretório do tencim
    """
    return Path(origin_dir / settings.EXEC_TENCIM_DIR)


def iteration_folder(iteration: int) -> Path:
    """
    Gera o nome da pasta de iteração no formato `it_0000`.

    Parameters:
        iteration: Número da iteração.

    Returns:
        Retorno um pasta no formato `it_0001`.

    """

    return Path(f"it_{iteration:04d}")


def get_template_dir(files_path: Path) -> Path:
    """
    Caminho dos arquivos de template

    Paramenters:
        files_path: Caminho base dos arquivos de simulação

    Returns:
        Retornar o camninho dos templates
    """
    return files_path / "templates/"


def list_files(path: Path, patterns: str | list[str]) -> list[Path]:
    """
    Lista todos os arquivos em um diretório que com um deterrminado padrão.

    Parameters:
        path: caminho do diretório.
        patterns: Lista dos padrões.

    Returns:
        Lista com os diretorios.
    """
    match patterns:
        case list():
            list_ = [Path(f) for m in patterns for f in glob(str(path / m))]
        case str():
            list_ = list(map(Path, glob(str(path / patterns))))
        case _:
            list_ = []
    return list_


def tmp_workdir(tmpdir: TemporaryDirectory, sample_name: str) -> Path:
    """
    Diretório temporário onde a amastra irá roda.

    Parameters:
        tmpdir: Diretório temporário.
        sample_name: Nome da amostra.

    Returns:
        Camminho completo do diretório temporário.
    """

    return Path(tmpdir.name) / sample_name


def list_only_dirs(path: Path) -> list[Path]:
    """
    Lista apenas diretórios.

    Parameters:
        path: caminho do diretório.

    Returns:
        Lista com os caminhos.
    """
    return [d for d in path.iterdir() if d.is_dir()]


def default_output_dir(input_dir: Path) -> Path:
    """
    Gera o caminho padrão do diretório de saida.

    Parameters:
        input_dir: caminho do diretório de entrada.

    Returns:
        Caminho do diretório de saida.
    """
    return input_dir / "output"


def clean_temporary_dir(tmpdir: TemporaryDirectory):
    """Limpa o diretório temporario

    Parameters:
        tmpdir: Diretorio temporario
    """

    # No windows as vezes temos um problema de permissão
    # na hora de deletar executável do tencim por ele
    # ainda estar associado ao outro processo.
    if sys.platform.startswith("win"):
        attempts = 1
        while attempts < 11:
            try:
                tmpdir.cleanup()
                break
            except NotADirectoryError:
                # TODO: coloca isso no log
                # console.print(f"[red]Tentativa: {attempts} - Esperando {0.05 * attempts} segundos[/red]")
                sleep(0.05 * attempts)
                attempts += 1
    else:
        tmpdir.cleanup()


def result_folders(path: Path, reverse: bool = False) -> list[Path]:
    """
    Retorna somente diretorios que começam com `it_` de forma ordenada.

    Attributes:
        path: caminho do diretório.
        reverse: ordem da listagem.

    Returns:
        Lista com os diretórios.
    """

    dirs = [abs_path for abs_path in list_only_dirs(path) if abs_path.name.startswith("it_")]

    return sorted(dirs, key=lambda x: int(x.name.split("_")[1]), reverse=reverse)
