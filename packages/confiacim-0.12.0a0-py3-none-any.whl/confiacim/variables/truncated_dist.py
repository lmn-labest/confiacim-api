"""
Módulo com a implementação da distribuição `trucandas`.

(EXPERIMENTAL)

"""

from math import sqrt

from scipy.integrate import quad
from scipy.optimize import newton, toms748
from scipy.stats import lognorm


class LogNormalTrunked:
    def pdf(self, x: float, s: float, scale: float, b: float):
        """
        Função densidade de probabilidade acumulada da distruibuição `(pdf)`.

        Parameters:
            x: valor da váriavel.
            s: Parâmetro.
            scale: Parâmetro.
            b: Parâmetro limite superior.

        Returns:
            Valor da função avaliada em x.

        """

        if x > b:
            return 0.0

        return lognorm.pdf(x, s=s, scale=scale) / lognorm.cdf(b, s=s, scale=scale)

    def cdf(self, x: float, s: float, scale: float, b: float):
        """
        Função densidade de probabilidade acumulada da distruibuição `(cdf)`.

        Parameters:
            x: valor da váriavel.
            s: Parâmetro.
            scale: Parâmetro.
            b: Parâmetro limite superior.

        Returns:
            Valor da função avaliada em x.

        """
        if x > b:
            return 1.0

        return lognorm.cdf(x, s=s, scale=scale) / lognorm.cdf(b, s=s, scale=scale)

    def ppf(self, p: float, s: float, scale: float, b: float):
        """
        Inversa da função densidade de probabilidade acumulada da distruibuição `(ppf)`.

        Parameters:
            p: valor da probabilidade.
            s: Parâmetro.
            scale: Parâmetro.
            b: Parâmetro limite superior.

        Returns:
            Valor da função avalida em p.
        """
        return self._ppf_numeric(p, s, scale, b)

    def mean(self, s: float, scale: float, b: float):
        """
        Cálculo da média.

        Parameters:
            s: Parâmetro.
            scale: Parâmetro.
            b: Parâmetro limite superior.

        Returns:
            Valor da média.
        """
        return self._mean_numeric(s=s, scale=scale, b=b)

    def std(self, s: float, scale: float, b: float) -> float:
        """
        Cálculo do desvio padrão.

        Parameters:
            s: Parâmetro.
            scale: Parâmetro.
            b: Parâmetro limite superior.

        Returns:
            Valor da desvio padrão.
        """
        return self._std_numeric(s=s, scale=scale, b=b)

    def _mean_numeric(self, s: float, scale: float, b: float):
        result = quad(lambda x: x * self.pdf(x, s, scale, b), 0.0, b, limit=500)

        if result[1] > 1.0e-4:
            print(f"Problema na convergencia da integral {result[1]}")

        return result[0]

    def _std_numeric(self, s: float, scale: float, b: float) -> float:
        result = quad(lambda x: x * x * self.pdf(x, s, scale, b), 0.0, b, limit=500)

        mean = self.mean(s, scale, b)

        if result[1] > 1.0e-4:
            print(f"Problema na convergencia da integral {result[1]}")

        var = result[0] - mean * mean

        return sqrt(var)

    def _ppf_numeric(self, p: float, s: float, scale: float, b: float):
        """
        Cálculo analítico da densidade de probabilidade acumulada inversa.

        Parameters:
            p: Valor da probabilidade.
            s: Parâmetro.
            scale: Parâmetro.
            b: Parâmetro limite superior.

        Returns
            Retorna o valor de ppf(p)
        """

        f = lambda x: self.cdf(x, s, scale, b) - p  # noqa

        r = toms748(f, a=0, b=b, rtol=1e-6)
        if abs(f(r)) > 1e-10:
            r = newton(f, r, maxiter=1_000, tol=1e-14)

        return r


lognorm_t = LogNormalTrunked()
