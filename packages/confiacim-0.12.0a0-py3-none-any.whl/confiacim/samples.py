"""
Módulo que gerência as amostras

Classes e funções deste módulo:

- Sample
- SamplesGeneratorForm
- sample_averages
- generate_seeds

---
"""

import random
from collections import OrderedDict
from dataclasses import dataclass

import numpy as np
from scipy.stats import uniform

from confiacim.erros import InvalidStochasticVar
from confiacim.variables.core import StochasticVariable


@dataclass(frozen=True)
class Sample:
    """
    Classe da amosta

    Parameters:
        name:  nome da amostra
        averages: medias da amostra
    """

    name: str
    averages: dict

    def __getitem__(self, key):
        try:
            return self.averages[key]
        except KeyError:
            raise InvalidStochasticVar(f"{key} não é uma variavel estocástica registrada.") from KeyError

    def __setitem__(self, key, value):
        self.averages[key] = value


@dataclass
class SamplesGeneratorForm:
    """
    Classe pra gerar as amostras:

    Parameters:
        avg:  Dicionario com as médias
        delta: delta usado para calcular as novas médias
    """

    avg: dict  # TODO: melhora esse nome
    delta: float = 0.01

    def mk_sample(self, var_name: str) -> Sample:
        """
        Gera uma amostra.

        Parameters:
            var_name: Nome da variável aleatoria.

        Returns:
            Retorna a amostra
        """
        new_avg = self.avg.copy()

        sp = Sample(name=var_name, averages=new_avg)  # TODO: isso aqui está estranho. Refazer depois
        sp[var_name] *= 1.0 + self.delta

        return Sample(name=var_name, averages=new_avg)

    def mk_sample_base(self) -> Sample:
        """
        Gera um amostrar base.

        Returns:
            Retorna a amostra base
        """
        new_avg = self.avg.copy()
        return Sample(name="base", averages=new_avg)

    def all(self) -> list[Sample]:
        """
        Gera todas as amostras.

        Returns:
            Retorna a amostra base
        """

        samples = [self.mk_sample_base()]
        samples.extend(self.mk_sample(k) for k in self.avg)

        return samples


def sample_averages(variables: tuple[StochasticVariable, ...]) -> dict[str, float]:
    """
    Gera um dicionário com as médias das variaveis.

    Parameters:
        variables: Lista de variaveis.

    Returns:
        Retorna um dicionário ordenando.
    """

    return OrderedDict({v.name: v.mean for v in variables})


@dataclass(frozen=True)
class SamplesGeneratorMonteCarlo:
    """
    Classe pra gerar as amostras para o Monte Carlo:

    Parameters:
        variables: Lista de variáveis
        n_samples: Número de amostras
        L: Parte inferior da fatoração **Cholesky** da matriz de correlação.
        seeds: Lista com as sementes
    """

    variables: tuple[StochasticVariable, ...]
    n_samples: int
    L: np.ndarray
    seeds: list[int] | None = None

    def all(self) -> list[Sample]:
        n_vars = len(self.variables)

        u = np.zeros((n_vars, self.n_samples))

        #     | a1 a2 ... an_samples]
        # u = | b1 b2 ... bn_samples]
        #     | c1 c2 ... cn_samples]
        if self.seeds:
            for n in range(n_vars):
                u[n, :] = uniform.rvs(size=self.n_samples, random_state=self.seeds[n])
        else:
            for n in range(n_vars):
                u[n, :] = uniform.rvs(size=self.n_samples)

        y = self.L.dot(u)

        samples = []
        for n in range(self.n_samples):
            values = {}
            for i, v in enumerate(self.variables):
                values[v.name] = v.dist.ppf(y[i][n])

            sp = Sample(name=f"sample_{n + 1}", averages=values)

            samples.append(sp)

        return samples


def generate_seeds(*, seed: int | None = None, n: int) -> list[int]:
    """
    Gerar as sementes para n variáaveis:

    Parameters:
        seed: Sementes.
        n: Número de sementes

    Returns:
        Retorna uma tupla com N sementes.
    """
    if seed:
        random.seed(seed)

    return [int.from_bytes(random.randbytes(4), "big") for _ in range(n)]
