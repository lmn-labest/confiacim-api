"""Modulo com as funcionalidades para rodar o `tencim` de forma standalone."""

from pathlib import Path

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from confiacim.file_folder_handlers import (
    abs_original_dir,
    base_work_tmpdir,
    check_tencim_exec,
    clean_temporary_dir,
    copy_exec_tencim,
    copy_list_files,
    exec_dir,
    list_files,
)
from confiacim.tencim.runner import TencimStandaloneRunner
from confiacim.verbose import VerboseLevel


def run_tencim(
    *,
    input_dir: Path,
    output_dir: Path,
    verbose_level: int,
    console: Console | None = None,
):
    """
    Rodando a tencim standalone.

    Parameters:
        input_dir: Ditetório do arquivo de entrada.
        output_dir: Ditetório do arquivo de saida.
        verbose_level: Nivel de verbosidade.

    Info:
        A verbosidade pode ser:

        - 0 - Nenhuma
        - 1 - Moderada
        - 2 - Alta
    """

    verbose = verbose_level == VerboseLevel.LEVEL_2

    original_dir = abs_original_dir()  # TODO: Melhorar o nome dessa função
    src_exec_dir = exec_dir(original_dir)  # TODO: Melhorar o nome dessa função
    tmpdir = base_work_tmpdir(original_dir)

    # TODO: Codigo repetido
    if input_dir.is_absolute():
        abs_path_input_dir = input_dir
    else:
        abs_path_input_dir = original_dir / input_dir

    if output_dir.is_absolute():
        abs_path_output_dir = output_dir
    else:
        abs_path_output_dir = original_dir / output_dir

    # TODO: botar isso na classe TencimRunner
    check_tencim_exec(src_exec_dir)

    # setup
    workdir = Path(tmpdir.name)

    copy_exec_tencim(src_exec_dir, workdir)

    if verbose and console:
        console.print("Copy Tencim files ...", style="green")

    input_files = list_files(abs_path_input_dir, "*.dat")
    copy_list_files(input_files, workdir)

    runner = TencimStandaloneRunner(
        output_base_dir=abs_path_output_dir,
        origin_dir=original_dir,
        workdir=workdir,
    )

    # TODO: Codigo repetido
    progressbarDisable = verbose_level == VerboseLevel.LEVEL_0 or verbose_level == VerboseLevel.LEVEL_2

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}\n"),
        transient=True,
        disable=progressbarDisable,
    ) as progress:
        progress.add_task(description="Running...", total=None)
        if verbose and console:
            console.print("Running tencim ...", style="green")
        runner.run()

    # TODO: Transformar isso em um função
    if verbose and console:
        console.print("Clean files ...", style="green")

    clean_temporary_dir(tmpdir)
