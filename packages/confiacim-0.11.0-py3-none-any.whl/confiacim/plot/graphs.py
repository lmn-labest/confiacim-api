"""
Modulo com as funções que plotam os gráficos

Classes e funções deste módulo:

- rc_all_matplotlib
- rc_it_matplotlib
- deterministic_rcs
- rc_all_plotly
---
"""

from itertools import cycle
from math import ceil
from pathlib import Path

import numpy as np

from confiacim.tencim.rc import first_timestamp_minimal_rc

try:
    import matplotlib.pyplot as plt
except ModuleNotFoundError:
    plt = None  # type: ignore[assignment]

try:
    import plotly.graph_objects as go
    from plotly.colors import cyclical
except ModuleNotFoundError:
    go = None  # type: ignore[assignment]


from confiacim.erros import (
    DirsResultsNotFound,
    ItFolderNotFound,
    MatplotlibModuleError,
    PlotlyModuleError,
    SimulationFolderNotFound,
)
from confiacim.file_folder_handlers import iteration_folder
from confiacim.plot.results import list_only_dirs, read_results, result_folders
from confiacim.variables.core import StochasticVariable


def _rc_max_min(s: Path, max_: None | np.ndarray, min_: None | np.ndarray) -> tuple:
    rc_results = read_results(s)
    max_ = rc_results.rc_mhor_coulomb if max_ is None else np.maximum(max_, rc_results.rc_mhor_coulomb)
    min_ = rc_results.rc_mhor_coulomb if min_ is None else np.minimum(min_, rc_results.rc_mhor_coulomb)

    return rc_results.t / 3600, max_, min_


def get_max_min_rc_from_files(dir_results: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Plota os gráficos de `RC` de todas as simulações.

    Parameters:
        dir_results: Diretórios dos resultados.

    Raises:
        EmptyRCFile: O arquivo `RC` está vazio.
        RCFileNotFound: O arquivo `RC` não encontrado.
    """

    max_, min_ = None, None
    for s in list_only_dirs(dir_results):
        t, max_, min_ = _rc_max_min(s, max_, min_)

    return t, np.array(max_), np.array(min_)


def rc_all_matplotlib(output_dir: Path, save: bool) -> None:
    """
    Plota os graficos de `RC` de todas as simulações.

    Info:
        Usa o matplotlib.

    Parameters:
        output_dir: Diretório onde a análise esta.
        save: Flag par salvar o gráfico em um arquivo.

    Raises:
        DirsResultsNotFound: Nenhum diretório de resultados achado.
        RCFileNotFound: O arquivo `RC` não encontrado.
        MatplotlibModuleError: Matplotlib não instalado.
        SimulationFolderNotFound: A pasta da simulação não foi encontrado.
    """

    if not plt:
        raise MatplotlibModuleError("É necessário instalar o matplotlib.")

    _, ax = plt.subplots()
    try:
        results = result_folders(output_dir)
    except FileNotFoundError:
        raise SimulationFolderNotFound(output_dir)

    if not results:
        raise DirsResultsNotFound(output_dir)

    labels = []
    for d in results:
        t, max_, min_ = get_max_min_rc_from_files(d)

        plt.plot(t, min_, color="grey", ls="--", lw=0.5)
        plt.plot(t, max_, color="grey", ls="--", lw=0.5)
        plt.fill_between(t, min_, max_, cmap="viridis", label=d.name, alpha=0.6)
        labels.append(d.name)

    ax.set_title("FORM Simulation")
    ax.legend(ncols=2, labels=labels)
    ax.spines["right"].set_color("none")
    ax.spines["top"].set_color("none")
    ax.spines["bottom"].set_color("gray")
    ax.spines["left"].set_color("gray")
    ax.grid(c="gray", ls="--")
    ax.set_xlabel("Time(h)")
    ax.set_xlim(0, ceil(max(t)))
    ax.set_ylim(-100, 100)
    ax.set_ylabel("RC Mhor-Coulomb")

    if save:
        save_dir = output_dir / "graphs"
        save_dir.mkdir(exist_ok=True)
        plt.savefig(save_dir / "all_RC.png")

    plt.show()


def rc_it_matplotlib(it: int, output_dir: Path, save: bool) -> None:
    """
    Plota os graficos de `RC` da iteralção `it`.

    Info:
        Usa o `matplotlib`

    Parameters:
        it: Número da iteração.
        output_dir: Diretório onde a análise esta.
        save: Flag par salvar o gráfico em um arquivo.

    Raises:
        ItFolderNotFound: Diretório da iteração nnão foi achado.
        RCFileNotFound: O arquivo `RC` não encontrado.
        MatplotlibModuleError: Matplotlib não instalado.
    """
    if not plt:
        raise MatplotlibModuleError("É necessário instalar o matplotlib.")

    _, ax = plt.subplots()

    path = output_dir / iteration_folder(it)

    try:
        t, max_, min_ = get_max_min_rc_from_files(path)
    except FileNotFoundError as e:
        raise ItFolderNotFound(e.filename) from FileNotFoundError

    plt.plot(t, min_, color="grey")
    plt.plot(t, max_, color="grey")
    plt.fill_between(t, min_, max_, alpha=0.8)

    ax.set_title(f"FORM Iteration {it}")
    ax.spines["right"].set_color("none")
    ax.spines["top"].set_color("none")
    ax.spines["bottom"].set_color("gray")
    ax.spines["left"].set_color("gray")
    ax.grid(c="gray", ls="--")
    ax.set_xlabel("Time(h)")
    ax.set_xlim(0, ceil(max(t)))
    ax.set_ylim(-100, 100)
    ax.set_ylabel("RC Mhor-Coulomb")

    if save:
        save_dir = output_dir / "graphs"
        save_dir.mkdir(exist_ok=True)
        plt.savefig(save_dir / f"it_{it:04d}_RC.png")

    plt.show()


def deterministic_rcs(*, output_dir: Path, save: bool = False) -> None:
    """
    Plota o grafico de `RC` da analise deterministica

    Info:
        Usa o `matplotlib`

    Parameters:
        output_dir: Diretório onde a análise esta.
        save: Flag par salvar o gráfico em um arquivo.

    Raises:
        RCFileNotFound: O arquivo `RC` não encontrado.
        EmptyRCFile: O Arquivo `RC`esta vazio.
        MatplotlibModuleError: Matplotlib não instalado.

    """
    if not plt:
        raise MatplotlibModuleError("É necessário instalar o matplotlib.")

    _, ax = plt.subplots()

    rc_path = output_dir / "deterministic/"

    results = read_results(rc_path)

    rcs = first_timestamp_minimal_rc(results)

    plt.plot(results.t, results.rc_mhor_coulomb, color="blue", label="Mhor Coulomn")
    plt.plot(results.t, results.rc_rankine, color="red", label="Rankine")

    ax.spines["right"].set_color("none")
    ax.spines["top"].set_color("none")
    ax.spines["bottom"].set_color("gray")
    ax.spines["left"].set_color("gray")

    ax.vlines(x=rcs["rc_mhor_coulomb"].t, ymin=-200, ymax=200, ls="--", color="blue", lw=0.5)
    ax.vlines(x=rcs["rc_rankine"].t, ymin=-200, ymax=200, ls="--", color="red", lw=0.5)

    ax.set_title("Deterministic Analysis")
    ax.grid(c="gray", ls="--")
    ax.set_xlabel("Time(h)")
    ax.set_xlim(0, ceil(max(results.t)))
    ax.set_ylim(-125, 125)
    ax.set_ylabel("RC")
    ax.legend(ncols=1, labels=["Mhor Coulomn", "Rankine"])

    if save:
        save_dir = output_dir / "graphs"
        save_dir.mkdir(exist_ok=True)
        plt.savefig(save_dir / "deterministic_RC.png")

    plt.show()


def rc_all_plotly(output_dir: Path) -> None:
    """
    Plota os graficos de `RC` de todas as simulações.

    Info:
        Usa o `plotly`

    Parameters:
        output_dir: Diretório onde a análise esta.

    Raises:
        ItFolderNotFound: Diretório da iteração nnão foi achado.
        RCFileNotFound: O arquivo `RC` não encontrado.
        PlotlyModuleError: Plotly não instalado.
        SimulationFolderNotFound: A pasta da simulação não foi encontrado.
    """

    if not go:
        raise PlotlyModuleError("É necessário instalar o plotly.")

    try:
        results = result_folders(output_dir)
    except FileNotFoundError:
        raise SimulationFolderNotFound(output_dir)

    if not results:
        raise DirsResultsNotFound(output_dir)

    colors = cycle(cyclical.HSV)

    fig = go.Figure()

    for d in results:
        max_, min_ = None, None
        for s in list_only_dirs(d):
            t, max_, min_ = _rc_max_min(s, max_, min_)
        t, max_, min_ = get_max_min_rc_from_files(d)
        color = next(colors)
        fig.add_trace(
            go.Scatter(
                x=t,
                y=min_,
                name=f"Min({d.name})",
                line_color=color,
            )
        )
        fig.add_trace(
            go.Scatter(
                x=t,
                y=max_,
                fill="tonexty",
                name=f"Max({d.name})",
                line_color=color,
                mode=None,
            )
        )

    fig.update_layout(
        xaxis_title="Time(h)",
        yaxis_title="RC Mhor-Coulomb",
        title="FORM Simulation",
        xaxis_range=[0, ceil(max(t))],
        yaxis_range=[0, 100],
    )

    fig.show()


def dist_pdf(*, variable: StochasticVariable) -> None:
    """
    Plota o grafico da `pdf` da variával.

    Info:
        Usa o `matplotlib`

    Parameters:
        variable: Variavel probabilística.

    Raises:
        MatplotlibModuleError: Matplotlib não instalado.

    """
    if not plt:
        raise MatplotlibModuleError("É necessário instalar o matplotlib.")

    _, ax = plt.subplots()

    mean_ = variable.mean
    std = variable.std

    x = np.linspace(
        mean_ - 5.0 * std,
        mean_ + 5.0 * std,
        1000,
    )

    y = [variable.dist.pdf(xi) for xi in x]

    plt.plot(x, y, color="blue")

    ax.spines["right"].set_color("none")
    ax.spines["top"].set_color("none")
    ax.spines["bottom"].set_color("gray")
    ax.spines["left"].set_color("gray")

    ax.vlines(
        x=mean_,
        ymin=-200,
        ymax=200,
        ls="--",
        color="green",
        lw=0.5,
    )

    ax.vlines(
        x=mean_ - std,
        ymin=-200,
        ymax=200,
        ls="--",
        color="red",
        lw=0.5,
    )
    ax.vlines(
        x=mean_ + std,
        ymin=-200,
        ymax=200,
        ls="--",
        color="red",
        lw=0.5,
    )

    ax.set_title(f"Variavel {variable.name} ({variable.dist_infos.name.capitalize()})")
    ax.grid(c="gray", ls="--")
    ax.set_xlabel("x")
    ax.set_xlim(mean_ - 5.0 * std, mean_ + 5.0 * std)
    ax.set_ylim(0, max(y) * 1.1)
    ax.set_ylabel("pdf")

    plt.show()


def dist_cdf(*, variable: StochasticVariable) -> None:
    """
    Plota o grafico da `cdf` da variával.

    Info:
        Usa o `matplotlib`

    Parameters:
        variable: Variavel probabilística.

    Raises:
        MatplotlibModuleError: Matplotlib não instalado.

    """
    if not plt:
        raise MatplotlibModuleError("É necessário instalar o matplotlib.")

    _, ax = plt.subplots()

    mean_ = variable.mean
    std = variable.std

    x = np.linspace(
        mean_ - 5.0 * std,
        mean_ + 5.0 * std,
        1000,
    )

    y = [variable.dist.cdf(xi) for xi in x]

    plt.plot(x, y, color="blue")

    ax.spines["right"].set_color("none")
    ax.spines["top"].set_color("none")
    ax.spines["bottom"].set_color("gray")
    ax.spines["left"].set_color("gray")

    ax.set_title(f"Variavel {variable.name} ({variable.dist_infos.name.capitalize()})")
    ax.grid(c="gray", ls="--")
    ax.set_xlabel("x")
    ax.set_xlim(mean_ - 5.0 * std, mean_ + 5.0 * std)
    ax.set_ylim(0, ceil(max(y)))
    ax.set_ylabel("cdf")

    plt.show()


def dist_ppf(*, variable: StochasticVariable) -> None:
    """
    Plota o grafico da `ppf` da variával.

    Info:
        Usa o `matplotlib`

    Parameters:
        variable: Variavel probabilística.

    Raises:
        MatplotlibModuleError: Matplotlib não instalado.

    """
    if not plt:
        raise MatplotlibModuleError("É necessário instalar o matplotlib.")

    _, ax = plt.subplots()

    mean_ = variable.mean
    std = variable.std

    p = np.linspace(0.0, 1.0, 1000)

    y = [variable.dist.ppf(pi) for pi in p]

    plt.plot(p, y, color="blue")

    ax.spines["right"].set_color("none")
    ax.spines["top"].set_color("none")
    ax.spines["bottom"].set_color("gray")
    ax.spines["left"].set_color("gray")

    ax.set_title(f"Variavel {variable.name} ({variable.dist_infos.name.capitalize()})")
    ax.grid(c="gray", ls="--")
    ax.set_xlabel("p")
    ax.set_xlim(0, 1.0)
    ax.set_ylim(mean_ - 5 * std, mean_ + 5 * std)
    ax.set_ylabel("ppf")

    plt.show()


def histogram(*, values: list[float], variable: StochasticVariable) -> None:
    """
    Plota o grafico do histagrama da variával.

    Info:
        Usa o `matplotlib`

    Parameters:
        values: Valor das amostras.
        variable: Variável probabilística.

    Raises:
        MatplotlibModuleError: Matplotlib não instalado.

    """
    if not plt:
        raise MatplotlibModuleError("É necessário instalar o matplotlib.")

    _, ax = plt.subplots()

    mean_ = variable.mean
    std = variable.std

    x = np.linspace(
        mean_ - 5.0 * std,
        mean_ + 5.0 * std,
        1000,
    )

    y = [variable.dist.pdf(xi) for xi in x]

    plt.hist(values, color="blue", density=True, bins="auto", label="hist")
    plt.plot(x, y, color="red", label="pdf")

    ax.spines["right"].set_color("none")
    ax.spines["top"].set_color("none")
    ax.spines["bottom"].set_color("gray")
    ax.spines["left"].set_color("gray")

    ax.set_title(f"Variavel {variable.name} ({variable.dist_infos.name.capitalize()})")
    ax.grid(c="gray", ls="--")
    ax.set_xlabel("x")
    ax.set_xlim(mean_ - 5.0 * std, mean_ + 5.0 * std)
    ax.set_ylim(0, max(y) * 1.1)
    ax.legend(ncols=1, labels=["hist", "pdf"])

    plt.show()
