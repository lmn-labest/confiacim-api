"""Loop principal do método **FORM**"""

from pathlib import Path

from rich.align import Align
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.text import Text
from scipy.linalg import cholesky
from scipy.stats import norm

from confiacim import tables
from confiacim.constants import COLORS, NR
from confiacim.form.correlations import generate_correlation_matrix
from confiacim.form.iteration import form_step
from confiacim.form.math_utils import (
    Ua2avgs,
    importance_factors,
    omission_factors,
    variables_mean2Ua,
)
from confiacim.form.model import FormResult
from confiacim.logger import get_logger
from confiacim.samples import SamplesGeneratorForm
from confiacim.tencim import run_samples_iteration_i
from confiacim.tencim.rc import RCCriteria
from confiacim.tencim.runner import TencimRunner
from confiacim.variables import StochasticVariable, pdf_cdf_ppf_of_distributions
from confiacim.verbose import VerboseLevel
from confiacim.write_results import (
    write_iteration_log,
    write_samples_variables_it,
    write_variables_it,
)


def loop(
    input_dir: Path,
    output_dir: Path,
    variables: tuple[StochasticVariable, ...],
    beta: float,
    delta: float,
    gamma: float,
    tol: float = 1.0e-05,
    maxit: int = 100,
    Nr: int = NR,
    correlations: dict[str, float] | None = None,
    rc_criteria: str = "mohr-coulomb",
    verbose_level: int = VerboseLevel.LEVEL_2.value,
    result_files: str = "json",
    save_intermediate_files: bool = False,
    json_indent: int | None = None,
    console: Console | None = None,
) -> FormResult:
    """
    Efetua os cálculos e procedientos do loop principal do método **FORM**.

    Parameters:
        input_dir: Diretório dos arquivos de entrada.
        output_dir: Diretório dos arquivos de saida.
        variables: Variaveis aleatórias.
        beta: Parametro do **FORM**.
        delta: Parametro do **FORM**.
        gamma: Parametro do **FORM**.
        tol: Tolerância do **FORM**.
        maxit: Número máximo de iterações do **FORM**.
        Nr: Parâmetro de relaxação do metodo **FORM**
        correlations: Informação das correlações das variáveis.
        rc_criteria: Critério do **RC**.
        verbose_level: Nivel de verbosidade.
        result_files: Tipo de arquivo de saida.
        save_intermediate_files: Salva os arquivos intermediarios da simulação.
        json_indent: identação do arquivo json.
        console: console do `Rich`.

    Returns:
        Retorna o resultado final do **FORM**.

    Info:
        A verbosidade pode ser:

        - 0 - Nenhuma
        - 1 - Moderada
        - 2 - Alta
    """
    simulation_logger = get_logger(name="simulation")

    f_F_IFs = pdf_cdf_ppf_of_distributions(variables)

    ro = generate_correlation_matrix(correlations, variables)

    L = cholesky(ro, lower=True)

    Ua = variables_mean2Ua(variables)
    avgs = Ua2avgs(Ua, variables)
    resid = 1.0

    write_json = result_files == "json"

    # TODO: Codigo repetido
    progressbarDisable = verbose_level == VerboseLevel.LEVEL_0 or verbose_level == VerboseLevel.LEVEL_2
    verbose = verbose_level == VerboseLevel.LEVEL_2

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}\n"),
        transient=True,
        disable=progressbarDisable,
    ) as progress:
        task = progress.add_task(description="Running...", total=None)

        # --- start mainloop
        for it in range(maxit):
            progress.update(
                task,
                description=(
                    f"[green]Running[/green]:\n"
                    f"[cyan]Iteration[/cyan] = {it+1:8}\n"
                    f"[cyan]Residual[/cyan]  = {resid:.2e}"
                ),
            )
            if verbose and console:
                text = Text(f"Iteration {it + 1}", justify="center", style=COLORS[0])
                panel = Panel(Align(text, vertical="middle", align="center"))
                console.print(panel)

                text = Text("Tencim step", justify="center", style=COLORS[1])
                panel = Panel(Align(text, vertical="middle", align="center"))
                console.print(panel)

            # Tencim
            generator = SamplesGeneratorForm(avgs, delta=delta)
            samples = generator.all()
            simulation_logger.info(f"Amostras geradas: {[s.name for s in samples]}")

            rcs = run_samples_iteration_i(
                samples=samples,
                input_dir=input_dir,
                output_dir=output_dir,
                iteration=it + 1,
                RunnerClass=TencimRunner,
                verbose=verbose,
                save_intermediate_files=save_intermediate_files,
                rc_criteria=RCCriteria.str_to_enum(rc_criteria),
            )

            if save_intermediate_files:
                write_samples_variables_it(
                    samples=samples,
                    iteration=it + 1,
                    output_dir=output_dir,
                    write_json=write_json,
                    indent=json_indent,
                )

            # form
            if verbose and console:
                text = Text("End tencim step", justify="center", style=COLORS[1])
                panel = Panel(Align(text, vertical="middle", align="center"))
                console.print(panel)

                text = Text("form step", justify="center", style=COLORS[2])
                panel = Panel(Align(text, vertical="middle", align="center"))
                console.print(panel)

                console.print(tables.variables_vector(Ua, avgs, f"U_{it + 1}"))

                console.print(tables.samples_it_rcs(rcs))

            Ua, betai, resid, alpha = form_step(Ua, L, rcs, gamma, delta, beta, f_F_IFs, it + 1, Nr)

            avgs = Ua2avgs(Ua, variables)

            if save_intermediate_files:
                write_variables_it(
                    averages=avgs,
                    iteration=it + 1,
                    output_dir=output_dir,
                    write_json=write_json,
                    indent=json_indent,
                )

            write_iteration_log(
                betai=betai,
                resid=resid,
                averages=avgs,
                iteration=it + 1,
                output_dir=output_dir,
                write_json=write_json,
                indent=json_indent,
            )

            if verbose and console:
                console.print(tables.convergence(betai, resid, "Convergence"))

                text = Text("End form step", justify="center", style=COLORS[2])
                panel = Panel(Align(text, vertical="middle", align="center"))
                console.print(panel)

                console.print(tables.variables_vector(Ua, avgs, "U_new"))

                text = Text(f"End iteration {it + 1}", justify="center", style=COLORS[0])
                panel = Panel(Align(text, vertical="middle", align="center"))
                console.print(panel)

            beta = betai
            simulation_logger.info(f"Iteration: {it=} {betai=:.6e} {resid=:.6e}")

            if resid < tol:
                break

    # --- end mainloop
    result = FormResult(
        beta=beta,
        resid=resid,
        rcs=rcs,
        it=it + 1,
        Pf=norm.cdf(-beta),
        importance_factors=importance_factors(alpha),
        omission_factors=omission_factors(alpha),
    )

    return result
