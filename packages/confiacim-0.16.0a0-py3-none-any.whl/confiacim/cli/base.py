from pathlib import Path
from typing import Annotated

import typer
from click import Context
from rich.console import Console
from rich.table import Table

from confiacim import tables
from confiacim.conf import Settings, settings
from confiacim.controllers.base import init as init_controller
from confiacim.controllers.base import summary as summary_controller
from confiacim.controllers.base import version as version_controller
from confiacim.erros import InputDirNotExists, InvalidDistributionError
from confiacim.logger import get_logger
from confiacim.simulation_config import (
    JsonIndentValueError,
    ResultFilesInvalidOptionError,
)
from confiacim.variables.weibull_params import NoConvergenceWeibullParams

console = Console()
logger = get_logger()

base_app = typer.Typer(add_completion=False, pretty_exceptions_show_locals=False)


def version_callback(value: bool):
    if value:
        str_ = version_controller()
        console.print(str_)
        raise typer.Exit()


@base_app.callback(invoke_without_command=True)
def typer_callback(
    ctx: Context,
    version: Annotated[
        bool, typer.Option("--version", "-v", help="Versão do FORM.", callback=version_callback)
    ] = False,
):
    if ctx.invoked_subcommand:
        return
    console.print("[yellow]Usage[/yellow]: [green]form[/green] [OPTIONS] COMMAND [ARGS]...\n")
    console.print("[blue]--help[/blue] for more informations.")


@base_app.command(name="init")
def cli_init():
    """Iniciando a estrutura básica da simulação"""
    init_controller()


@base_app.command(name="summary")
def cli_summary(input_dir: Annotated[Path, typer.Argument(..., help="Diretório dos arquivos de entra.")]):
    """Resumo das configurações lidas no arquivo case.yml"""
    try:
        summary_controller(input_dir=input_dir)
    except (
        InputDirNotExists,
        InvalidDistributionError,
        NoConvergenceWeibullParams,
        JsonIndentValueError,
        ResultFilesInvalidOptionError,
    ) as e:
        console.print(f"[red]Error[/red]: {e}")
        logger.error(e)
        raise typer.Exit(1) from e


@base_app.command(name="config")
def cli_config(
    raw: Annotated[bool, typer.Option("--raw", "-r", help="Mostra as configs sem transformar em uma tabela.")] = False
):
    """Mostra as configurações do confiacim"""

    printable: Settings | Table = settings

    if not raw:
        printable = tables.confiam_configs(settings)

    console.print(printable)
