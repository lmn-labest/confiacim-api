"""Módulo com os executores do `tencim`."""

import os
import subprocess
from pathlib import Path

from confiacim.conf import settings
from confiacim.erros import TencimRunError
from confiacim.file_folder_handlers import copy_file, iteration_folder


class TencimRunner:
    """
    Classe que executa a chamada do tencim

    Parameters:
        output_base_dir: Diretório dos arquivos de saida.
        iteration: Número da iteração.
    """

    def __init__(self, output_base_dir: Path, iteration: int = 1):
        self.output_base_dir = output_base_dir
        self.iteration = iteration

    def run(
        self, sample_name: str, used_templates: dict[str, bool], workdir: Path, origin_dir: Path, save: bool = False
    ):
        """
        Roda a simulação de uma amostra.

        Parameters:
            sample_name: Nome da amostra.
            used_templates: Quais templates foram usandos.
            workdir: Diretorio de trabalho temporário para rodar a análise.
            origin_dir: Diretório original
            save:  Salva os arquivos intermediarios da simulação.
        """
        os.chdir(workdir)
        self._run_tencim(sample_name, used_templates=used_templates, origin_dir=origin_dir)
        if save:
            base_folder = self._output_folder(sample_name)
            self._copy_analysis_files(sample_name, used_templates, base_folder)
        os.chdir(origin_dir)

    def _run_tencim(self, sample_name: str, **kwargs):
        """Rodar o tencim"""
        with open("log_file", mode="w") as log_file:
            sp = subprocess.run(
                [f"./{settings.EXEC_TENCIM_BIN}", "case.dat", sample_name],
                stdout=log_file,
                stderr=log_file,
            )
        if sp.returncode:
            dict_ = {"sample_name": sample_name, **kwargs}
            self.failure(**dict_)

    def failure(self, **kwargs):
        """Tratamento quando o tencim falha"""
        with open("log_file") as log_file:
            log_error = log_file.readlines()
        os.chdir(kwargs["origin_dir"])
        raise TencimRunError("".join(log_error))

    def _copy_analysis_files(self, sample_name: str, used_templates: dict, base_folder: Path):
        """Copia os arquivos da simulação desejados"""

        copy_file("log_file", base_folder / "stdout_log_file")
        if Path(f"./{sample_name}_time_log.txt").exists():
            copy_file(f"{sample_name}_time_log.txt", base_folder / "case_time_log.txt")
        if Path(f"{sample_name}_RC.txt").exists():
            copy_file(f"{sample_name}_RC.txt", base_folder / f"{sample_name}_RC.txt")

        # TODO: Repensar isso
        if used_templates.get("hidrationprop"):
            file_name = settings.HIDRPROP_FILE_NAME
            copy_file(file_name, base_folder / file_name)

        if used_templates.get("materials"):
            file_name = settings.MATERIALS_FILE_NAME
            copy_file(file_name, base_folder / file_name)

        if used_templates.get("initialtemperature"):
            file_name = settings.INITIAL_TEMP_FILE_NAME
            copy_file(file_name, base_folder / file_name)

        if used_templates.get("loads"):
            file_name = settings.LOADS_FILE_NAME
            copy_file(file_name, base_folder / file_name)

    def _output_folder(self, sample_name: str) -> Path:
        return self.output_base_dir / f"{iteration_folder(self.iteration)}/{sample_name}/"


class TencimRunnerByPassFailure(TencimRunner):
    """Não levanta uma exceção caso exista um erro no tencim"""

    def failure(self, **kwargs):
        """Tratamento quando o tencim falha"""
        sample_name = kwargs["sample_name"]
        used_templates = kwargs["used_templates"]
        base_folder = self._output_failure(sample_name)
        self._copy_analysis_files(sample_name, used_templates, base_folder)

    def _output_failure(self, sample_name: str) -> Path:
        return self.output_base_dir / f"failure/{sample_name}/"


class TencimRunnerDeterministic(TencimRunner):
    """Classe que executa a chamada do tencim da análise deterministica."""

    def _output_folder(self, sample_name: str = "deterministic") -> Path:
        return self.output_base_dir / f"{sample_name}"


class TencimStandaloneRunner:
    """
    Classe que executa a chamada do tencim

    Parameters:
        output_base_dir: Diretório dos arquivos de saida.
        workdir: Diretorio de trabalho temporário para rodar a análise.
        origin_dir: Diretório original
    """

    def __init__(
        self,
        output_base_dir: Path,
        workdir: Path,
        origin_dir: Path,
    ):
        self.output_base_dir = output_base_dir
        self.workdir = workdir
        self.origin_dir = origin_dir

    def run(self):
        """
        Rodar o tencim

        Raises:
            TencimRunError: Erro do tencim
        """
        os.chdir(self.workdir)
        self._run_tencim()
        self._copy_analysis_files()
        self._return_to_original_dir()

    def _return_to_original_dir(self):
        os.chdir(self.origin_dir)

    def _run_tencim(self):
        """Rodar o tencim"""
        with open("log_file", mode="w") as log_file:
            sp = subprocess.run(
                [f"./{settings.EXEC_TENCIM_BIN}", "case.dat"],
                stdout=log_file,
                stderr=log_file,
            )
        if sp.returncode:
            self.failure()

    def failure(self):
        """
        Tratamento quando o tencim falha

        Raises:
            TencimRunError: Erro do tencim
        """
        with open("log_file") as log_file:
            log_error = log_file.readlines()
        self._return_to_original_dir()
        raise TencimRunError("".join(log_error))

    def _copy_analysis_files(self):
        """Copia os arquivos da simulação desejados"""
        copy_file("log_file", self.output_base_dir / "stdout_log_file")
        if Path("./case_time_log.txt").exists():
            copy_file("case_time_log.txt", self.output_base_dir / "case_time_log.txt")
        if Path("case_RC.txt").exists():
            copy_file("case_RC.txt", self.output_base_dir / "case_RC.txt")
