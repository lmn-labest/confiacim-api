from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console

from confiacim.controllers.form import run as run_controller
from confiacim.erros import (
    CaseFileNotFound,
    FormStepModZeroError,
    FormStepUaInfError,
    InputDirNotExists,
    InvalidDistributionError,
    MissingNoRcNoClip,
    PropValueMissingError,
    SimulationConfigFileError,
    TencimExecNotFound,
    TencimRunError,
    VariableTemplateError,
)
from confiacim.logger import get_logger
from confiacim.simulation_config import (
    JsonIndentValueError,
    RCCriteriaInvalidOptionError,
    ResultFilesInvalidOptionError,
)
from confiacim.variables.weibull_params import NoConvergenceWeibullParams
from confiacim.verbose import VerboseLevel

form_app = typer.Typer()

logger = get_logger()

console = Console()


@form_app.command(name="run")
def cli_run(
    input_dir: Annotated[Path, typer.Argument(..., help="Diretório dos arquivos de entra.")],
    output_dir: Annotated[Optional[Path], typer.Argument(..., help="Diretório dos arquivos de saida.")] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Modo verboso.")] = False,
    save_intermediate_files: Annotated[
        bool, typer.Option("--save", "-s", help="Salva os arquivos intermediarios.")
    ] = False,
):
    """Comando que executa o FORM."""

    try:
        verbose_level = VerboseLevel.LEVEL_2 if verbose else VerboseLevel.LEVEL_1
        run_controller(
            input_dir=input_dir,
            output_dir=output_dir,
            verbose_level=verbose_level,
            save_intermediate_files=save_intermediate_files,
        )
    except (
        InputDirNotExists,
        CaseFileNotFound,
        TencimExecNotFound,
    ) as e:
        console.print(f"[red]Error[/red]: {e}")
        logger.error(e)
        raise typer.Exit(1) from e

    except TencimRunError as e:
        console.print(f"[red]Error[/red]: Erro no tencim\n{e}")

        logger.error("Erro no tencim. Ver simulation.log para mais informações.")

        logger_simulation = get_logger("simulation")
        logger_simulation.error(e)

        raise typer.Exit(1) from e

    except (
        MissingNoRcNoClip,
        SimulationConfigFileError,
        JsonIndentValueError,
        FormStepModZeroError,
        FormStepUaInfError,
        NoConvergenceWeibullParams,
        ResultFilesInvalidOptionError,
        InvalidDistributionError,
        VariableTemplateError,
        PropValueMissingError,
        RCCriteriaInvalidOptionError,
    ) as e:
        console.print(f"[red]Error[/red]: {e}")

        logger.error("Erro na simulação. Ver simulation.log para mais informações.")

        logger_simulation = get_logger(name="simulation")
        logger_simulation.error(e)
        raise typer.Exit(1) from e
