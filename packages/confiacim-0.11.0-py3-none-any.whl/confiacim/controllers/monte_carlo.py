"""
O módulo contem controladores para serem usando na `CLI` e na `API`.

Classes e funções deste módulo:

- run
- mk_samples

---

"""

from pathlib import Path

from rich.align import Align
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from scipy.linalg import cholesky

from confiacim import tables
from confiacim.constants import COLORS
from confiacim.erros import (
    CaseFileNotFound,
    InputDirNotExists,
    VarNameNotFoundAtCaseFileError,
)
from confiacim.file_folder_handlers import default_output_dir
from confiacim.form.correlations import generate_correlation_matrix
from confiacim.logger import get_logger, set_logger
from confiacim.monte_carlo.core import generate_samples, loop
from confiacim.plot.graphs import histogram
from confiacim.run_statistics import confiacim_statistics
from confiacim.samples import SamplesGeneratorMonteCarlo
from confiacim.simulation_config import load_config
from confiacim.tencim.input_file import check_for_nocliprc_macro
from confiacim.timer import Timer
from confiacim.variables.core import search_var_by_name
from confiacim.write_results import (
    write_confiacim_statistics,
    write_monte_carlo_results,
    write_samples_variables_it,
)

logger = get_logger()
console = Console()


def run(
    *, input_dir: Path, verbose_level: int, output_dir: Path | None = None, save_intermediate_files: bool = False
) -> None:
    """
    Rodando a simulação Monte Carlo.

    Parameters:
        input_dir: Diterório do arquivo de entrada.
        output_dir: Diterório do arquivo de saida.
        verbose_level: Nivel de verbosidade.
        save_intermediate_files: Salva os arquivos intermediarios da simulação.

    Info:
        A verbosidade pode ser:

        - 0 - Nenhuma
        - 1 - Moderada
        - 2 - Alta

    """
    if not Path(input_dir).exists():
        raise InputDirNotExists(input_dir)

    if not output_dir:
        output_dir = default_output_dir(input_dir) / "mc"

    set_logger(logfile=input_dir / "simulation.log", name="simulation")

    try:
        check_for_nocliprc_macro(case_file=input_dir / "case.dat")
    except FileNotFoundError as e:
        raise CaseFileNotFound(e.filename) from FileNotFoundError

    simulation_conf = load_config(file_path=input_dir / "case.yml")

    logger.info(f"Analise Monte Carlo: {input_dir=} {output_dir=} {verbose_level=}")

    with Timer("Complete Analysis", print_time=verbose_level) as t:
        results = loop(
            **simulation_conf.monte_carlo_configs,
            **simulation_conf.base_configs,
            **simulation_conf.variables_infos,
            input_dir=input_dir,
            output_dir=output_dir,
            console=console,
            verbose_level=verbose_level,
            save_intermediate_files=save_intermediate_files,
        )
    confiacim_statistics.total_time = t.get_wall_time()
    write_json = simulation_conf.result_files == "json"
    json_indent = simulation_conf.json_indent

    if verbose_level:
        text = Text("Final results", justify="center", style=COLORS[3])
        panel = Panel(Align(text, vertical="middle", align="center"))
        console.print(panel)

        console.print(tables.monte_carlo_final_results(results))

    write_monte_carlo_results(results, output_dir, write_json=write_json, indent=json_indent)
    write_confiacim_statistics(confiacim_statistics, output_dir, write_json=write_json, indent=json_indent)


def mk_samples(*, input_dir: Path, output_dir: Path | None, verbose_level: int) -> None:
    """
    Gera as amostras do Monte Carlo.

    Parameters:
        input_dir: Diterório do arquivo de entrada.
        output_dir: Diterório do arquivo de saida.
        verbose_level: Nivel de verbosidade.

    Info:
        A verbosidade pode ser:

        - 0 - Nenhuma
        - 1 - Moderada
        - 2 - Alta

    """
    if not Path(input_dir).exists():
        raise InputDirNotExists(input_dir)

    if not output_dir:
        output_dir = default_output_dir(input_dir) / "mc"

    set_logger(logfile=input_dir / "simulation.log", name="simulation")

    try:
        check_for_nocliprc_macro(case_file=input_dir / "case.dat")
    except FileNotFoundError as e:
        raise CaseFileNotFound(e.filename) from FileNotFoundError

    simulation_conf = load_config(file_path=input_dir / "case.yml")

    logger.info(f"Gerando amostras do Monte Carlo: {input_dir=} {output_dir=} {verbose_level=}")

    with Timer("Generating Monte Carlo samples", print_time=verbose_level):
        ro = generate_correlation_matrix(simulation_conf.correlations, simulation_conf.variables)
        L = cholesky(ro, lower=True)
        generator = SamplesGeneratorMonteCarlo(
            variables=simulation_conf.variables,
            n_samples=simulation_conf.monte_carlo_configs["n_samples"],
            L=L,
        )
        samples = generate_samples(generator, verbose_level, console=console)

    write_json = simulation_conf.result_files == "json"
    write_samples_variables_it(
        samples=samples,
        iteration=1,
        output_dir=output_dir,
        write_json=write_json,
        indent=simulation_conf.json_indent,
    )


def plot_histgram(*, var_name: str, input_dir: Path):
    """
    Plota o histograma da distribuição selecinada.

    Parameters:
        input_dir: Diretório da simulação
        var_name: Nome da variável.

    Raises:
        InputDirNotExists: Diretŕio não encontrado.
        VarNameNotFoundAtCaseFileError: Não da variável no encontrado.
        InvalidDistributionError: Distribuição Invalida.
        SimulationConfigFileError: Erro no arquivo de configurações.
    """

    if not Path(input_dir).exists():
        raise InputDirNotExists(input_dir)

    simulation_conf = load_config(file_path=input_dir / "case.yml")

    ro = generate_correlation_matrix(simulation_conf.correlations, simulation_conf.variables)
    L = cholesky(ro, lower=True)

    generator = SamplesGeneratorMonteCarlo(
        variables=simulation_conf.variables,
        n_samples=simulation_conf.monte_carlo_configs["n_samples"],
        L=L,
    )

    found_var = search_var_by_name(simulation_conf.variables, var_name)

    if not found_var:
        raise VarNameNotFoundAtCaseFileError(var_name)

    samples = samples = generator.all()

    values = [sp[var_name] for sp in samples]

    histogram(values=values, variable=found_var)
