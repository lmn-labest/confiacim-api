from dataclasses import dataclass, field
from math import sqrt

import numpy as np


@dataclass
class MonteCarloResult:
    """
    Classe que define os resultados.

    Attributes:
        total (int): Número total de amostras.
        valid_simulations: Simulações válidas.
        fail (int): Número amostras que falharam.
        P (int): Instância da distribuição desejada.

    """

    total: int
    valid_simulations: int
    fail: int
    P: float = field(init=False)
    estimator: float | None = field(init=False)

    def __post_init__(self):
        self.P = _probability(self.fail, self.valid_simulations)
        self.estimator = _estimator(self.P, self.valid_simulations)


def _probability(fail: int, n: int):
    """
    Calculo da probabilidade.

    Attributes:
        fail : Número de falhas.
        n : Número de amostras

    Returns:
        Retorna a probabilidae
    """

    try:
        return fail / n
    except ZeroDivisionError:
        return np.Inf


def _estimator(p: float, n: int) -> float | None:
    """
    Calculo do estimador do Monte Carlo.

    Attributes:
        P : Instância da distribuição desejada.
        n : Número de amostras

    Returns:
        Retorna o estimador
    """
    try:
        return sqrt(1.0 - p) / (sqrt(n) * sqrt(p))
    except ZeroDivisionError:
        return None
