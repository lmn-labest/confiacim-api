"""
Módulo com as funcionalidades de geração de arquivos via template.

Classes e funções deste módulo:

- Genarator
- Jinja2ContextProcessor

"""

from pathlib import Path

from jinja2 import Environment, FileSystemLoader, meta
from jinja2.exceptions import TemplateNotFound

from confiacim.conf import settings
from confiacim.erros import PropValueMissingError, VariableTemplateError

MATERIALS_PROPS = (
    # Cimento
    "E_c",
    "poisson_c",
    "thermal_expansion_c",
    "friction_angle_c",
    "cohesion_c",
    "thermal_conductivity_c",
    "volumetric_heat_capacity_c",
    # Formacao
    "E_f",
    "poisson_f",
    "thermal_expansion_f",
    "thermal_conductivity_f",
    "volumetric_heat_capacity_f",
)

HIDROPROP = "E_c,poisson_c,cohesion_c,volumetric_heat_capacity_c".split(",")

LOADS = "external_temperature,internal_temperature,internal_pressure".split(",")


class Jinja2ContextProcessor:
    """
    Classe que envelopa a funcionalidades do `Jinja2`.
    """

    def __init__(self, template_dir: Path, template_name: str):
        """
        Parameters:
            template_dir: Diretório dos templates.
            template_name: nome do template.
        """
        self.searchpath = template_dir
        self.template_name = template_name
        self._setup()

    def _setup(self):
        templateLoader = FileSystemLoader(searchpath=self.searchpath)
        self.env = Environment(loader=templateLoader)
        self.template = self.env.get_template(self.template_name)

    def render(self, **context) -> str:
        """
        Gera o arquivo utilizando o template

        Parameters:
            context kwgars: Variaveis passadas para o contexto do template.

        Returns:
            Retorna o aquivo gerado na forma de `str`.
        """
        str_file: str = self.template.render(context)
        return str_file

    def get_variables(self) -> set[str]:
        """
        Obtem as variaveis utilizadas no template.

        Returns:
            Retorna as variaveis utilizadas no template.
        """
        template_source = self.env.loader.get_source(self, self.template_name)[0]
        parsed_content = self.env.parse(template_source)
        return meta.find_undeclared_variables(parsed_content)


class Genarator:
    """
    Classe que genera os arquivos de entrada

    Parameters:
        template_path: Diretório dos templates.
    """

    def __init__(self, template_path: Path) -> None:
        self.template_path = template_path

    def get_template(self, name: str):
        return Jinja2ContextProcessor(self.template_path, name)

    def generate_hidrprop(self, averages: dict[str, float], write_path: Path) -> None:
        """
        Gera o arquivo `hidrationprop.dat`.

        Parameters:
            averages: Variaveis médias.
            write_path: Caminho do diretório onde o arquivo será escrito.
        """

        template = self.get_template("hidrationprop.jinja")

        context = self.context_props_from_averages(averages, HIDROPROP)

        self.check_variables(template, context)

        string = template.render(**context)

        with open(write_path / settings.HIDRPROP_FILE_NAME, mode="w") as f:
            f.write(string)

    def generate_materials(self, averages: dict[str, float], write_path: Path) -> None:
        """
        Gera o arquivo `materials.dat`.

        Parameters:
            averages: Variaveis médias.
            write_path: Caminho do diretório onde o arquivo será escrito.
        """

        template = self.get_template("materials.jinja")

        context = self.context_props_from_averages(averages, MATERIALS_PROPS)

        self.check_variables(template, context)

        string = template.render(**context)

        with open(write_path / settings.MATERIALS_FILE_NAME, mode="w") as f:
            f.write(string)

    def generate_initialtemperature(self, averages: dict[str, float], write_path: Path) -> None:
        """
        Gera o arquivo `initialtemperature.dat`.

        Parameters:
            averages: Variaveis médias.
            write_path: Caminho do diretório onde o arquivo será escrito.
        """

        template = self.get_template("initialtemperature.jinja")

        # TODO: repensar isso, talvez seja melhor context_props_from_averages e check_variables
        try:
            initial_temp = averages["initial_temp"]
        except KeyError as e:
            raise PropValueMissingError(template_name="initialtemperature.jinja", variable="initial_temp") from e

        string = template.render(initial_temp=initial_temp)

        with open(write_path / settings.INITIAL_TEMP_FILE_NAME, mode="w") as f:
            f.write(string)

    def generate_loads(self, averages: dict[str, float], write_path: Path) -> None:
        """
        Gera o arquivo `loads.dat`.

        Parameters:
            averages: Variaveis médias.
            write_path: Caminho do diretório onde o arquivo será escrito.
        """

        template = self.get_template("loads.jinja")

        context = self.context_props_from_averages(averages, LOADS)

        self.check_variables(template, context)

        string = template.render(**context)

        with open(write_path / settings.LOADS_FILE_NAME, mode="w") as f:
            f.write(string)

    def all(self, averages: dict[str, float], write_path: Path) -> dict[str, bool]:
        """
        Gera todos as arquivos que foram achos templates.

        Parameters:
            averages: Variaveis médias.
            write_path: Caminho do diretório onde o arquivo será escrito.

        Returns:
            Retorna quais foram os templates gerados.
        """

        was_generated = {}

        try:
            self.generate_materials(averages, write_path)
            was_generated["materials"] = True
        except TemplateNotFound:
            pass

        try:
            self.generate_hidrprop(averages, write_path)
            was_generated["hidrationprop"] = True
        except TemplateNotFound:
            pass

        try:
            self.generate_initialtemperature(averages, write_path)
            was_generated["initialtemperature"] = True
        except TemplateNotFound:
            pass

        try:
            self.generate_loads(averages, write_path)
            was_generated["loads"] = True
        except TemplateNotFound:
            pass

        return was_generated

    def check_variables(self, template: Jinja2ContextProcessor, variable_in_context: dict) -> None:
        """
        Verifica se todas as variaveis no dicionário estão no template.

        Parameters:
            template: template Jinja
            variable_in_context: Variveis no contexto

        Raises:
            VariableTemplateError: _description_
        """
        variables_in_templates = template.get_variables()

        for var_in_tamplate in variables_in_templates:
            if var_in_tamplate not in variable_in_context:
                raise VariableTemplateError(var_in_tamplate)

    @classmethod
    def context_props_from_averages(cls, averages: dict, props: list[str] | tuple[str, ...]) -> dict[str, float]:
        """
        Pega a variaveis que serão utlizadas no contexto

        Parameters:
            averages: Médias de todas as variaveis aleatórias.
            props: Propriedades desejadas

        Returns:
            Retorna um dicionário apenas com as médias desejadas.
        """
        context = {}
        for prop in props:
            try:
                context[prop] = averages[prop]
            except KeyError:
                pass
        return context
