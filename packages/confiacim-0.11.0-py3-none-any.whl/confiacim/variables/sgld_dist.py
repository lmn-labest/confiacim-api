"""
Módulo com a implementação da distribuição `SGLD`.

Referencia:

**A new distribution for ﬁtting four moments and its applications to reliability analysis - Y.M. Low (2013)**\
[[1]](https://www.sciencedirect.com/science/article/abs/pii/S0167473013000143?via%3Dihub)

"""

from math import exp, factorial, gamma, log, sqrt

import numpy as np
from scipy.special import gammainc, gammaincinv


class SGLD:
    def pdf(self, x: float, sigma: float, r: float, b: float, theta: float) -> float:
        """
        Função densidade de probabilidade da distruibuição `(pdf)`.

        Parameters:
            x:
            sigma: Parâmetro.
            r: Parâmetro.
            b: Parâmetro.
            theta: Parâmetro.

        Returns:
            Valor da função avalida em x.
        """
        return self._pdf(x, sigma=sigma, r=r, b=b, theta=theta)

    def cdf(self, x: float, sigma: float, r: float, b: float, theta: float) -> float:
        """
        Função densidade de probabilidade acumulada da distruibuição `(cdf)`.

        Parameters:
            x: valor na variavel
            sigma: Parâmetro.
            r: Parâmetro.
            b: Parâmetro.
            theta: Parâmetro.

        Returns:
            Valor da função avalida em x.

        """
        return self._cdf_analytic(x, sigma=sigma, r=r, b=b, theta=theta)

    def ppf(self, p: float, sigma: float, r: float, b: float, theta: float) -> float:
        """
        Inversa da função densidade de probabilidade acumulada da distruibuição `(ppf)`.

        Parameters:
            p: probabilidade
            sigma: Parâmetro.
            r: Parâmetro.
            b: Parâmetro.
            theta: Parâmetro.

        Returns:
            Valor da função avalida em p.
        """
        return self._ppf_analytic(p, sigma=sigma, r=r, b=b, theta=theta)

    def mean(self, sigma: float, r: float, b: float, theta: float) -> float:
        """
        Cálculo da média.

        Parameters:
            sigma: Parâmetro.
            r: Parâmetro.
            b: Parâmetro.
            theta: Parâmetro.

        Returns:
            Valor da média.
        """
        return self._mean_calc_analytic(sigma=sigma, r=r, b=b, theta=theta)

    def std(self, sigma: float, r: float, b: float, theta: float) -> float:
        """
        Cálculo do desvio padrão.

        Parameters:
            sigma: Parâmetro.
            r: Parâmetro.
            b: Parâmetro.
            theta: Parâmetro.

        Returns:
            Valor da desvio padrão.
        """
        return self._std_calc_analytic(sigma=sigma, r=r, b=b, theta=theta)

    def _pdf(self, x: float, sigma: float, r: float, b: float, theta: float) -> float:
        """
        Cálculo analítico da densidade de probabilidade.

        Parameters:
            x: Valor da variavel.

        Returns
            Retorona o valor de pdf(x)
        """

        def alpha(r: float, sigma: float) -> float:
            r_inv = 1.0 / r
            r_pow = r**r_inv

            res: float = 1.0 / (2.0 * r_pow * sigma * gamma(1.0 + r_inv))

            return res

        if x <= b:
            return 0.0

        alpha_ = alpha(r, sigma)

        xb = x - b

        par1 = alpha_ / xb
        par2 = -1.0 / (r * (sigma**r))
        par3 = abs(log(xb / theta)) ** r

        return par1 * exp(par2 * par3)

    def _cdf_analytic(self, x: float, sigma: float, r: float, b: float, theta: float) -> float:
        """
        Cálculo analítico da ensidade de probabilidade acumulada.

        Parameters:
            x: Valor da variavel.

        Returns
            Retorna o valor de cdf(x)
        """

        y = (x - b) / theta

        if y <= 0:
            return 0.0

        partial1 = pow(abs(log(y) / sigma), r) / r

        res: float = 0.5 + 0.5 * np.sign(y - 1.0) * gammainc(1.0 / r, partial1)

        return res

    def _ppf_analytic(self, p: float, sigma: float, r: float, b: float, theta: float) -> float:
        """
        Cálculo analítico da densidade de probabilidade acumulada inversa.

        Parameters:
            p: Valor da probabilidade.

        Returns
            Retorna o valor de ppf(p)
        """
        # partial1 = 1.0 if p - 0.5 > 0.0 else -1.0
        # partial2 = (2.0 * p - 1.0) / partial1
        # partial3 = 1.0 / r
        # partial4 = pow(r * gammaincinv(partial3, partial2), partial3)

        # y = exp(partial1 * sigma * partial4)

        partial1 = 1.0 if p - 0.5 > 0.0 else -1.0

        y = exp(partial1 * sigma * pow(r * gammaincinv(1.0 / r, (2.0 * p - 1.0) * partial1), 1.0 / r))

        x = y * theta + b

        return x

    def _mean_calc_analytic(self, sigma: float, r: float, b: float, theta: float, sum_k: int = 15) -> float:
        tmp = 0.0e0

        for n in range(sum_k):
            _2n = 2 * n
            tmp += pow(sigma, _2n) * pow(r, _2n / r) * gamma((_2n + 1) / r) / factorial(_2n)

        mu_Y = tmp / gamma(1.0 / r)

        return b + theta * mu_Y

    def _std_calc_analytic(self, sigma: float, r: float, b: float, theta: float, sum_k: int = 15) -> float:
        tmp = 0.0e0
        for n in range(sum_k):
            _2n = 2 * n
            tmp += pow(2 * sigma, _2n) * pow(r, _2n / r) * gamma((_2n + 1) / r) / factorial(_2n)

        E_y2 = tmp / gamma(1.0 / r)

        E_y = (self._mean_calc_analytic(sigma=sigma, r=r, b=b, theta=theta) - b) / theta

        std_Y = sqrt(E_y2 - E_y * E_y)

        return theta * std_Y


sgld = SGLD()
