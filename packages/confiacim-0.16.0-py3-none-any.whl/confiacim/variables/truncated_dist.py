"""
Módulo com a implementação da distribuição `trucandas`.

(EXPERIMENTAL)

"""

from functools import cache
from math import inf, sqrt

from scipy.integrate import quad
from scipy.optimize import newton, toms748
from scipy.stats import lognorm

from confiacim.variables.sgld_dist import sgld


@cache
def _fe(x: float, sigma: float, r: float, b: float, theta: float):
    return sgld.cdf(x, sigma=sigma, r=r, b=b, theta=theta)


@cache
def apply_scale(x_lower_limit: float, x_upper_limit: float, scale_factor: float) -> tuple[float, float]:
    return x_lower_limit / scale_factor, x_upper_limit / scale_factor


class LogNormalTrunked:
    def pdf(self, x: float, s: float, scale: float, b: float):
        """
        Função densidade de probabilidade acumulada da distruibuição `(pdf)`.

        Parameters:
            x: valor da váriavel.
            s: Parâmetro.
            scale: Parâmetro.
            b: Parâmetro limite superior.

        Returns:
            Valor da função avaliada em x.
        """

        if x > b:
            return 0.0

        return lognorm.pdf(x, s=s, scale=scale) / lognorm.cdf(b, s=s, scale=scale)

    def cdf(self, x: float, s: float, scale: float, b: float):
        """
        Função densidade de probabilidade acumulada da distruibuição `(cdf)`.

        Parameters:
            x: valor da váriavel.
            s: Parâmetro.
            scale: Parâmetro.
            b: Parâmetro limite superior.

        Returns:
            Valor da função avaliada em x.

        """
        if x > b:
            return 1.0

        return lognorm.cdf(x, s=s, scale=scale) / lognorm.cdf(b, s=s, scale=scale)

    def ppf(self, p: float, s: float, scale: float, b: float):
        """
        Inversa da função densidade de probabilidade acumulada da distruibuição `(ppf)`.

        Parameters:
            p: valor da probabilidade.
            s: Parâmetro.
            scale: Parâmetro.
            b: Parâmetro limite superior.

        Returns:
            Valor da função avalida em p.
        """
        return self._ppf_numeric(p, s, scale, b)

    def mean(self, s: float, scale: float, b: float):
        """
        Cálculo da média.

        Parameters:
            s: Parâmetro.
            scale: Parâmetro.
            b: Parâmetro limite superior.

        Returns:
            Valor da média.
        """
        return self._mean_numeric(s=s, scale=scale, b=b)

    def std(self, s: float, scale: float, b: float) -> float:
        """
        Cálculo do desvio padrão.

        Parameters:
            s: Parâmetro.
            scale: Parâmetro.
            b: Parâmetro limite superior.

        Returns:
            Valor da desvio padrão.
        """
        return self._std_numeric(s=s, scale=scale, b=b)

    def _mean_numeric(self, s: float, scale: float, b: float):
        result = quad(lambda x: x * self.pdf(x, s, scale, b), 0.0, b, limit=500)

        if result[1] > 1.0e-4:
            print(f"Problema na convergencia da integral {result[1]}")

        return result[0]

    def _std_numeric(self, s: float, scale: float, b: float) -> float:
        result = quad(lambda x: x * x * self.pdf(x, s, scale, b), 0.0, b, limit=500)

        mean = self.mean(s, scale, b)

        if result[1] > 1.0e-4:
            print(f"Problema na convergencia da integral {result[1]}")

        var = result[0] - mean * mean

        return sqrt(var)

    def _ppf_numeric(self, p: float, s: float, scale: float, b: float):
        """
        Cálculo analítico da densidade de probabilidade acumulada inversa.

        Parameters:
            p: Valor da probabilidade.
            s: Parâmetro.
            scale: Parâmetro.
            b: Parâmetro limite superior.

        Returns
            Retorna o valor de ppf(p)
        """

        f = lambda x: self.cdf(x, s, scale, b) - p  # noqa

        r = toms748(f, a=0, b=b, rtol=1e-6)
        if abs(f(r)) > 1e-10:
            r = newton(f, r, maxiter=1_000, tol=1e-14)

        return r


class SGLDLowerTrunked:
    def pdf(self, x: float, sigma: float, r: float, b: float, theta: float, x_lower_limit: float):
        """
        Função densidade de probabilidade acumulada da distruibuição `(pdf)`.

        Parameters:
            x:
            sigma: Parâmetro.
            r: Parâmetro.
            b: Parâmetro.
            theta: Parâmetro.
            x_lower_limit: Limite inferior.

        Returns:
            Valor da função avaliada em x.
        """

        if x < x_lower_limit:
            return 0.0

        fe = _fe(x_lower_limit, sigma=sigma, r=r, b=b, theta=theta)

        numerator = sgld.pdf(x, sigma=sigma, r=r, b=b, theta=theta)
        denominator = 1.0 - fe

        return numerator / denominator

    def cdf(self, x: float, sigma: float, r: float, b: float, theta: float, x_lower_limit: float):
        """
        Função densidade de probabilidade acumulada da distruibuição `(cdf)`.

        Parameters:
            x:
            sigma: Parâmetro.
            r: Parâmetro.
            b: Parâmetro.
            theta: Parâmetro.
            x_lower_limit: Limite inferior.

        Returns:
            Valor da função avaliada em x.

        """
        if x < x_lower_limit:
            return 0.0

        fe = _fe(x_lower_limit, sigma=sigma, r=r, b=b, theta=theta)

        numerator = sgld.cdf(x, sigma=sigma, r=r, b=b, theta=theta) - fe
        denominator = 1.0 - fe

        return numerator / denominator

    def ppf(self, p: float, sigma: float, r: float, b: float, theta: float, x_lower_limit: float):
        """
        Inversa da função densidade de probabilidade acumulada da distruibuição `(ppf)`.

        Parameters:
            p: valor da probabilidade.
            sigma: Parâmetro.
            r: Parâmetro.
            b: Parâmetro.
            theta: Parâmetro.
            x_lower_limit: Limite inferior.

        Returns:
            Valor da função avalida em p.
        """

        fe = _fe(x_lower_limit, sigma=sigma, r=r, b=b, theta=theta)
        return sgld.ppf(p * (1.0 - fe) + fe, sigma=sigma, r=r, b=b, theta=theta)

    def mean(self, sigma: float, r: float, b: float, theta: float, x_lower_limit: float):
        """
        Cálculo da média.

        Parameters:
            sigma: Parâmetro.
            r: Parâmetro.
            b: Parâmetro.
            theta: Parâmetro.
            x_lower_limit: Limite inferior.

        Returns:
            Valor da média.
        """
        return self._mean_numeric(sigma, r, b, theta, x_lower_limit)

    def std(self, sigma: float, r: float, b: float, theta: float, x_lower_limit: float) -> float:
        """
        Cálculo do desvio padrão.

        Parameters:
            sigma: Parâmetro.
            r: Parâmetro.
            b: Parâmetro.
            theta: Parâmetro.
            x_lower_limit: Limite inferior.

        Returns:
            Valor da desvio padrão.
        """
        return self._std_numeric(sigma=sigma, r=r, b=b, theta=theta, x_lower_limit=x_lower_limit)

    def _mean_numeric(self, sigma: float, r: float, b: float, theta: float, x_lower_limit: float):
        mean_ = sgld.mean(sigma=sigma, r=r, b=b, theta=theta)
        std = sgld.std(sigma=sigma, r=r, b=b, theta=theta)

        result = [0.0, 0.0]
        for ra in self.range_integration(x_lower_limit, mean_, std):
            tmp = quad(lambda x: x * self.pdf(x, sigma, r, b, theta, x_lower_limit), **ra, limit=500)
            result[0] += tmp[0]
            result[1] += tmp[1]

        if result[1] > 1.0e-4:
            print(f"Problema na convergencia da integral {result[1]}")

        return result[0]

    def _std_numeric(self, sigma: float, r: float, b: float, theta: float, x_lower_limit: float) -> float:
        mean_ = sgld.mean(sigma=sigma, r=r, b=b, theta=theta)
        std = sgld.std(sigma=sigma, r=r, b=b, theta=theta)

        result = [0.0, 0.0]
        for ra in self.range_integration(x_lower_limit, mean_, std):
            tmp = quad(lambda x: x * x * self.pdf(x, sigma, r, b, theta, x_lower_limit), **ra, limit=500)
            result[0] += tmp[0]
            result[1] += tmp[1]

        mean = self.mean(sigma=sigma, r=r, b=b, theta=theta, x_lower_limit=x_lower_limit)

        if result[1] > 1.0e-4:
            print(f"Problema na convergencia da integral {result[1]}")

        var = result[0] - mean * mean

        return sqrt(var)

    def range_integration(self, x_lower_limit: float, mean_: float, std: float) -> list[dict[str, float]]:
        return [
            {"a": x_lower_limit, "b": mean_ - 5.0 * std},
            {"a": mean_ - 5.0 * std, "b": mean_},
            {"a": mean_, "b": mean_ + 5.0 * std},
            {"a": mean_ + 5.0 * std, "b": inf},
        ]


class SGLDLowerUpperTrunked:

    def pdf(
        self,
        x: float,
        sigma: float,
        r: float,
        b: float,
        theta: float,
        x_lower_limit: float,
        x_upper_limit: float,
        scale_factor: float,
    ):
        """
        Função densidade de probabilidade acumulada da distruibuição `(pdf)`.

        Parameters:
            x:
            sigma: Parâmetro.
            r: Parâmetro.
            b: Parâmetro.
            theta: Parâmetro.
            x_lower_limit: Limite inferior.
            x_upper_limit: Limite superior.
            scale_factor: fator de escala que divide o x.

        Returns:
            Valor da função avaliada em x.
        """
        x_lower, x_upper = apply_scale(x_lower_limit, x_upper_limit, scale_factor)

        if x < x_lower or x > x_upper:
            return 0.0

        fe1 = _fe(x_lower, sigma=sigma, r=r, b=b, theta=theta)
        fe2 = _fe(x_upper, sigma=sigma, r=r, b=b, theta=theta)

        numerator = sgld.pdf(x, sigma=sigma, r=r, b=b, theta=theta)
        denominator = fe2 - fe1

        return numerator / denominator

    def cdf(
        self,
        x: float,
        sigma: float,
        r: float,
        b: float,
        theta: float,
        x_lower_limit: float,
        x_upper_limit: float,
        scale_factor: float,
    ):
        """
        Função densidade de probabilidade acumulada da distruibuição `(cdf)`.

        Parameters:
            x:
            sigma: Parâmetro.
            r: Parâmetro.
            b: Parâmetro.
            theta: Parâmetro.
            x_lower_limit: Limite inferior.
            x_upper_limit: Limite superior.
            scale_factor: fator de escala que divide o x.

        Returns:
            Valor da função avaliada em x.

        """
        x_lower, x_upper = apply_scale(x_lower_limit, x_upper_limit, scale_factor)

        if x < x_lower:
            return 0.0

        if x > x_upper:
            return 1.0

        fe1 = _fe(x_lower, sigma=sigma, r=r, b=b, theta=theta)
        fe2 = _fe(x_upper, sigma=sigma, r=r, b=b, theta=theta)

        numerator = sgld.cdf(x, sigma=sigma, r=r, b=b, theta=theta) - fe1
        denominator = fe2 - fe1

        return numerator / denominator

    def ppf(
        self,
        p: float,
        sigma: float,
        r: float,
        b: float,
        theta: float,
        x_lower_limit: float,
        x_upper_limit: float,
        scale_factor: float,
    ):
        """
        Inversa da função densidade de probabilidade acumulada da distruibuição `(ppf)`.

        Parameters:
            p: valor da probabilidade.
            sigma: Parâmetro.
            r: Parâmetro.
            b: Parâmetro.
            theta: Parâmetro.
            x_lower_limit: Limite inferior.
            x_upper_limit: Limite superior.
            scale_factor: fator de escala que divide o x.

        Returns:
            Valor da função avalida em p.
        """
        x_lower, x_upper = apply_scale(x_lower_limit, x_upper_limit, scale_factor)

        fe1 = _fe(x_lower, sigma=sigma, r=r, b=b, theta=theta)
        fe2 = _fe(x_upper, sigma=sigma, r=r, b=b, theta=theta)
        return sgld.ppf(p * (fe2 - fe1) + fe1, sigma=sigma, r=r, b=b, theta=theta)

    def mean(
        self,
        sigma: float,
        r: float,
        b: float,
        theta: float,
        x_lower_limit: float,
        x_upper_limit: float,
        scale_factor: float,
    ):
        """
        Cálculo da média.

        Parameters:
            sigma: Parâmetro.
            r: Parâmetro.
            b: Parâmetro.
            theta: Parâmetro.
            x_lower_limit: Limite inferior.
            x_upper_limit: Limite superior.
            scale_factor: fator de escala que divide o x.

        Returns:
            Valor da média.
        """
        return self._mean_numeric(sigma, r, b, theta, x_lower_limit, x_upper_limit, scale_factor)

    def std(
        self,
        sigma: float,
        r: float,
        b: float,
        theta: float,
        x_lower_limit: float,
        x_upper_limit: float,
        scale_factor: float,
    ) -> float:
        """
        Cálculo do desvio padrão.

        Parameters:
            sigma: Parâmetro.
            r: Parâmetro.
            b: Parâmetro.
            theta: Parâmetro.
            x_lower_limit: Limite inferior.
            x_upper_limit: Limite superior.
            scale_factor: fator de escala que divide o x.

        Returns:
            Valor da desvio padrão.
        """
        return self._std_numeric(
            sigma=sigma,
            r=r,
            b=b,
            theta=theta,
            x_lower_limit=x_lower_limit,
            x_upper_limit=x_upper_limit,
            scale_factor=scale_factor,
        )

    def _mean_numeric(
        self,
        sigma: float,
        r: float,
        b: float,
        theta: float,
        x_lower_limit: float,
        x_upper_limit: float,
        scale_factor: float,
    ):
        x_lower, x_upper = apply_scale(x_lower_limit, x_upper_limit, scale_factor)

        result = quad(
            lambda x: x * self.pdf(x, sigma, r, b, theta, x_lower_limit, x_upper_limit, scale_factor),
            x_lower,
            x_upper,
            limit=500,
        )

        if result[1] > 1.0e-4:
            print(f"Problema na convergencia da integral {result[1]}")

        return result[0]

    def _std_numeric(
        self,
        sigma: float,
        r: float,
        b: float,
        theta: float,
        x_lower_limit: float,
        x_upper_limit: float,
        scale_factor: float,
    ) -> float:
        x_lower, x_upper = apply_scale(x_lower_limit, x_upper_limit, scale_factor)

        mean = sgld.mean(sigma=sigma, r=r, b=b, theta=theta)
        result = quad(
            lambda x: x
            * x
            * self.pdf(
                x,
                sigma,
                r,
                b,
                theta,
                x_lower_limit,
                x_upper_limit,
                scale_factor,
            ),
            x_lower,
            x_upper,
            limit=500,
        )

        mean = self.mean(
            sigma=sigma,
            r=r,
            b=b,
            theta=theta,
            x_lower_limit=x_lower_limit,
            x_upper_limit=x_upper_limit,
            scale_factor=scale_factor,
        )

        if result[1] > 1.0e-4:
            print(f"Problema na convergencia da integral {result[1]}")

        var = result[0] - mean * mean

        return sqrt(var)


lognorm_t = LogNormalTrunked()
sgld_lower_t = SGLDLowerTrunked()
sgld_lower_upper_t = SGLDLowerUpperTrunked()
