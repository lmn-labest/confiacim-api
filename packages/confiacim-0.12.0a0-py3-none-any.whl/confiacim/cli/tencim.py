from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console

from confiacim.controllers.tencim import run as run_controller
from confiacim.erros import InputDirNotExists, TencimRunError
from confiacim.logger import get_logger
from confiacim.verbose import VerboseLevel

tencim_app = typer.Typer()
logger = get_logger()

console = Console()


@tencim_app.command(name="run")
def cli_run(
    input_dir: Annotated[Path, typer.Argument(..., help="Diretório dos arquivos de entra.")],
    output_dir: Annotated[Optional[Path], typer.Argument(..., help="Diretório dos arquivos de saida.")] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Modo verboso.")] = False,
):
    """
    Comando que executa o Tencim usando os arquivos base .dat. Os arquivo de entrada
    são os estáticos. Este comando funciona extamente como chamar o Tencim1D manualmente
    no console.
    """

    try:
        verbose_level = VerboseLevel.LEVEL_2 if verbose else VerboseLevel.LEVEL_1
        run_controller(
            input_dir=input_dir,
            output_dir=output_dir,
            verbose_level=verbose_level,
        )
    except InputDirNotExists as e:
        console.print(f"[red]Error[/red]: {e}")
        logger.error(e)
        raise typer.Exit(1) from e

    except TencimRunError as e:
        console.print(f"[red]Error[/red]: Erro no tencim\n{e}")
        logger.error("Erro no tencim. Ver simulation.log para mais informações.")
        logger_simulation = get_logger("simulation")
        logger_simulation.error(e)
        raise typer.Exit(1) from e
