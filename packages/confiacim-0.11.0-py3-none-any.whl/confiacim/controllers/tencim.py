"""
O módulo contem controladores para serem usando na `CLI` e na `API`.
"""

from pathlib import Path

import typer
from rich.console import Console

from confiacim.erros import InputDirNotExists
from confiacim.file_folder_handlers import default_output_dir
from confiacim.logger import get_logger, set_logger
from confiacim.tencim.standalone import run_tencim
from confiacim.timer import Timer

logger = get_logger()

determ_app = typer.Typer()

console = Console()


def run(
    *,
    input_dir: Path,
    output_dir: Path | None,
    verbose_level: int,
):
    """
    Rodando a simulação do tencim standalone. Roda simulação usando os *.dat. Funcionada
    simular a chamadar o tencim direto.

    Parameters:
        input_dir: Ditetório do arquivo de entrada.
        output_dir: Ditetório do arquivo de saida.
        verbose_level: Nivel de verbosidade.
    """

    if not Path(input_dir).exists():
        raise InputDirNotExists(input_dir)

    if not output_dir:
        output_dir = default_output_dir(input_dir)

    set_logger(logfile=input_dir / "simulation.log", name="simulation")

    logger.info(f"Análise do tencim: {input_dir=} {output_dir=}")

    with Timer("Tencim Analysis", print_time=verbose_level):
        run_tencim(
            input_dir=input_dir,
            output_dir=output_dir,
            verbose_level=verbose_level,
            console=console,
        )
