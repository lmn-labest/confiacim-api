"""Modulo que gerencia e exceuta a iteração do **FORM** utilizando o `tencim`."""

import os
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Type

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from .files_generator import Genarator
from .rc import RCCriteria, rc_stats
from .runner import TencimRunner, TencimRunnerDeterministic
from confiacim.conf import TencimExcMode, settings
from confiacim.constants import COLORS
from confiacim.file_folder_handlers import (
    abs_original_dir,
    base_work_tmpdir,
    check_tencim_exec,
    clean_temporary_dir,
    copy_exec_tencim,
    copy_list_files,
    exec_dir,
    get_template_dir,
    list_files,
    tmp_workdir,
)
from confiacim.run_statistics import confiacim_statistics
from confiacim.samples import Sample
from confiacim.timer import Timer

console = Console()


def _cpu_count() -> int:
    ncpus = os.cpu_count() or 1
    return int(ncpus * 0.5)


def _active_workers(samples: list | tuple) -> int:
    return min(len(samples), max(_cpu_count(), 1))


def run_samples_iteration_i(
    *,
    samples: list[Sample] | tuple[Sample],
    input_dir: Path,
    output_dir: Path,
    iteration: int = 1,
    rc_criteria: RCCriteria = RCCriteria.MOHR_COULOMB,
    RunnerClass: type[TencimRunner] = TencimRunner,
    verbose: bool = True,
    save_intermediate_files: bool = False,
) -> dict[str, dict[str, float] | None]:
    """
    Função executa simulações da iteração `i`.

    Parameters:
        samples: Lista da amostras.
        input_dir: Diterório do arquivo de entrada.
        output_dir: Diterório do arquivo de saida.
        iteration: Número da iteração do **FORM**.
        rc_criteria: Critério do **RC**.
        RunnerClass: Classe que executa o `tencim`.
        verbose: Nivel de verbosidade.
        save_intermediate_files: Salva os arquivos intermediarios da simulação.

    Returns:
        `RCs` das amostras.
    """

    rcs = {}
    original_dir = abs_original_dir()  # TODO: Melhorar o nome dessa função
    src_exec_dir = exec_dir(original_dir)  # TODO: Melhorar o nome dessa função
    tmpdir = base_work_tmpdir(original_dir)

    # TODO: Codigo repetido
    if input_dir.is_absolute():
        abs_path_input_dir = input_dir
    else:
        abs_path_input_dir = original_dir / input_dir

    if output_dir.is_absolute():
        abs_path_output_dir = output_dir
    else:
        abs_path_output_dir = original_dir / output_dir

    generator = Genarator(get_template_dir(abs_path_input_dir))

    # TODO: botar isso na classe TencimRunner
    check_tencim_exec(src_exec_dir)

    # Setup iteration
    was_generated = setup_iteration(samples, tmpdir, src_exec_dir, abs_path_input_dir, generator, verbose)

    # Run simulation
    with Timer("", print_time=verbose) as t:
        workers = run_simulations(
            samples=samples,
            tmpdir=tmpdir,
            was_generated=was_generated,
            original_dir=original_dir,
            abs_path_output_dir=abs_path_output_dir,
            iteration=iteration,
            exc_mode=settings.EXEC_TENCIM_MODE,
            RunnerClass=RunnerClass,
            verbose=verbose,
            save_intermediate_files=save_intermediate_files,
        )

    # posprocess
    rcs = simulation_rcs(samples, tmpdir, rc_criteria)

    clean_temporary_dir(tmpdir)

    # run_statics
    confiacim_statistics.workers = workers
    confiacim_statistics.exc_mode = settings.EXEC_TENCIM_MODE
    confiacim_statistics.tencim_time += t.get_wall_time()

    return rcs


def setup_iteration(
    samples: list[Sample] | tuple[Sample],
    tmpdir: TemporaryDirectory,
    src_exec_dir: Path,
    abs_path_input_dir: Path,
    generator: Genarator,
    verbose: bool = True,
) -> dict[str, bool]:
    """
    Função que copia e gera os arquivos necessários para rodar as simulações dessa iteração.

    Parameters:
        samples: Lista da amostras.
        tmpdir: Diretório temporário base onde as analises serão rodadas.
        src_exec_dir: Diterório donde esta o `tencim`.
        abs_path_input_dir: Camminho absoluto dos arquivos de entrada.
        generator: gerador dos arquivos de entrada para simulação **FORM**.
        verbose: Nivel de verbosidade.

    Returns:
        Retorna quais arquivos foram gerados.
    """

    for s in samples:
        sample_name, averages = s.name, s.averages

        if verbose:
            panel = Panel(Text(f"Sample name: {sample_name}", style="green"))
            console.print(panel)

        # setup
        workdir = tmp_workdir(tmpdir, sample_name)

        copy_exec_tencim(src_exec_dir, workdir)

        input_files = list_files(abs_path_input_dir, "*.dat")
        copy_list_files(input_files, workdir)

        # generate files
        was_generated = generator.all(averages, workdir)

        # TODO: Repensar isso
        if verbose:
            if was_generated.get("materials"):
                console.print("Generated materials.dat file.", style=COLORS[0])
            if was_generated.get("hidrationprop"):
                console.print("Generated hidrationprop.dat file.", style=COLORS[0])
            if was_generated.get("initialtemperature"):
                console.print("Generated initialtemperature.dat file.", style=COLORS[0])
            if was_generated.get("loads"):
                console.print("Generated loads.dat file.", style=COLORS[0])

    return was_generated


def run_simulations(
    *,
    samples: list[Sample] | tuple[Sample],
    tmpdir: TemporaryDirectory,
    was_generated: dict[str, bool],
    original_dir: Path,
    abs_path_output_dir: Path,
    iteration: int,
    exc_mode: int,
    RunnerClass: Type[TencimRunner] = TencimRunner,
    verbose: bool = True,
    save_intermediate_files: bool = False,
) -> int:
    """
    Chama os tencim para executar as análises das amostras.

    Parameters:
        samples: Lista da amostras.
        tmpdir: Diretório temporário base onde as analises serão rodadas.
        was_generated: Quais arquivos foram gerados.
        original_dir: Diterório donde esta o `tencim`.
        abs_path_output_dir: Camminho absoluto do diretorio dos arquivos de saida.
        iteration: Número da iteração do **FORM**.
        exc_mode: Modo de execução.
        RunnerClass: Classe que executa o `tencim`.
        verbose: Nivel de verbosidade.
        save_intermediate_files: Salva os arquivos intermediarios da simulação.

    Returns:
        Numero de workers utilizados para excutar as amostras.
    """

    runner = RunnerClass(output_base_dir=abs_path_output_dir, iteration=iteration)

    if exc_mode == TencimExcMode["MULTIPROC"].value and not isinstance(runner, TencimRunnerDeterministic):
        workers = _active_workers(samples)
        if verbose:
            console.print(f"\nRunning Tencim on {workers} workers ...", style="green", end=" ")
        with ProcessPoolExecutor(max_workers=workers) as executor:
            for s in samples:
                sample_name = s.name

                workdir = tmp_workdir(tmpdir, sample_name)

                future = executor.submit(
                    runner.run,
                    sample_name,
                    was_generated,
                    workdir,
                    original_dir,
                    save_intermediate_files,
                )

            future.result()

    else:
        workers = 1
        if verbose:
            console.print("\nRunning Tencim ...", style="green", end=" ")
        for s in samples:
            sample_name = s.name
            workdir = tmp_workdir(tmpdir, sample_name)
            runner.run(sample_name, was_generated, workdir, original_dir, save_intermediate_files)

    return workers


def simulation_rcs(
    samples: list[Sample] | tuple[Sample],
    tmpdir: TemporaryDirectory,
    rc_criteria: RCCriteria = RCCriteria.MOHR_COULOMB,
) -> dict[str, dict[str, float] | None]:
    """
    Lê o `RC` das simulações das amostras

    Parameters:
        samples: Lista da amostras.
        tmpdir: Diretório temporário base onde as analises serão rodadas.
        rc_criteria: Critério do **RC**.

    Returns:
        Retorna o `RC` mínimo e ultimo das amostras.

    Raises:
        EmptyRCFile: Arquivo de `RC`vazio.
    """
    rcs: dict[str, dict[str, float] | None] = {}
    for s in samples:
        sample_name = s.name
        workdir = tmp_workdir(tmpdir, sample_name)
        try:
            rcs[sample_name] = rc_stats(workdir / f"{sample_name}_RC.txt", rc_criteria)
        except FileNotFoundError:
            rcs[sample_name] = None

    return rcs
