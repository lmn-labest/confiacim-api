from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from confiacim.erros import (
    DirsResultsNotFound,
    ItFolderNotFound,
    MatplotlibModuleError,
    PlotlyModuleError,
    RCFileNotFound,
    SimulationFolderNotFound,
)
from confiacim.logger import get_logger
from confiacim.plot.graphs import rc_all_matplotlib, rc_all_plotly, rc_it_matplotlib

plot_app = typer.Typer()

console = Console()
logger = get_logger()


@plot_app.command(name="all")
def plot_all(
    output_dir: Annotated[Path, typer.Argument(..., help="Diretório dos arquivos de saida.")],
    save: Annotated[bool, typer.Option("--save", "-s", help="Salvar gráfico.")] = False,
):
    """Plotando os RCs de todos as simulações."""

    try:
        rc_all_matplotlib(output_dir / "form", save)
    except (DirsResultsNotFound, RCFileNotFound, MatplotlibModuleError, SimulationFolderNotFound) as e:
        console.print(f"[red]Error[/red]: {e}")
        logger.error(e)
        raise typer.Exit(1) from e


@plot_app.command(name="it")
def plot_it(
    it: Annotated[int, typer.Argument(..., help="Iteração específica")],
    output_dir: Annotated[Path, typer.Argument(..., help="Diretório dos arquivos de saida.")],
    save: Annotated[bool, typer.Option("--save", "-s", help="Salvar gráfico.")] = False,
):
    """Plotando os RCs das simulações da iteração it"""

    try:
        rc_it_matplotlib(it, output_dir / "form", save)
    except (ItFolderNotFound, RCFileNotFound, MatplotlibModuleError, SimulationFolderNotFound) as e:
        console.print(f"[red]Error[/red]: {e}")
        logger.error(e)
        raise typer.Exit(1) from e


plotly_app = typer.Typer()


@plotly_app.command(name="all")
def plotly_all(
    output_dir: Annotated[Path, typer.Argument(..., help="Diretório dos arquivos de saida.")],
):
    """Plotando os RCs de todos as simulações."""

    try:
        rc_all_plotly(output_dir / "form")
    except (RCFileNotFound, DirsResultsNotFound, PlotlyModuleError, SimulationFolderNotFound) as e:
        console.print(f"[red]Error[/red]: {e}")
        logger.error(e)
        raise typer.Exit(1) from e
