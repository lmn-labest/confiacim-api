"""
Modulo que lida com a `RC` simulação

Classes e funções deste módulo:

- TimeMinimalRC
- first_timestamp_minimal_rc
- rc_stats

---
"""

import csv
from dataclasses import dataclass
from enum import Enum
from math import inf
from pathlib import Path

import numpy as np

from confiacim.erros import EmptyRCFile
from confiacim.tencim.results import RCResults


class RCCriteria(Enum):
    """Tipos de criteiros de RC."""

    MHOR_COULOMB = 3
    """Criterio de Mhor Coulomb"""
    RANKINE = 5
    """Criterio de Rankine"""

    @staticmethod
    def str_to_enum(value):
        convert = {
            "mohr-coulomb": RCCriteria.MHOR_COULOMB,
            "rankine": RCCriteria.RANKINE,
        }
        return convert.get(value)


@dataclass(frozen=True)
class TimeMinimalRC:
    """
    `RC` minimo da simulação.

    Parameters:
        istep: Passo de tempo do `RC` mínimo.
        t: Tempo do `RC` mínimo.
        rc: valor do `RC` mínimo.
    """

    istep: int | np.int32 | np.int64
    t: float | np.float64
    rc: float | np.float64


def _rc_parser(line: list[str], method: RCCriteria) -> float:
    return float(line[0].split()[method.value])


def first_timestamp_minimal_rc(results: RCResults) -> dict[str, TimeMinimalRC]:
    """
    Obtém o passo de tempo do RC minimo do `RC`minimo para ambos os métodos.

    Info:
        Caso o mínimo seja um patamar o tempo será o do menor tempo.

    Parameters:
        results: Resultado de `RC` da analise.

    Returns:
        Retorna o RC minimo de ambos os métodos.
    """

    dict_ = {}

    istep, t_min, rc_min = 0, 0, inf
    for i, t, rc in zip(results.istep, results.t, results.rc_mhor_coulomb):
        if rc_min > rc:
            istep, t_min, rc_min = i, t, rc

    dict_["rc_mhor_coulomb"] = TimeMinimalRC(istep, t_min, rc_min)

    istep, t_min, rc_min = 0, 0, inf
    for i, t, rc in zip(results.istep, results.t, results.rc_rankine):
        if rc_min > rc:
            istep, t_min, rc_min = i, t, rc

    dict_["rc_rankine"] = TimeMinimalRC(istep, t_min, rc_min)

    return dict_


def rc_stats(path_rc_file: Path, method: RCCriteria = RCCriteria.MHOR_COULOMB) -> dict[str, float]:
    """
    Le o `RC` do arquivo e pega o menor e o último.

    Parameters:
        path_rc_file: Caminho para o arquivo `RC`.
        method: O metodo de calculo de `RC`.

    Returns:
        Retorna o dicionário com menor e ultimo `RC`.

    Raises:
        EmptyRCFile: Arquivo de `RC`vazio.
    """
    # TODO: De leitura repetido
    with open(path_rc_file, encoding="utf-8") as fp:
        reader = csv.reader(fp)

        try:
            next(reader)
        except StopIteration:
            raise EmptyRCFile(f"Arquivo {path_rc_file}_RC.txt RC está vazio.") from StopIteration

        rc_min = inf
        for line in reader:
            rc_min = min(rc_min, _rc_parser(line, method))
            last_line = line

        return {"min": rc_min, "last": _rc_parser(last_line, method)}
