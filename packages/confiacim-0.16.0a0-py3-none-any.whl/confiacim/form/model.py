"""
Definição da resultado do **FORM**

Classes e funções deste módulo:

- FormResult

---
"""

from dataclasses import asdict, dataclass

import numpy as np


@dataclass(frozen=True)
class FormResult:
    """
    Resultado do simulação form

    Attributes:
        beta: Parametro do Form.
        resid: Residuo final da iteração do Form.
        rcs: RCs final.
        it: Numero de iterção do Formm.
        Pf: Probabilidade de falha.
        importance_factors: Fator de importância.
        omission_factors: Fator de omissão.

    """

    beta: float
    resid: float
    rcs: dict
    it: int
    Pf: float
    importance_factors: np.ndarray
    omission_factors: np.ndarray

    @property
    def infos(self) -> dict:
        """
        Retorna as informações brutas na forma de um dicionário.

        Returns:
            Atributos da classe.
        """
        return asdict(self)

    def json_results(self) -> dict:
        """
        Retorna as informações tratadas na forma de um dicionário.

        Returns:
            Returna as informações em uma versão alternativas mais acessivel para ser escrita em formato json.
        """
        results_json = self.infos
        del results_json["rcs"]
        importance = results_json.pop("importance_factors")
        omission = results_json.pop("omission_factors")

        variables = [k for k in self.rcs if k != "base"]

        dict_ = {}
        for v, i, o in zip(variables, importance, omission):
            dict_[v] = {"importance_factor": i, "omission_factor": o}
        results_json["variables"] = dict_

        return results_json
