import json
from dataclasses import asdict, is_dataclass

import numpy as np


class JSONEncoder2Dataclasses(json.JSONEncoder):
    """
    Classe que expande JSONEncoder para dataclasses.
    """

    def default(self, o):
        if is_dataclass(o):
            return asdict(o)
        if np.issubdtype(o, np.int32) or np.issubdtype(o, np.int64):
            return int(o)
        if np.issubdtype(o, np.float64):
            return float(o)
        return super().default(o)
