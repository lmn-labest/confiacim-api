"""
Checa as macros necessárias no arquivo de entrada da simulação do tencim

Classes e funções deste módulo:

- check_for_nocliprc_macro

---
"""

from pathlib import Path

from confiacim.erros import MissingNoRcNoClip


def check_for_nocliprc_macro(*, case_file: Path) -> None:
    """
    Verifica se a macro `nocliprc`esta no arquivo de entrada.

    Parameters:
        case_file: Caminho para carquivo de entrada do `tencim`.

    Raises:
        MissingNoRcNoClip: O arquivo não tem a macro `nocliprc`.
    """

    str_content = case_file.read_text()

    if "nocliprc" not in str_content:
        raise MissingNoRcNoClip("A macro nocliprc é necessária para utilizar a análise FORM.")
