"""
Neste modulo temos a definição das distribuição das variaveis aleatórias.
Novas distruibuições devem ser adicionandas aqui.

---
"""

from abc import ABC, abstractmethod
from enum import Enum, unique
from functools import partial
from math import exp, log, pi, sqrt
from typing import Any

from scipy.stats import gumbel_r, lognorm, norm, triang, weibull_min

from confiacim.variables.sgld_dist import sgld
from confiacim.variables.truncated_dist import (
    lognorm_t,
    sgld_lower_t,
    sgld_lower_upper_t,
)
from confiacim.variables.weibull_params import weibull_k_lambda_from_mean_std


@unique
class DistributionNames(Enum):
    """
    Ditruibuição disponiveis.

    Info:
        - `NORMAL`: Distribuição normal.
        - `LOGNORMAL`: Distribuição lognormal.
        - `LOGNORMAL_T`: Distribuição lognormal truncada.
        - `GUMBEL_R`: Distribuição de gumbel com cauda a direita.
        - `WEIBULL_MIN`: Distribuição de Weibull com dois parâmetros.
        - `TRIANG`: Distribuição triagular de três parâmetros.
        - `SGLD`: Distribuição SGLD.
        - `SGLD_LOWER_T`: Distribuição SGLD truncada.
        - `SGLD_LOWER_UPPER_T`: Distribuição SGLD truncamento inferior e superior.
    """

    NORMAL = "normal"
    LOGNORMAL = "lognormal"
    LOGNORMAL_T = "lognormal_t"
    GUMBEL_R = "gumbel_r"
    WEIBULL_MIN = "weibull_min"
    TRIANG = "triang"
    SGLD = "sgld"
    SGLD_LOWER_T = "sgld_lower_t"
    SGLD_LOWER_UPPER_T = "sgld_lower_upper_t"

    @classmethod
    def has_value(cls, value):
        return value.upper() in cls._member_names_

    @classmethod
    def options(cls):
        return [d.name.lower() for d in cls]


class DistBase(ABC):
    """
    Classe base para as distribuições.

    Info:
        dist: Será atribuido a uma classe do `scipy`.

    Danger:
        Esta classe não deve ser usada diretamente.
    """

    dist: Any = None

    @abstractmethod
    def _parameters(self) -> tuple[float, ...]: ...

    @abstractmethod
    def _params_dist(self) -> dict[str, float]: ...

    @property
    def pdf(self):
        """Função densidade de probabilidade da distruibuição `(pdf)`"""
        return partial(self.dist.pdf, **self._params_dist())

    @property
    def cdf(self):
        """Função densidade de probabilidade acumulada da distruibuição `(cdf)`"""
        return partial(self.dist.cdf, **self._params_dist())

    @property
    def ppf(self):
        """Inversa da função densidade de probabilidade acumulada da distruibuição `(ppf)`"""
        return partial(self.dist.ppf, **self._params_dist())

    @property
    def mean(self):
        """Retorna a média da distruibuição calculada direto da distribuição"""
        return self.dist.mean(**self._params_dist())

    @property
    def std(self):
        """Retorna o desvio padrão da distruibuição calculada direto da distribuição"""
        return self.dist.std(**self._params_dist())

    def __str__(self) -> str:
        """
        Representação da distruibuição para string

        Returns:
            String na forma: <DistLogNormal\\> {'s': '9.9751e-02', 'scale': '9.9504e-01'}.
        """
        d = {k: f"{v:.4e}" for k, v in self._params_dist().items()}
        return f"<{self.__class__.__name__}> {d}"

    @classmethod
    def infos(cls) -> dict:
        """
        Returns:
            dict: Retorna a class e os parametros da distribuição.
        """
        params = [name for name in cls.__init__.__annotations__.keys() if name != "return"]
        return dict(class_=cls, params=tuple(params))


class DistNormal(DistBase):
    """
    Classe da distruibução `normal`.

    Info:
        dist: função `norm` do `scipy`.
    """

    dist = norm

    def __init__(self, *, mean: float, cov: float) -> None:
        """
        Inicializador da classe.

        Parameters:
            mean: média.
            cov: coeficiente de variação.
        """

        self._mean, self._cov, self._sigma = mean, cov, mean * cov
        _, sig = self._parameters()
        self.loc = self._mean
        self.scale = sig

    def _parameters(self) -> tuple[float, float]:
        """
        Returns:
            Returna uma tupla com a média e o desvio padrão.
        """
        return self._mean, self._sigma

    def _params_dist(self) -> dict[str, float]:
        """Esta função serve para ajustar os paramentros necessários paras as diferentes distribuição o scipy"""
        return {"loc": self.loc, "scale": self.scale}


class DistLogNormal(DistBase):
    """
    Classe da distruibução `lognormal`.

    Info:
        dist: função `lognorm` do `scipy`.
    """

    dist = lognorm

    def __init__(self, *, mean: float, cov: float) -> None:
        """
        Inicializador da classe.

        Parameters:
            mean: média
            cov: coeficiente de variação
        """
        self._mean, self._cov, self._sigma = mean, cov, mean * cov
        std_normal, mean_normal = self._parameters()
        self.s = std_normal
        self.scale = exp(mean_normal)

    def _parameters(self) -> tuple[float, float]:
        """
        Returns:
            Returna uma tupla com a média e o desvio padrão da distruibuiçao normal associada
        """

        def std_normal(cov: float) -> float:
            """Desvio padrão da distruibuiçao normal associada

            Args:
                cov: coeficiente de variação

            Returns:
                float: valor do desvio padrão da distruibuiçao normal associada
            """
            return sqrt(log(1.0 + cov**2))

        def mean_normal(mean: float, cov: float) -> float:
            """Média da distruibuiçao normal associada

            Args:
                mean: Média da distruibuição lognormal
                cov: coeficiente de variação da distruibuição lognormal

            Returns:
                float: valor da média distruibuiçao normal associada
            """
            return log(mean / sqrt(1.0 + cov**2))

        return std_normal(self._cov), mean_normal(self._mean, self._cov)

    def _params_dist(self) -> dict[str, float]:
        """Esta função serve para ajutar os paramentros necessarios paras as diferentes distribuição o scipy"""
        return {"s": self.s, "scale": self.scale}


class DistLogNormalTrunked(DistLogNormal):
    """
    Classe da distruibução `lognormal` truncada.
    """

    dist = lognorm_t

    def __init__(self, *, mean: float, cov: float, b: float) -> None:
        """
        Inicializador da classe.

        Parameters:
            mean: média.
            cov: coeficiente de variação.
            b: parâmetro limite superior.
        """
        super().__init__(mean=mean, cov=cov)
        self.b = b

    def _params_dist(self) -> dict[str, float]:
        """Esta função serve para ajutar os paramentros necessarios paras as diferentes distribuição"""
        return {"s": self.s, "scale": self.scale, "b": self.b}


class DistGumbelR(DistBase):
    """
    Classe da distruibução `gumbel_r`.

    Info:
        dist: classe `gumbel_r` do `scipy`.
    """

    dist = gumbel_r

    def __init__(self, *, mean: float, cov: float) -> None:
        """
        Inicializador da classe.

        Parameters:
            mean: média
            cov: coeficiente de variação.
        """
        self._mean, self._cov, self._sigma = mean, cov, mean * cov
        alpha, u = self._parameters()
        self.loc = u
        self.scale = 1.0 / alpha

    def _parameters(self) -> tuple[float, float]:
        """
        Returns:
            Returna uma tupla com a alpha, u.
        """

        def alpha(sig: float) -> float:
            return (pi / sqrt(6)) * (1.0 / sig)

        def u(mean: float, alpha: float) -> float:
            return mean - 0.5772 / alpha

        alpha_ = alpha(self._sigma)
        return alpha_, u(self._mean, alpha_)

    def _params_dist(self) -> dict[str, float]:
        """Esta função serve para ajutar os paramentros necessarios paras as diferentes distribuição o scipy"""
        return {"loc": self.loc, "scale": self.scale}


class DistWeibullMin(DistBase):
    """
    Classe da distruibução `weibull_min`.

    Info:
        dist: classe `gumbel_min` do `scipy`.
    """

    dist = weibull_min

    def __init__(self, *, mean: float, cov: float) -> None:
        """
        Inicializador da classe.

        Parameters:
            mean: média
            cov: coeficiente de variação.
        """
        self._mean, self._cov, self._sigma = mean, cov, mean * cov
        k, lambda_ = self._parameters()
        self.c = k
        self.scale = lambda_

    def _parameters(self) -> tuple[float, float]:
        """
        Returns:
            Returna uma tupla com a k, lambda.
        """

        k, lambda_ = weibull_k_lambda_from_mean_std(self._mean, self._sigma, exception=True)

        return k, lambda_

    def _params_dist(self) -> dict[str, float]:
        """Esta função serve para ajutar os paramentros necessarios paras as diferentes distribuição o scipy"""
        return {"c": self.c, "scale": self.scale}


class DistTriang(DistBase):
    """
    Classe da distruibução `triang`.

    Info:
        dist: classe `gumbel_min` do `scipy`.
    """

    dist = triang

    def __init__(self, *, min: float, max: float, mod: float) -> None:
        """
        Inicializador da classe.

        Parameters:
            min: menor valor
            max: maior valor
            mod: valor mais frequente
        """
        self._min, self._max, self._mod = min, max, mod

        self.loc = min
        self.scale = max - min
        self.c = (mod - min) / self.scale

    def _parameters(self) -> tuple[float, float, float]:
        """
        Returns:
            Returna uma tupla com x, y, z.

        Info:
            Esta método nesta distruição não é muito util. Foi mantido apenas para manter o protocolo da classe

        """

        return self._min, self._max, self._mod

    def _params_dist(self) -> dict[str, float]:
        """Esta função serve para ajutar os paramentros necessários paras as diferentes distribuição o scipy"""
        return {"loc": self.loc, "scale": self.scale, "c": self.c}


class DistSGLD(DistBase):
    """
    Classe da distruibução `SGLD`.
    """

    dist = sgld

    def __init__(self, sigma: float, r: float, b: float, theta: float) -> None:
        """
        Inicializador da classe.

        Parameters:
            sigma: Parâmetro.
            r: Parâmetro.
            b: Parâmetro.
            theta: Parâmetro.
        """

        self._sigma = sigma
        self._r = r
        self._b = b
        self._theta = theta

    def _parameters(self) -> tuple[float, float, float, float]:
        """
        Returns:
            Returna uma tupla com sigma, r, b e theta.

        Info:
            Esta método nesta distruição não é muito util. Foi mantido apenas para manter o protocolo da classe

        """

        return self._sigma, self._r, self._b, self._theta

    def _params_dist(self) -> dict[str, float]:
        return {"sigma": self._sigma, "r": self._r, "b": self._b, "theta": self._theta}


class DistSGLDTrunked(DistBase):
    """
    Classe da distruibução `SGLD` truncada.
    """

    dist = sgld_lower_t

    def __init__(self, sigma: float, r: float, b: float, theta: float, x_lower_limit: float) -> None:
        """
        Inicializador da classe.

        Parameters:
            sigma: Parâmetro.
            r: Parâmetro.
            b: Parâmetro.
            theta: Parâmetro.
            x_lower_limit: Limite inferior.
        """

        self._sigma = sigma
        self._r = r
        self._b = b
        self._theta = theta
        self._x_lower_limit = x_lower_limit

    def _parameters(self) -> tuple[float, float, float, float, float]:
        """
        Returns:
            Returna uma tupla com sigma, r, b, theta e x_lower_limit.

        Info:
            Esta método nesta distruição não é muito util. Foi mantido apenas para manter o protocolo da classe

        """

        return self._sigma, self._r, self._b, self._theta, self._x_lower_limit

    def _params_dist(self) -> dict[str, float]:
        return {
            "sigma": self._sigma,
            "r": self._r,
            "b": self._b,
            "theta": self._theta,
            "x_lower_limit": self._x_lower_limit,
        }


class DistSGLDLowerUpperTrunked(DistBase):
    """
    Classe da distruibução `SGLD` truncada com limite inferior e superior.
    """

    dist = sgld_lower_upper_t

    def __init__(
        self,
        sigma: float,
        r: float,
        b: float,
        theta: float,
        x_lower_limit: float,
        x_upper_limit: float,
        scale_factor: float,
    ) -> None:
        """
        Inicializador da classe.

        Parameters:
            sigma: Parâmetro.
            r: Parâmetro.
            b: Parâmetro.
            theta: Parâmetro.
            x_lower_limit: Limite inferior.
            x_upper_limit: Limite superior.
            scale_factor: fator de escala que divide o x.
        """

        self._sigma = sigma
        self._r = r
        self._b = b
        self._theta = theta
        self._x_lower_limit = x_lower_limit
        self._x_upper_limit = x_upper_limit
        self._scale_factor = scale_factor

    def _parameters(self) -> tuple[float, float, float, float, float, float, float]:
        """
        Returns:
            Returna uma tupla com sigma, r, b, theta, x_lower_limit, x_lower_limit e scale_factor.

        Info:
            Esta método nesta distruição não é muito util. Foi mantido apenas para manter o protocolo da classe

        """

        return self._sigma, self._r, self._b, self._theta, self._x_lower_limit, self._x_upper_limit, self._scale_factor

    def _params_dist(self) -> dict[str, float]:
        return {
            "sigma": self._sigma,
            "r": self._r,
            "b": self._b,
            "theta": self._theta,
            "x_lower_limit": self._x_lower_limit,
            "x_upper_limit": self._x_upper_limit,
            "scale_factor": self._scale_factor,
        }
