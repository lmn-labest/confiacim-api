"""
Modulo com estáticas de execuação

Classes e funções deste módulo:

- RunStatistics

---
"""

from dataclasses import asdict, dataclass


@dataclass
class RunStatistics:
    """
    Estátisticas de execuação.

    Parameters:
        total_time: Tempo total da análise.
        tencim_time: Tempo gasto nnas chamdas do `tencim`.
        workers: Número de chamadas simultanias do `tencim`.
        exc_mode: Modo de excução do `tencim`.
    """

    total_time: float = 0.0
    tencim_time: float = 0.0
    workers: int | None = None
    exc_mode: int | None = None

    def json(self) -> dict:
        """
        Converte a classe para um dicionário
        """
        return asdict(self)


confiacim_statistics = RunStatistics()
