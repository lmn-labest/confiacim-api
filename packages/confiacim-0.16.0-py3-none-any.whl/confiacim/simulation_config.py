"""
Modulo com as configurações da simulação e funcionalidades de leitura.
"""

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, Optional

import yaml
from yaml.loader import BaseLoader

from confiacim.erros import InvalidDistributionError, SimulationConfigFileError
from confiacim.variables import DistributionNames, StochasticVariable
from confiacim.variables.core import DIST_OPTIONS, DistInfos

RESULT_FILES_OPTIONS = "json,txt".split(",")
RC_CRITERIA_OPTIONS = "mohr-coulomb,rankine".split(",")


class ResultFilesInvalidOptionError(ValueError):
    def __init__(self, file_type: str):
        self.message = (
            f"Tipo do arquivo de saida '{file_type}' é inválido." f" As opções disponiveis são: {RESULT_FILES_OPTIONS}."
        )
        super().__init__(self.message)


class RCCriteriaInvalidOptionError(ValueError):
    def __init__(self, criteria: str):
        self.message = (
            f"Tipo de criterio '{criteria}' é inválido." f" As opções disponiveis são: {RC_CRITERIA_OPTIONS}."
        )
        super().__init__(self.message)


class JsonIndentValueError(ValueError): ...


@dataclass(frozen=True)
class FormConfig:
    """
    Classe com as configurações da simulação do **FORM**.

    Parameters:
        beta: Paramentro do **FORM**.
        gamma: Paramentro do **FORM**.
        delta: Delta das derivadas.
        tol: Tolerência do critério de parada do **FORM**.
        maxit: Número máximo de iterações do **FORM**.
        Nr: Parâmetro de relaxação do metodo **FORM**.
    """

    beta: float = 0.0
    delta: float = 0.01
    gamma: float = 0.0
    tol: float = 1.0e-04
    maxit: int = 100
    Nr: int = 1


@dataclass(frozen=True)
class MonteCarloConfig:
    """
    Classe com as configurações da simulação do **Monte Carlo**.

    Parameters:
        n_samples: Número de amostras do **Monte Carlo**.
        batch_size: Tamanho do lote do **Monte Carlo**.
        seed: Semente do **Monte Carlo**..
    """

    n_samples: int = 10_000
    batch_size: int = 100
    seed: Optional[int] = None


@dataclass(frozen=True)
class SimulationConfig:
    """
    Classe com as configurações da simulação.

    Parameters:
        variables: Lista de variaveis.
        form: Configurações do **FORM**.
        monte_carlo: Configurações do **Monte Carlo**.
        correlations: Informação das correlação entre as variáveis.
        result_files: Escrita dos resultados.
        json_indent: Identação dos arquivos json
    """

    variables: tuple[StochasticVariable, ...]
    form: Optional[FormConfig] = None
    monte_carlo: Optional[MonteCarloConfig] = None
    correlations: Optional[dict[str, float]] = None
    result_files: str = "json"
    json_indent: Optional[int] = None
    rc_criteria: str = "mohr-coulomb"

    @property
    def configs(self) -> dict:
        """
        Returns:
            Todas as configurações forma de um dicionário.
        """

        ditc_: dict[str, int | str | None | dict] = {
            "result_files": self.result_files,
            "json_indent": self.json_indent,
            "rc_criteria": self.rc_criteria,
        }

        if self.form:
            ditc_["form"] = asdict(self.form)

        if self.monte_carlo:
            ditc_["monte_carlo"] = asdict(self.monte_carlo)

        return ditc_

    @property
    def base_configs(self) -> dict:
        """
        Returns:
            Configurações forma de um dicionário.
        """
        return {
            "result_files": self.result_files,
            "json_indent": self.json_indent,
            "rc_criteria": self.rc_criteria,
        }

    @property
    def form_configs(self) -> dict:
        """
        Returns:
            Configurações do **FORM** na forma de um dicionário.
        """
        return asdict(self.form) if self.form else asdict(FormConfig())

    @property
    def monte_carlo_configs(self) -> dict:
        """
        Returns:
            Configurações do **Monte Carlo** na forma de um dicionário.
        """

        return asdict(self.monte_carlo) if self.monte_carlo else asdict(MonteCarloConfig())

    def __post_init__(self):
        for name, _ in self.__dataclass_fields__.items():
            if name == "result_files":
                self.validate_result_files(self.result_files)

            elif name == "json_indent":
                self.validate_json_indent(self.json_indent)

            elif name == "rc_criteria":
                self.validate_rc_criteria(self.rc_criteria)

    def validate_result_files(self, value):
        if value not in RESULT_FILES_OPTIONS:
            raise ResultFilesInvalidOptionError(file_type=value)
        return value

    def validate_rc_criteria(self, value):
        if value not in RC_CRITERIA_OPTIONS:
            raise RCCriteriaInvalidOptionError(criteria=value)
        return value

    def validate_json_indent(self, value):
        if value is None:
            return value

        try:
            value_ = int(value)
        except ValueError:
            raise JsonIndentValueError("O valor de 'json_indent' precisa ser um numero inteiro.")

        if value_ < 1:
            raise JsonIndentValueError("O valor de 'json_indent' precisa ser > 0.")

        return value

    @property
    def variable_names(self) -> tuple[str, ...]:
        """
        Returns:
            Retorna um tupla com o nome das váriaveis.
        """
        return tuple(v.name for v in self.variables)

    @property
    def infos(self) -> dict:
        """
        Returns:
            Informações completas na forma de um dicionário.
        """
        return {
            "variables": self.variables,
            "correlations": self.correlations,
            **self.configs,
        }

    @property
    def variables_infos(self) -> dict:
        """
        Returns:
            Informações completas na forma de um dicionário.
        """
        return {
            "variables": self.variables,
            "correlations": self.correlations,
        }


def _converte_fields(config, valid_fields, key) -> dict:
    dict_ = {}
    for field in config:
        if field not in valid_fields:
            raise SimulationConfigFileError(f"O campo '{field}' não é uma configuração válida para a chave '{key}'.")

        if field == "form":
            dict_["form"] = form_config_validations(config["form"])
            continue

        elif field == "monte_carlo":
            dict_["monte_carlo"] = monte_carlo_config_validations(config["monte_carlo"])
            continue

        try:
            cast = valid_fields[field]
            dict_[field] = cast(config[field])
        except ValueError:
            raise SimulationConfigFileError(f"O campo '{field}' não pode ser convertido.") from ValueError

    return dict_


def form_config_validations(data: dict) -> dict:
    """
    Validação das configs da simulação **FORM**.

    Parameters:
        data: Dados brutos dos arquivo `*.yml`.

    Returns:
        Dicionário com informações das configurações validados e convertidos.

    Raises:
        SimulationConfigFileError: Erro no arquivo `case.yaml`.
    """
    FORM_CONFIG_FIELDS: dict[str, Callable] = {
        "beta": float,
        "delta": float,
        "gamma": float,
        "tol": float,
        "maxit": int,
        "Nr": int,
    }

    dict_ = _converte_fields(data, FORM_CONFIG_FIELDS, "form")

    return dict_


def monte_carlo_config_validations(data: dict) -> dict:
    """
    Validação das configs da simulação **Monte Carlo**.

    Parameters:
        data: Dados brutos dos arquivo `*.yml`.

    Returns:
        Dicionário com informações das configurações validados e convertidos.

    Raises:
        SimulationConfigFileError: Erro no arquivo `case.yaml`.
    """
    MONTE_CARLO_CONFIG_FIELDS: dict[str, Callable] = {
        "n_samples": int,
        "batch_size": int,
        "seed": int,
    }

    dict_ = _converte_fields(data, MONTE_CARLO_CONFIG_FIELDS, "monte_carlo")

    return dict_


def config_validations(data: dict) -> dict:
    """
    Validação das configs da simulação.

    Parameters:
        data: Dados brutos dos arquivo `*.yml`.

    Returns:
        Dicionário com informações das configurações validados e convertidos.

    Raises:
        SimulationConfigFileError: Erro no arquivo `case.yaml`.
    """

    CONFIG_FIELDS: dict[str, Callable] = {
        "result_files": str,
        "json_indent": lambda v: None if v == "null" else int(v),
        "rc_criteria": str,
        "form": str,
        "monte_carlo": str,
    }

    dict_: dict[str, int | str | None | dict] = {}

    if not data.get("config"):
        return dict_

    config = data["config"].copy()

    dict_.update(_converte_fields(config, CONFIG_FIELDS, "config"))

    return dict_


def correlations_validation(data: dict, variables: list[dict]) -> dict[str, float] | None:
    """
    Validação das informações de correlação da variaveis aleatorias da simulação.

    Parameters:
        data: Dados brutos dos arquivo `*.yaml`.
        variables: Variaveis aleatórios validadas.

    Returns:
        Dicionário com informações de correlação validados e convertidos.

    Raises:
        SimulationConfigFileError: Erro no arquivo `case.yaml`.
    """

    if correlations := data.get("correlations"):
        variable_names = [v["name"] for v in variables]

        for k in correlations:
            v1, v2 = map(str.strip, k.split(","))
            if (v1 not in variable_names) or (v2 not in variable_names):
                raise SimulationConfigFileError(
                    f"A correlação '{k}' não é de uma variável válida. " f"As variáveis válidas são: {variable_names}."
                )

        dict_ = {}
        for k, v in correlations.items():
            try:
                dict_[k] = float(v)
            except ValueError:
                raise SimulationConfigFileError(f"O valor '{v}' da correlação '{k}' é invalido.") from ValueError

        return dict_

    return None


def load_config(file_path: Path) -> SimulationConfig:
    """
    Carregando as configurações lidar no arquivo `*.ymal`.

    Parameters:
        file_path: Diretório do arquivo `*.yaml`.

    Returns:
        Retorna a configurações da simulações validadads e convertidas

    Raises:
        SimulationConfigFileError: Erro no arquivo `case.yaml`.
        InvalidDistributionError: Distribuição inválida.
    """

    data = read_simulation_config(file_path)

    validated = validation(data)
    variables = tuple(
        [
            StochasticVariable(
                **({key: value for key, value in v.items() if key != "dist"}),
                dist_infos=DistInfos(**v["dist"]),
            )
            for v in validated["variables"]
        ]
    )

    config = validated.get("config", {})
    if validated["config"].get("form"):
        config["form"] = FormConfig(**validated["config"]["form"])

    if validated["config"].get("monte_carlo"):
        config["monte_carlo"] = MonteCarloConfig(**validated["config"]["monte_carlo"])

    sim = SimulationConfig(
        variables=variables,
        correlations=validated.get("correlations"),
        **config,
    )

    return sim


def read_simulation_config(file_path: Path) -> dict:
    """
    Lendo o aquivo de configuração da simulacao do **FORM**.

    Parameters:
        file_path: Diretório do arquivo `*.yaml`.

    Returns:
        Retorna um dicionário com as informções do `*.yaml`.
    """

    conf = {}

    with open(file_path, encoding="utf-8") as f:
        conf = yaml.load(f, Loader=BaseLoader)

    return conf


def validation(data: dict) -> dict:
    """
    Validação das informações lidos no  `*.yaml`.

    Parameters:
        data: Dados brutos dos arquivo `*.yaml`.

    Returns:
        Dicionário com informações validados e convertidos.

    Raises:
        SimulationConfigFileError: Erro no arquivo `case.yaml`.
        InvalidDistributionError: Distribuição inválida.
    """

    validated: dict[str, list | dict] = {}

    list_variables = variables_validation(data)
    validated["variables"] = list_variables

    if correlations := correlations_validation(data, list_variables):
        validated["correlations"] = correlations

    validated["config"] = config_validations(data)

    return validated


def variables_validation(data: dict) -> list:
    """
    Validação das informações da variaveis aleatorias da simulação.

    Parameters:
        data: Dados brutos dos arquivo `*.yaml`.

    Returns:
        Lista com as variaveis validados e convertidos para os formatos corretos.

    Raises:
        SimulationConfigFileError: Erro no arquivo `case.yaml`.
        InvalidDistributionError: Distribuição inválida.
    """
    try:
        variables = data["variables"]
    except KeyError as e:
        raise SimulationConfigFileError(f"Faltando {e} no arquivo de configuração da simulação.") from KeyError

    if not variables:
        raise SimulationConfigFileError("A lista variaveis não pode estar de estar vazia.")

    list_validated = []
    for var in variables:
        not_optional, optional = {}, {}  # type: ignore
        try:
            name, dist = var["name"], var["dist"]
        except KeyError as e:
            raise SimulationConfigFileError(
                f"Faltando {e} no arquivo de configuração da simulação para a variável."
            ) from KeyError

        try:
            dist_name, dist_params = dist["name"], dist["params"]
        except KeyError as e:
            raise SimulationConfigFileError(
                f"Faltando o campo {e} na distruibuição para a variável '{name}' "
                "no arquivo de configuração da simulação."
            ) from KeyError

        if not DistributionNames.has_value(dist_name):
            raise InvalidDistributionError(dist_name)

        params_name = DIST_OPTIONS[dist_name]["params"]
        if set(params_name) != set(dist_params.keys()):
            msg = (
                f"Erro nos parâmetros da distribuição da variável '{name}'. "
                f"A distribuição '{dist_name}' precisa dos parâmetros: ({', '.join(params_name)}). "
                f"Mas foi passado: ({', '.join(dist_params.keys())})."
            )
            raise SimulationConfigFileError(msg)

        dist_conv = {"name": dist["name"], "params": dict()}
        for k, v in dist_params.items():
            try:
                dist_conv["params"][k] = float(v)
            except ValueError:
                raise SimulationConfigFileError(
                    f"O parâmetro '{k}' da distruibuição da variável '{name}' não pode ser convertido."
                ) from ValueError

        optional |= {"name": name, "dist": dist_conv}

        if var.get("initial_point_factor") is not None:
            try:
                initial_point_factor = float(var["initial_point_factor"])
            except ValueError:
                raise SimulationConfigFileError(
                    "O parâmetro 'initial_point_factor' da distruibuição "
                    f"da variável '{name}' não pode ser convertido."
                ) from ValueError

            if initial_point_factor < 0.0:
                raise SimulationConfigFileError(
                    "O parâmetro 'initial_point_factor' da distruibuição "
                    f"da variável '{name}' precisa ser maior que zero."
                )

            optional |= {"initial_point_factor": initial_point_factor}

        list_validated.append(not_optional | optional)

    return list_validated
