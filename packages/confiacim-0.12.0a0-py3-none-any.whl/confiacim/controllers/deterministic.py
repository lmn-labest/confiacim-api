"""
O módulo contem controladores para serem usando na `CLI` e na `API`.

Classes e funções deste módulo:

- run
- new_max_step
---

"""

from pathlib import Path

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from confiacim import tables
from confiacim.erros import CaseFileNotFound, InputDirNotExists, NeedBeAFileNotDir
from confiacim.file_folder_handlers import default_output_dir
from confiacim.logger import get_logger, set_logger
from confiacim.simulation_config import load_config
from confiacim.tencim.deterministic import new_case_with_until_the_step, run_tencim
from confiacim.tencim.rc import first_timestamp_minimal_rc
from confiacim.write_results import write_deterministic_results

logger = get_logger()

determ_app = typer.Typer()

console = Console()


def run(*, input_dir: Path, output_dir: Path | None, verbose: bool):
    """
    Rodando a simulação deterministica.

    Parameters:
        input_dir: Diterório do arquivo de entrada.
        output_dir: Diterório do arquivo de saida.
        verbose: Nivel de verbosidade.
    """

    if not Path(input_dir).exists():
        raise InputDirNotExists(input_dir)

    if not output_dir:
        output_dir = default_output_dir(input_dir)

    set_logger(logfile=input_dir / "simulation.log", name="simulation")

    simulation_conf = load_config(file_path=input_dir / "case.yml")

    logger.info(f"Analise deterministica: {input_dir=} {output_dir=} {verbose=}")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}\n"),
        transient=True,
        disable=verbose,
    ) as progress:
        progress.add_task(description="Running...", total=None)
        results = run_tencim(
            input_dir=input_dir,
            output_dir=output_dir,
            variables=simulation_conf.variables,
            verbose=verbose,
        )

    rcs = first_timestamp_minimal_rc(results)
    table = tables.minimal_rcs(rcs)
    console.print(table)

    write_json = simulation_conf.result_files == "json"
    json_indent = simulation_conf.json_indent

    write_deterministic_results(rcs, output_dir, write_json, json_indent)


def new_max_step(*, case_path: Path, step: int):
    """
    Gera case truncado no new_last_step

    Parameters:
        case_path: Caminho do arquivo principal do `tencim`.
        step: Novo ultimo passo de tempo.
    """

    try:
        data_str = case_path.read_text()
    except FileNotFoundError as e:
        raise CaseFileNotFound(e.filename) from FileNotFoundError
    except IsADirectoryError as e:
        raise NeedBeAFileNotDir(f"{e.filename}") from IsADirectoryError

    original_file = case_path.parent / "case_original.dat"
    if not original_file.exists():
        original_file.write_text(data_str)

    logger.info(f"Analise deterministica: {case_path=} step {step=}")

    new_file_data_str = new_case_with_until_the_step(
        case_data_str=data_str,
        new_last_step=step,
    )

    new_file = case_path.parent / "case.dat"
    new_file.write_text(new_file_data_str)
