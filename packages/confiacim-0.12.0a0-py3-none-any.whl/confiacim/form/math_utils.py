"""Funções matemáticas de apoio.

---
"""

from collections import OrderedDict

import numpy as np
from scipy.linalg import solve_triangular
from scipy.stats import norm

from confiacim.variables.core import StochasticVariable


def variables_mean2Ua(variables: tuple[StochasticVariable, ...]) -> np.ndarray:
    """Pega o valor médio da variáveis estocásticas e inicia a vetor Ua.

    Parameters:
        variables : Tupla das variáveis estocásticas.

    Returns:
        Vetor Ua iniciado com as médias.
    """

    return np.array([v.mean for v in variables], dtype=np.float64)


def _array_Y(Va: np.ndarray, L: np.ndarray) -> np.ndarray:
    """
    Cálculo do vetor `Y` do **FORM**.

    Parameters:
        Va: vetor do **FORM**.
        L: Parte inferior da fatoração **Cholesky** da matriz de correlação.

    Return:
        Retorna o vetor `Y`.
    """
    Y: np.ndarray = L.dot(Va)
    return Y


# TODO: Criar teste unitáro
def Ua2avgs(Un: np.ndarray, variables: tuple[StochasticVariable, ...]) -> OrderedDict[str, float]:
    """
    Transforma a tupla des variáveis para um dicionário.

    Parameters:
        Un: Valor das variaveis aleatórias.
        variables: variaveis.

    Returns:
        Retorna as variáveis.
    """
    new_avg = OrderedDict()
    for u, v in zip(Un, variables):
        new_avg[v.name] = u

    return new_avg


def array_U(Vn: np.ndarray, L: np.ndarray, IFs: tuple) -> np.ndarray:
    """
    Cálculo do vetor `U` do **FORM**.

    Parameters:
        Vn: vetor do **FORM**.
        L: Parte inferior da fatoração **Cholesky** da matriz de correlação.
        IFs: Lista com as `ppf` das distribuições.

    Returns:
        Retorna o fator de importância.
    """
    Y = _array_Y(Vn, L)

    vector = np.zeros_like(Y)

    for i, (y, IF) in enumerate(zip(Y, IFs)):
        vector[i] = IF(norm.cdf(y))

    return vector


def array_V(Ua: np.ndarray, L: np.ndarray, list_of_F: tuple) -> np.ndarray:
    """
    Cálculo do arranho `V` do **FORM**.

    Info:

        Procedimento para evitar inverta matriz.

        1. Gamma = inv(L)
        2. V = Gamma * qNorm
        3. V = inv(L) * qNorm
        4. L * V = L * inv(L) * qNorm
        5. L * V = I * qNorm
        6. L * V = qNorm

    Parameters:
        Ua: valores das variaveis aleatórias.
        L: Parte inferior da fatoração **Cholesky** da matriz de correlação.
        list_of_F: Lista com as `cdf` das distribuições.

    Returns:
        Retorna o vetor `V`.

    """

    qNorm = np.zeros_like(Ua)
    for i, (u, F) in enumerate(zip(Ua, list_of_F)):
        qNorm[i] = norm.ppf(F(u))

    # Triangular solver

    V: np.ndarray = solve_triangular(L, qNorm, lower=True)

    return V


def i_matrix_A(A: np.ndarray) -> np.ndarray:
    """
    Cálculo da matriz inversa diagonal.

    Parameters:
        A: Matriz.

    Returns:
        Retorna a matriz inversa.
    """

    return 1.0 / A


def importance_factors(alpha: np.ndarray) -> np.ndarray:
    """
    Cálculo ao fator da importância.

    Parameters:
        alpha: vetor do **FORM**.

    Returns:
        Retorna o fator de importância.
    """
    x: np.ndarray = 100 * alpha**2
    return x


def matrix_A(Ua: np.ndarray, fs: tuple, Fs: tuple) -> np.ndarray:
    """
    Cálculo da matriz `A` do **FORM**.

    Parameters:
        Ua: RC da simulação
        fs: Lista com as `pdf` das distribuições.
        Fs: Lista com as `cdf` das distribuições.

    Returns:
        Retorna a matriz `A`.
    """

    A = np.zeros_like(Ua)

    for i, (U, f, F) in enumerate(zip(Ua, fs, Fs)):
        A[i] = f(U) / norm.pdf(norm.ppf(F(U)))

    return A


def mk_G(rcs: dict[str, dict[str, float]], gamma: float) -> tuple[float, np.ndarray]:
    """
    Gera o vetor `G` e o vetor `Gaux` do **FORM**.

    Parameters:
        rcs: `RCs` das simulações.
        gamma: Parametro do **FORM**.

    Returns:
        Retorna um tupla com `Gi - gamma` e `Gaux - gamma` da funções de falha.
    """

    rc_u = rcs.copy()
    base = rc_u.pop("base")

    gi = base["last"] * 0.01  # percentage

    tmp = [v["last"] * 0.01 for _, v in rc_u.items()]

    gaux = np.array(tmp)

    return gi - gamma, gaux - gamma


def mk_gradU(Gaux: np.ndarray, Gi: float, Ua: np.ndarray, delta: float) -> np.ndarray:
    """
    Cálculo o gradiente do **Form**.

    Parameters:
        Gaux: Função de falha do casos das derivadas.
        Gi: Função de falha do caso base.
        Ua: Gradiente do **FORM**.
        delta: delta das derivadas.

    Returns:
        Retorna o `gradU`

    """
    return (Gaux - Gi) / (Ua * delta)


def mk_grad_g(Lt: np.ndarray, iA: np.ndarray, gradU: np.ndarray) -> np.ndarray:
    """
    Cálculo o gradiente `g` do **Form**.

    Info:
        L^(T) * A^(-1) * gradU

    Parameters:
        Lt: Transposta da parte inferior da fatoração **Cholesky** da matriz de correlação.
        iA: Matriz inversa da matriz do **FORM**.
        gradU: Gradiente do **FORM**.

    Returns:
        Retorna o vetor `Y`.

    """
    iAxgradU = iA * gradU
    grad_g: np.ndarray = Lt.dot(iAxgradU)
    return grad_g


def omission_factors(alpha: np.ndarray) -> np.ndarray:
    """
    Cálculo ao fator de omissão.

    Parameters:
        alpha: vetor do **FORM**.

    Returns:
        Retorna o fator de omissão.
    """
    if len(alpha) == 1:
        return np.array([np.inf])
    x: np.ndarray = 1.0 / np.sqrt(1.0 - alpha**2)
    return x
