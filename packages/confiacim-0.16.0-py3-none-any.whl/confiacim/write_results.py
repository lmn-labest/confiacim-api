"""
Modulo com funcionalidade para escrever os resultados em arquivos.
"""

import json
from pathlib import Path
from typing import OrderedDict

from confiacim.file_folder_handlers import iteration_folder
from confiacim.form.model import FormResult
from confiacim.jsonencoder import JSONEncoder2Dataclasses
from confiacim.monte_carlo.model import MonteCarloResult
from confiacim.run_statistics import RunStatistics
from confiacim.samples import Sample
from confiacim.tencim.rc import TimeMinimalRC


def write_deterministic_results(
    tmrcs: dict[str, TimeMinimalRC],
    output_dir: Path,
    write_json: bool = True,
    indent: int | None = None,
) -> None:
    """
    Escreve o restultado do RCs da análise deterministica.

    Parameters:
        tmrcs: `RCs` minimo da simulação deterministica.
        output_dir: Caminho do diretório de saida.
        write_json: Escreve também no formato `JSON`.
        indent: Identação do arquivo `JSON`.
    """

    if write_json:
        result_file = output_dir / "deterministic_results.json"
        with open(result_file, encoding="utf-8", mode="w") as fp:
            json.dump(tmrcs, fp, indent=indent, cls=JSONEncoder2Dataclasses)

    else:
        result_file = output_dir / "deterministic_results.txt"
        with open(result_file, mode="w", encoding="utf-8") as fp:
            fp.write("{:^15}|{:^15}|{:^15}|{:^15}|\n".format("Method", "istep", "time", "RC"))
            for k, v in tmrcs.items():
                fp.write(f"{k:15}|{v.istep:15}|{v.t:15.3f}|{v.rc:15.2f}|\n")


def write_final_results(
    results: FormResult,
    output_dir: Path,
    write_json: bool = True,
    indent: int | None = None,
) -> None:
    """
    Escreve os resultado final do **FORM**.

    Parameters:
        results: Resultado do **FORM**.
        output_dir: Caminho do diretório de saida.
        write_json: Escreve também no formato `JSON`.
        indent: Identação do arquivo `JSON`.
    """

    if write_json:
        results_json = results.json_results()
        with open(output_dir / "results.json", encoding="utf-8", mode="w") as fp:
            json.dump(results_json, fp, indent=indent)

    else:
        with open(output_dir / "results.txt", encoding="utf-8", mode="w") as fp:
            fp.write("{:^15}|{:^15}|{:^15}|{:^15}|{:^15}|\n".format("iteration", "beta", "resid", "Pf", "Pf(%)"))
            fp.write(
                f"{results.it:15}|{results.beta:15.6f}|{results.resid:15.6e}|{results.Pf:15.6e}|{results.Pf:15.2%}|\n"
            )

            importance = results.importance_factors
            omission = results.omission_factors

            variables = [k for k in results.rcs if k != "base"]

            fp.write("\n")
            fp.write("{:^20}|{:^20}|{:^20}|\n".format("Variables", "Importance(%)", "Omission"))
            for v, i, o in zip(variables, importance, omission):
                fp.write(f"{v:20}|{i:>20.6f}|{o:>20.6f}|\n")

            fp.write("\n")
            fp.write("{:^20}|{:^20}|{:^20}|\n".format("Variables", "RC_min", "RC_last"))
            for k, v in results.rcs.items():
                fp.write(f"{k:20}|{v['min']:>20.6f}|{v['last']:>20.6f}|\n")


def write_iteration_log(
    betai: float,
    resid: float,
    averages: dict[str, float],
    iteration: int,
    output_dir: Path,
    write_json: bool = True,
    indent: int | None = None,
) -> None:
    """
    Escreve informações da iteração do **FORM** em formato **JSON** ou **TXT**.

    Parameters:
        betai: Valor beta da iteração i.
        resid: Valor do residuo da iteração i.
        averages: Valores das variaveis na iteração i.
        iteration: Número da iteração i.
        write_json: Escreve também no formato `JSON`.
        output_dir: Caminho do diretório de saida.
        indent: Identação do arquivo `JSON`.
    """
    output_dir.mkdir(exist_ok=True, parents=True)
    if write_json:
        _write_iteration_log_json(betai, resid, averages, iteration, output_dir, indent)
    else:
        _write_iteration_log_txt(betai, resid, averages, iteration, output_dir)


def _write_iteration_log_txt(betai: float, resid: float, averages: dict[str, float], it: int, output_dir: Path) -> None:
    file_path = output_dir / "form_iteration_log.txt"

    line = "{:>6} {:e} {:e}"

    for _ in averages:
        line += " {:e}"
    line += "\n"

    if it == 1:
        fp = open(file_path, encoding="utf-8", mode="w")

        head_format = "{:>6} {:>12} {:>12}"
        for _ in averages:
            head_format += " {:>12}"
        head_format += "\n"

        head = head_format.format("it", "beta", "resid", *averages.keys())
        fp.write(head)
    else:
        fp = open(file_path, encoding="utf-8", mode="a")

    fp.write(line.format(it, betai, resid, *averages.values()))

    fp.close()


def _write_iteration_log_json(
    betai: float,
    resid: float,
    averages: dict[str, float],
    it: int,
    output_dir: Path,
    indent: int | None = None,
) -> None:
    file_path = output_dir / "form_iteration_log.json"

    if it == 1:
        with open(file_path, encoding="utf-8", mode="w") as fp:
            vars = {k: [v] for k, v in averages.items()}
            dict_ = {"beta": [betai], "resid": [resid]} | vars
            json.dump(dict_, fp, indent=indent)
    else:
        with open(file_path, encoding="utf-8", mode="r") as fp:
            dict_ = json.load(fp)
            dict_["beta"].append(betai)
            dict_["resid"].append(resid)
            for k, v in averages.items():
                dict_[k].append(v)

        with open(file_path, encoding="utf-8", mode="w") as fp:
            json.dump(dict_, fp, indent=indent)


def write_confiacim_statistics(
    run_statistics: RunStatistics,
    output_dir: Path,
    write_json: bool = True,
    indent: int | None = None,
) -> None:
    """
    Escreve informações da execução do `confiacim`.

    Parameters:
        run_statistics: Estatisca da execuação da simulação.
        output_dir: Caminho do diretório de saida.
        write_json: Escreve também no formato `JSON`.
        indent: Identação do arquivo `JSON`.
    """

    if write_json:
        with open(output_dir / "run_statistics.json", encoding="utf-8", mode="w") as fp:
            json.dump(run_statistics.json(), fp, indent=indent)

    else:
        with open(output_dir / "run_statistics.txt", encoding="utf-8", mode="w") as fp:
            fp.write(f"tencim_time         : {run_statistics.tencim_time:.2f}\n")
            fp.write(f"total_time          : {run_statistics.total_time:.2f}\n")
            fp.write(f"workers             : {run_statistics.workers}\n")
            fp.write(f"exc_mode            : {run_statistics.exc_mode}\n")


def write_samples_variables_it(
    samples: list[Sample] | tuple[Sample],
    iteration: int,
    output_dir: Path,
    write_json: bool = True,
    indent: int | None = None,
) -> None:
    """
    Escreve as variavel usadas nas amostras em cada iteração.

    Parameters:
        samples: Lista com as mostras.
        iteration: Número da iteração.
        output_dir: Caminho do diretório de saida.
        write_json: Escreve também no formato `JSON`.
        indent: Identação do arquivo `JSON`.
    """

    for s in samples:
        if write_json:
            file_path = output_dir / iteration_folder(iteration) / f"sample_variavel_{s.name}.json"
            file_path.parent.mkdir(exist_ok=True, parents=True)

            with open(file_path, encoding="utf-8", mode="w") as fp:
                json.dump(s.averages, fp, indent=indent)

        else:
            file_path = output_dir / iteration_folder(iteration) / f"sample_variavel_{s.name}.txt"
            file_path.parent.mkdir(exist_ok=True, parents=True)

            with open(file_path, encoding="utf-8", mode="w") as fp:
                for k, v in s.averages.items():
                    fp.write(f"{k:<20}: {v:.6e}\n")


def write_variables_it(
    averages: OrderedDict,
    iteration: int,
    output_dir: Path,
    write_json: bool = True,
    indent: int | None = None,
) -> None:
    """
    Escreve as novas variaveis em cada iteração do **FORM**.

    Parameters:
        averages: Variaveis.
        iteration: Número da iteração.
        output_dir: Caminho do diretório de saida.
        write_json: Escreve também no formato `JSON`.
        indent: Identação do arquivo `JSON`.
    """

    if write_json:
        file_path = output_dir / f"u_new_{iteration}.json"
        file_path.parent.mkdir(exist_ok=True, parents=True)

        with open(file_path, encoding="utf-8", mode="w") as fp:
            json.dump(averages, fp, indent=indent)

    else:
        file_path = output_dir / f"u_new_{iteration}.txt"
        file_path.parent.mkdir(exist_ok=True, parents=True)

        with open(file_path, encoding="utf-8", mode="w") as fp:
            for k, v in averages.items():
                fp.write(f"{k:<20}: {v:.6e}\n")


def write_monte_carlo_results(
    results: MonteCarloResult,
    output_dir: Path,
    write_json: bool = True,
    indent: int | None = None,
) -> None:
    """
    Escreve o restultado do monte_carlo.

    Parameters:
        results: Resultado.
        output_dir: Caminho do diretório de saida.
        write_json: Escreve também no formato `JSON`.
        indent: Identação do arquivo `JSON`.
    """
    output_dir.mkdir(exist_ok=True, parents=True)
    if write_json:
        result_file = output_dir / "results.json"
        with open(result_file, encoding="utf-8", mode="w") as fp:
            json.dump(results, fp, indent=indent, cls=JSONEncoder2Dataclasses)

    else:
        result_file = output_dir / "results.txt"
        with open(result_file, mode="w", encoding="utf-8") as fp:
            fp.write(f"total: {results.total}\n")
            fp.write(f"valid_simulations: {results.valid_simulations}\n")
            fp.write(f"fail: {results.fail}\n")
            fp.write(f"P: {results.P}\n")
            if results.estimator:
                fp.write(f"estimator: {results.estimator:.4f}\n")
            else:
                fp.write(f"estimator: {results.estimator}\n")


def write_monte_carlo_batch_results(
    results: list[MonteCarloResult],
    output_dir: Path,
    write_json: bool = True,
    indent: int | None = None,
) -> None:
    """
    Escreve o restultado do monte_carlo.

    Parameters:
        results: Resultado.
        output_dir: Caminho do diretório de saida.
        write_json: Escreve também no formato `JSON`.
        indent: Identação do arquivo `JSON`.
    """
    output_dir.mkdir(exist_ok=True, parents=True)
    if write_json:
        result_file = output_dir / "batch_results.json"
        with open(result_file, encoding="utf-8", mode="w") as fp:
            json.dump(results, fp, indent=indent, cls=JSONEncoder2Dataclasses)

    else:
        result_file = output_dir / "batch_results.txt"
        with open(result_file, mode="w", encoding="utf-8") as fp:
            fp.write(
                "{:8} {:16} {:8} {:8} {:8} {}\n".format(
                    "total", "valid_simulations", "fail", "P", "estimator", "estimator"
                )
            )
            for r in results:
                if r.estimator:
                    fp.write(f"{r.total:<8d} {r.valid_simulations:<16d} {r.fail:<8d} {r.P:.4f}   {r.estimator:.4f}\n")
                else:
                    fp.write(f"{r.total:<8d} {r.valid_simulations:<16d} {r.fail:<8d} {r.P:.4f}   {r.estimator}\n")
