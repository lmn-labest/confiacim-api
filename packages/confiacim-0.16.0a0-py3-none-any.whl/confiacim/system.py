"""
Modulo com funções que lidam com diferença entre `OS`.

Classes e funções deste módulo:

- get_os
- default_tencim_dir

---
"""

import platform
from importlib.resources import files
from pathlib import Path


def get_os() -> str:
    """
    Retorna qual `OS` esta sendo usado.

    Returns:
        Retorna `linux` ou `win`.
    """
    system = ""
    match platform.system():
        case "Linux":
            system = "linux"
        case "Windows":
            system = "win"
    return system


def default_tencim_dir() -> Path:
    """
    Retorna o diretório pradão do tencim de dependendo do `SO`.

    Returns:
        Retorna o diretório pradão do tencim.
    """

    module_root_dir = files("confiacim.data")
    return Path(str(module_root_dir / f"prebuild/{get_os()}"))
