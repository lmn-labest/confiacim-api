"""
Modulo com as configurações

Classes e funções deste módulo:

- TencimExcMode
- Settings
- ExcTencimModeError
---
"""

from enum import IntEnum
from pathlib import Path

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from confiacim.system import default_tencim_dir

_EXEC_TENCIM_DIR = default_tencim_dir()


class TencimExcMode(IntEnum):
    """
    Modo de excução disponiveis

    Info:
        Valores diponiveis:

        - SEQUENTIAL = 1
        - MULTIPROC = 2

    Attributes:
        SEQUENTIAL: Sequencial.
        MULTIPROC: Multiprocesso.

    """

    SEQUENTIAL = 1
    MULTIPROC = 2

    @classmethod
    def options(cls) -> list[str]:
        """
        Returna os nomes do modes.

        Returns
            Retorna uma lista com os nomes do modos.
        """
        return [d.name for d in cls]

    @classmethod
    def name_by_value(cls, v: int) -> str | None:
        """
        Pega o nome do mode pelo valor inteiro.

        Parameters:
            v: valor númerico do mode.

        Returns:
            Retorna o nome do modo.
        """
        for d in cls:
            if v == d.value:
                return d.name
        return None


# TODO: Loggar isso ou não ?
class ExcTencimModeError(Exception):
    """Only used in this module"""

    def __init__(self, mode):
        options = ", ".join(TencimExcMode.options())
        self.message = f"Modo de excução do tencim {mode} é invalido. As opções são: {options}."
        super().__init__(self.message)


class Settings(BaseSettings):
    """
    Classe de configurações

    Attributes:
        EXEC_TENCIM_BIN: Nome do executabel do `Tencim`.
        EXEC_TENCIM_DIR: Diretorio do executabel do `Tencim`.
        EXEC_TENCIM_MODE: Modo de execução.
        HIDRPROP_FILE_NAME: Nome do arquivo `hidrationprop.dat`.
        MATERIALS_FILE_NAME: Nome do arquivo `materials.dat`.
        INITIAL_TEMP_FILE_NAME: Nome do arquivo `initialtemperature.dat`.
        LOADS_FILE_NAME: Nome do arquivo `loads.dat`.
        LOG_LEVEL: Nivel do log
        LOG_FILE_PATH: Caminho do arquivo log do confiacim.

    """

    EXEC_TENCIM_BIN: str = "TENCIM1D.exe"
    EXEC_TENCIM_DIR: Path = _EXEC_TENCIM_DIR
    EXEC_TENCIM_MODE: int = Field(default="MULTIPROC")

    HIDRPROP_FILE_NAME: str = "hidrationprop.dat"
    MATERIALS_FILE_NAME: str = "materials.dat"
    INITIAL_TEMP_FILE_NAME: str = "initialtemperature.dat"
    LOADS_FILE_NAME: str = "loads.dat"

    LOG_LEVEL: str = "ERROR"
    LOG_FILE_PATH: Path = Path("./confiacim.log")

    model_config = SettingsConfigDict(
        env_prefix="confiacim_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra='ignore',
    )

    @field_validator("EXEC_TENCIM_MODE", mode="before")
    def exec_tencim_mode_convert(cls, v: str) -> int:
        """
        Converta a string `EXEC_TENCIM_MODE`para um código númerico

        Attributes:
            v: Nome do modo.

        Returns:
            Retorna o valor númerico
        """
        try:
            mode_ = TencimExcMode[v].value
        except KeyError:
            raise ExcTencimModeError(v) from KeyError
        return mode_


settings = Settings()
