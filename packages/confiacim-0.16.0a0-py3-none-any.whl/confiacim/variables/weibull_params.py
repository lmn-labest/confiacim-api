"""
Neste modulo temos a função que cálcula os parêmtro da weibull.

---
"""

import numpy as np
from scipy.optimize import fsolve
from scipy.special import gamma, gammaln


class NoConvergenceWeibullParams(Exception): ...


def weibull_k_lambda_from_mean_std_numeric_picard(
    mu: float,
    sig: float,
    tol: float = 1.0e-11,
    maxit: int = 500_000,
    alf: float = 0.5,
    exception: bool = False,
    verbose: bool = False,
) -> tuple[float, float]:
    """
    Obtem o `k` e `lamb` da distribuicao de `weibull` dada uma média e um desvio padrão.

    Parameters:
        mu: Média.
        sig: Desvio padrao.
        maxit: Número máximo de iterações.
        tol: Tolerância desejada.
        alf: Paramêtro de relaxamento.
        exception: Levanta um exeção caso a iteração máxima não seja atingida.
        verbose: Saida descritivas.

    Raises:
        NoConvergenceWeibullParams: Levanta um erro casso numero de iteração máximo seja atingindo.

    Returns:
        Returna uma tupla com os valores `k` e `amb`.

    """

    def _solver(A: np.ndarray, x: np.ndarray, F: np.ndarray):
        """Solver do Ax=F"""
        x[0] = F[0] / A[0]
        x[1] = F[1] / A[1]
        x[2] = (F[2] - A[3] * x[1]) / A[2]

    def _matriz_a(A: np.ndarray, X: np.ndarray):
        """Atualizacao da matriz A(x)"""
        lambda_ = X[0]
        w = X[1]
        z = X[2]

        # linha 1
        A[0] = z * gamma(z)  # A11
        # linha 2
        A[1] = lambda_ * lambda_ * gamma(w)  # A22
        # linha 3
        A[2] = 2.0e0  # A33
        A[3] = -1.0e0  # A23

    def _vector_F(sig: float, mu: float) -> np.ndarray:
        """Cálculo do vetor F"""
        f1 = mu
        f2 = sig**2 + mu**2

        return np.array([f1, f2, 0.0], dtype=np.float64)

    def _matvec(A: np.ndarray, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        """Operação matriz vetor"""

        y[0] = A[0] * x[0]
        y[1] = A[1] * x[1]
        y[2] = A[2] * x[2] + A[3] * x[1]

        return y

    A = np.zeros(4, dtype=np.float64)
    x = np.zeros(3, dtype=np.float64)
    y = np.zeros(3, dtype=np.float64)

    k, lambda_ = weibull_k_lambda_from_mean_std_analytic_gamma(mu, sig)

    # ... chute inicial
    x[0] = lambda_  # l
    x[1] = 2.0 / k  # y
    x[2] = 1.0 / k  # x

    F = _vector_F(sig, mu)
    r0 = F - _matvec(A, x, y)

    res0 = np.linalg.norm(r0)

    # ...
    one_alf = 1.0e0 - alf

    # ... loop
    for _it in range(1, maxit + 1):
        _matriz_a(A, x)
        # ... residuo
        r = F - _matvec(A, x, y)
        # ... ||r||
        res = np.linalg.norm(r)
        if res < res0 * tol:
            break
        # ...
        x0 = np.copy(x)
        # ... x = (A^-1)*F
        _solver(A, x, F)
        # ... update x
        x = alf * x + one_alf * x0

    if verbose:
        print(f"Ressiduo final {res} para _it {_it}")

    if exception and _it == maxit:
        raise NoConvergenceWeibullParams(
            f"Erro não obtenção dos parametros da weibull. Residuo final {res/res0:.6e} para iteração {_it}."
        )

    k, lambda_ = 2.0e0 / x[1], x[0]

    return k, lambda_


def weibull_k_lambda_from_mean_std_fsolve(mu: float, sig: float, exception: bool = False) -> tuple[float, float]:
    """
    Obtem o `k` e `lambda` da distribuicao de `weibull` dada uma média e um desvio padrao

    Parameters:
        mu: Média.
        sig: Desvio padrao.
        exception: Levanta um exeção caso a iteração máxima não seja atingida.

    Raises:
        NoConvergenceWeibullParams: Levanta um erro casso numero de iteração máximo seja atingindo.

    Returns:
        Returna uma tupla com os valores `k` e `lamb`.
    """

    def _h(k):
        r = np.exp(gammaln(2 / k) - 2 * gammaln(1 / k))
        return np.sqrt(1 / (2 * k * r - 1))

    k0 = 1.27 * np.sqrt(mu / sig)
    k, _, ier, msg = fsolve(lambda t: _h(t) - (mu / sig), k0, xtol=1e-10, full_output=True)
    if exception and ier != 1:
        raise NoConvergenceWeibullParams(
            f"Erro não obtenção dos parametros da weibull com mean={mu} and std={sig}: fsolve failed: {msg}"
        )

    k = k[0]
    lambda_ = mu / gamma(1 + 1 / k)
    return k, lambda_


def weibull_k_lambda_from_mean_std_analytic_gamma(mu: float, sig: float) -> tuple[float, float]:
    """
    Obtém o `k` e `lambda` da distribuição de `weibull` dada uma média e um desvio padrão de forma
    analítica estimada usuando a função `gamma`.

    Parameters:
        mu: Média.
        sig: Desvio padrao.

    Returns:
        Returna uma tupla com os valores `k` e `lamb`.

    """

    k = pow(sig / mu, -1.086)
    lambda_ = mu / gamma(1.0 + 1.0 / k)

    return k, lambda_


weibull_k_lambda_from_mean_std = weibull_k_lambda_from_mean_std_fsolve
