"""
Modulo com a funcionalidades do Monte Carlo

- generate_samples

---
"""

from pathlib import Path

from more_itertools import batched
from rich.align import Align
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.text import Text
from scipy.linalg import cholesky

from confiacim.constants import COLORS
from confiacim.form.correlations import generate_correlation_matrix
from confiacim.monte_carlo.model import MonteCarloResult
from confiacim.samples import Sample, SamplesGeneratorMonteCarlo, generate_seeds
from confiacim.tencim.iteration import run_samples_iteration_i
from confiacim.tencim.rc import RCCriteria
from confiacim.tencim.runner import TencimRunnerByPassFailure
from confiacim.timer import Timer
from confiacim.variables.core import StochasticVariable
from confiacim.verbose import VerboseLevel
from confiacim.write_results import (
    write_monte_carlo_batch_results,
    write_samples_variables_it,
)

TENCIM_TIME_MEAN = 5.0


def failure_probability_from_rcs(rcs: dict[str, dict[str, float] | None]) -> MonteCarloResult:
    """
    Indentifica os RCs menores de que zero para calcular a probabilidade de falha.

    Parameters:
        rcs (dict): Resultados de RCs das amostras

    Returns:
        Resultado do Monte Carlo
    """

    fail_count, valid_simulations = 0, 0
    for v in rcs.values():

        if v is None:
            continue

        if v["last"] <= 0.0:
            fail_count += 1

        valid_simulations += 1

    return MonteCarloResult(total=len(rcs), valid_simulations=valid_simulations, fail=fail_count)


def loop(
    *,
    input_dir: Path,
    output_dir: Path,
    variables: tuple[StochasticVariable, ...],
    n_samples: int,
    batch_size: int,
    seed: int | None = None,
    correlations: dict[str, float] | None = None,
    rc_criteria: str = "mohr-coulomb",
    result_files: str = "json",
    save_intermediate_files: bool = False,
    json_indent: int | None = None,
    verbose_level: int = VerboseLevel.LEVEL_2,
    console: Console | None = None,
) -> MonteCarloResult:
    """
    Efetua os cálculos e procedientos do loop principal do método **Monte Carlo**.

    Parameters:
        input_dir: Diretório dos arquivos de entrada.
        output_dir: Diretório dos arquivos de saida.
        variables: Variaveis aleatórias.
        n_samples: Número de amostras do **Monte Carlo**.
        batch_size: Tamanho do lote de simulação do **Monte Carlo**.
        seed: Semente do **Monte Carlo**.
        correlations: Informação das correlações das variáveis.
        rc_criteria: Critério do **RC**.
        result_files: Tipo de arquivo de saida.
        save_intermediate_files: Salva os arquivos intermediarios da simulação.
        json_indent: identação do arquivo json.
        verbose_level: Nivel de verbosidade.
        console: console do `Rich`.

    Returns:
        Retorna o resultado final do **FORM**.

    Info:
        A verbosidade pode ser:

        - 0 - Nenhuma
        - 1 - Moderada
        - 2 - Alta
    """

    ro = generate_correlation_matrix(correlations, variables)
    L = cholesky(ro, lower=True)

    seeds = generate_seeds(seed=seed, n=len(variables))
    g = SamplesGeneratorMonteCarlo(variables=variables, n_samples=n_samples, L=L, seeds=seeds)

    with Timer("Generate samples"):
        samples = g.all()

    progressbarDisable = verbose_level == VerboseLevel.LEVEL_0 or verbose_level == VerboseLevel.LEVEL_2
    verbose = verbose_level == VerboseLevel.LEVEL_2
    write_json = result_files == "json"
    json_indent = json_indent

    total, fail, valid_simulations = 0, 0, 0
    historic_results = []

    with Progress(
        transient=True,
        disable=progressbarDisable,
        speed_estimate_period=batch_size * TENCIM_TIME_MEAN,
    ) as progress:
        task = progress.add_task(description="Running Monte Carlo samples:", total=n_samples)
        for batch_number, batched_samples in enumerate(batched(samples, batch_size), start=1):
            if verbose and console:
                text = Text(f"Bath {batch_number + 1}", justify="center", style=COLORS[0])
                panel = Panel(Align(text, vertical="middle", align="center"))
                console.print(panel)

                text = Text("Tencim step", justify="center", style=COLORS[1])
                panel = Panel(Align(text, vertical="middle", align="center"))
                console.print(panel)

            rcs = run_samples_iteration_i(
                samples=batched_samples,
                input_dir=input_dir,
                output_dir=output_dir,
                iteration=batch_number,
                RunnerClass=TencimRunnerByPassFailure,
                verbose=verbose,
                save_intermediate_files=save_intermediate_files,
                rc_criteria=RCCriteria.str_to_enum(rc_criteria),
            )

            if verbose and console:
                text = Text("End tencim step", justify="center", style=COLORS[1])
                panel = Panel(Align(text, vertical="middle", align="center"))
                console.print(panel)

            if save_intermediate_files:
                write_samples_variables_it(
                    samples=batched_samples,
                    iteration=batch_number,
                    output_dir=output_dir,
                    write_json=write_json,
                    indent=json_indent,
                )

            partial_results = failure_probability_from_rcs(rcs)

            total += partial_results.total
            fail += partial_results.fail
            valid_simulations += partial_results.valid_simulations

            results = MonteCarloResult(total, valid_simulations, fail)
            historic_results.append(results)

            write_monte_carlo_batch_results(historic_results, output_dir, write_json=write_json, indent=json_indent)

            msg = (
                f"[cyan]Estimator[/cyan]  = {results.estimator:e}"
                if results.estimator
                else "[cyan]Estimator[/cyan] = Not avalible yet"
            )
            progress.update(
                task,
                description=(
                    f"[green]Running[/green]:\n"
                    f"[cyan]batch[/cyan] = {batch_number:8d}\n"
                    f"[cyan]Failure Probability[/cyan]  = {results.P:.4%}\n"
                    f"{msg}"
                ),
                advance=len(batched_samples),
            )

            if verbose and console:
                text = Text("Partial results", justify="center", style=COLORS[0])
                panel = Panel(Align(text, vertical="middle", align="center"))
                console.print(panel)

                console.print(f"batch = {batch_number:6d} Probability = {results.P:.4%}")

                text = Text("End bath step", justify="center", style=COLORS[1])
                panel = Panel(Align(text, vertical="middle", align="center"))
                console.print(panel)

    return results


def generate_samples(
    generator: SamplesGeneratorMonteCarlo,
    verbose_level: int = VerboseLevel.LEVEL_2,
    console: Console | None = None,
) -> list[Sample]:
    """
    Gerndo as amostras do Monte Carlo.

    Parameters:
        generator: Gerador de amostras.
        verbose_level: Nivel de verbosidade.
        console: console do `Rich`.

    Returns:
        Amostras geradas do **Monte Carlo**.

    Info:
        A verbosidade pode ser:

        - 0 - Nenhuma
        - 1 - Moderada
        - 2 - Alta

    """

    progressbarDisable = verbose_level == VerboseLevel.LEVEL_0 or verbose_level == VerboseLevel.LEVEL_2
    verbose = verbose_level == VerboseLevel.LEVEL_2
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}\n"),
        transient=True,
        disable=progressbarDisable,
    ) as progress:
        progress.add_task(description="Running...", total=None)

        if verbose and console:
            text = Text("Generating Monte Carlo samples", justify="center", style=COLORS[0])
            panel = Panel(Align(text, vertical="middle", align="center"))
            console.print(panel)
            console.print(f"Were generated {generator.n_samples}")

        samples = generator.all()

        if verbose and console:
            text = Text("End", justify="center", style=COLORS[0])
            panel = Panel(Align(text, vertical="middle", align="center"))
            console.print(panel)

    return samples
