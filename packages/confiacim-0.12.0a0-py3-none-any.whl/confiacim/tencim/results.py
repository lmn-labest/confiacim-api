"""Modulo que lida com os resultados da análise."""

import csv
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from confiacim.erros import EmptyRCFile, RCFileNotFound


@dataclass(frozen=True)
class RCResults:
    """
    Classe que define os resultados `RC`.

    Attributes:
        istep: passos de tempo.
        t: tempos.
        rc_mhor_coulomb: `RC` do critério de Mhor Coulomb.
        rc_rankine: `RC` do critério de Rankine.
    """

    istep: np.ndarray
    t: np.ndarray
    rc_mhor_coulomb: np.ndarray
    rc_rankine: np.ndarray


def read_rc_file(filename_path: Path) -> RCResults:
    """
    Lê o arquivo `RC`.

    Attributes:
        filename_path: caminho do diretório onde existe um arquivo`RC`.

    Returns:
        Retorna os resultados.

    Raises:
        EmptyRCFile: O arquivo `RC` está vazio.
        RCFileNotFound: O arquivo `RC` não encontrado.
    """

    try:
        with open(filename_path, encoding="utf-8") as fp:
            reader = csv.reader(fp)

            try:
                next(reader)
            except StopIteration:
                raise EmptyRCFile(f"Arquivo {filename_path} está vazio.") from StopIteration

            i_s, t_s, rc_mc_s, rc_r_s = [], [], [], []
            for line in reader:
                words = line[0].split()
                istep = int(words[0])
                t, rc_mc, rc_r = map(float, (words[1], words[3], words[-1]))

                i_s.append(istep)
                t_s.append(t)
                rc_mc_s.append(rc_mc)
                rc_r_s.append(rc_r)

        return RCResults(
            istep=np.array(i_s),
            t=np.array(t_s),
            rc_mhor_coulomb=np.array(rc_mc_s),
            rc_rankine=np.array(rc_r_s),
        )
    except FileNotFoundError as e:
        raise RCFileNotFound(f"Arquivo '{e.filename}' não foi achado.") from FileNotFoundError


def read_rc_results_from_folder(path: Path) -> RCResults:
    """
    Lê o arquivo RC no diretório especificado.

    Attributes:
        path: caminho do diretório onde existe um arquivo`RC`.

    Returns:
        Retorna os resultados.

    Info:
        O **prefixo** do arquivo de `RC` é o **mesmo** nome da pasta.

    Raises:
        EmptyRCFile: O arquivo `RC` está vazio.
        RCFileNotFound: O arquivo `RC` não encontrado.
    """
    filename = path.name + "_RC.txt"
    return read_rc_file(path / filename)
