"""
Matrix de correlação.

Classes e funções deste módulo:

- generate_correlation_matrix

---
"""

import numpy as np

from confiacim.variables.core import StochasticVariable


# TODO: Mover para raiz do projeto
def generate_correlation_matrix(
    correlations: dict[str, float] | None, variables: tuple[StochasticVariable, ...]
) -> np.ndarray:
    """
    Calcula a matrix de correlação.

    Parameters:
        correlations: dicionário com as correlações entre as variáveis.
        variables: variáveis aleatorios.

    Returns:
        Retorna a matriz de correlações
    """
    n_vars = len(variables)
    ro = np.identity(n_vars, dtype=np.float64)

    if not correlations:
        return ro

    index = {}
    for i, v in enumerate(variables):
        index[v.name] = i

    for k, coor in correlations.items():
        name1, name2 = map(str.strip, k.split(","))
        i, j = index[name1], index[name2]
        ro[i, j] = ro[j, i] = coor

    return ro
